plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.serialization)
}
android {
    namespace = "cn.edu.ruc.zhixing.companion.chat"
    compileSdk = 35
    defaultConfig { minSdk = 26 }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    api(project(":core:model"))
    api(project(":storage:room"))
    api(project(":companion:ai"))
    api(project(":agent:memory"))
    api(project(":planner:extract"))
    api(project(":planner:calendar"))
    api(project(":focus:ctdp"))
    implementation(libs.kotlinx.coroutines)
    implementation(libs.kotlinx.serialization.json)
    testImplementation(libs.junit)
}


package cn.edu.ruc.zhixing.companion.chat

import cn.edu.ruc.zhixing.core.model.companion.*

/** 安抚状态保持到用户明确发出规划请求，不因短回复自动推任务。 */
class ChatStateMachine {
    var mode = ChatMode.NORMAL
        private set
    fun next(text: String, emotion: EmotionLabel): ChatMode {
        val distress = emotion in setOf(EmotionLabel.CRISIS, EmotionLabel.SAD, EmotionLabel.STRESSED, EmotionLabel.OVERWHELMED, EmotionLabel.ANGRY)
        mode = when {
            distress -> ChatMode.SOOTHING
            Regex("帮我.*(安排|计划|规划)|我要开始|我该怎么办|帮我记|添加.*(日程|待办)").containsMatchIn(text) -> ChatMode.PLANNING
            mode == ChatMode.SOOTHING -> ChatMode.SOOTHING
            else -> ChatMode.NORMAL
        }
        return mode
    }
}

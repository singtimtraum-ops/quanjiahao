package cn.edu.ruc.zhixing.companion.chat.desensitize

/** 上云前统一替换已知昵称和数字标识；不能保证识别所有自由文本中的个人信息。 */
class Desensitizer {
    fun clean(text: String, names: List<String> = emptyList(), groups: List<String> = emptyList()): String {
        var result = text
        groups.filter { it.isNotBlank() }.sortedByDescending { it.length }.forEach { result = result.replace(it, "某群") }
        names.filter { it.isNotBlank() }.distinct().sortedByDescending { it.length }.forEachIndexed { index, name ->
            result = result.replace(name, "同学${index + 1}")
        }
        return result.replace(Regex("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"), "[邮箱]")
            .replace(Regex("(?<!\\d)\\d{5,19}[Xx]?(?!\\d)"), "[号码]")
    }
}

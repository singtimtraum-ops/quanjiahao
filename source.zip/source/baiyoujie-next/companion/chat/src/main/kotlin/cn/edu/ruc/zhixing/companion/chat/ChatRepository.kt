package cn.edu.ruc.zhixing.companion.chat

import cn.edu.ruc.zhixing.companion.ai.*
import cn.edu.ruc.zhixing.companion.ai.config.LlmConfigProvider
import cn.edu.ruc.zhixing.companion.ai.emotion.EmotionDetector
import cn.edu.ruc.zhixing.companion.ai.persona.PersonaPromptBuilder
import cn.edu.ruc.zhixing.companion.ai.shape.ResponseShaper
import cn.edu.ruc.zhixing.core.model.companion.*
import cn.edu.ruc.zhixing.storage.room.chat.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.*
import java.util.UUID

/** 一次只处理一轮对话；失败明确标记，不将网络错误当作模型回复。 */
class ChatRepository(
    private val dao: ChatDao, private val client: LlmClient,
    private val config: LlmConfigProvider, private val context: suspend () -> String,
    private val afterTurn: (String, String, Boolean) -> Unit = { _, _, _ -> },
) {
    private val mutex = Mutex()
    private val machine = ChatStateMachine()
    private val detector = EmotionDetector()
    private val shaper = ResponseShaper()
    val preview = MutableStateFlow("")
    val busy = MutableStateFlow(false)
    val error = MutableStateFlow("")
    fun clearStatus() { preview.value = ""; error.value = "" }
    suspend fun send(input: String) = mutex.withLock {
        val text = input.trim().take(4000)
        if (text.isBlank()) return@withLock
        busy.value = true; clearStatus()
        val emotion = detector.detect(text)
        val mode = machine.next(text, emotion)
        try {
            val userId = save(ChatRole.USER, text, emotion)
            val settings = config.current()
            if (emotion == EmotionLabel.CRISIS) {
                save(ChatRole.AI, shaper.shape("", mode, emotion), emotion)
                return@withLock
            }
            if (!settings.allowCloud) { error.value = "云端理解未开启，消息仅保存在本机。请到设置中选择是否开启。"; return@withLock }
            if (settings.apiKey.isBlank()) { error.value = "尚未填写 API Key，请前往设置。"; return@withLock }
            val history = dao.recent(20).asReversed().filter { it.role != ChatRole.SYSTEM.name }
            val system = PersonaPromptBuilder().build(settings.personaName, mode, ZonedDateTime.now().toString(), context())
            val raw = StringBuilder()
            client.chatStream(system, history.map { LlmMsg(if (it.role == "AI") "assistant" else "user", it.content) }).collect {
                if (it is LlmEvent.Delta) {
                    raw.append(it.text)
                    check(raw.length <= 16000) { "模型回复过长，请重试。" }
                    val withoutTag = raw.toString().replace(Regex("\\[emotion:[^]]*]", RegexOption.IGNORE_CASE), "")
                    // 等首个完整句子再显示，避免未整形的长清单或半截标签泄露到界面。
                    if (!withoutTag.startsWith("[") && Regex("[。！？.!?]").containsMatchIn(withoutTag)) {
                        preview.value = shaper.shape(withoutTag, mode, emotion)
                    }
                }
            }
            save(ChatRole.AI, shaper.shape(raw.toString(), mode, emotion), emotion)
            afterTurn(userId, text, mode != ChatMode.SOOTHING)
        } catch (cancelled: CancellationException) {
            error.value = "本次回复已停止。"
            throw cancelled
        } catch (failure: Exception) {
            error.value = when {
                failure is IllegalArgumentException || failure is IllegalStateException -> failure.message ?: "请求失败，请检查设置。"
                else -> "暂时无法连接模型。内容已保存在本机，请检查网络后重试。"
            }
        } finally { preview.value = ""; busy.value = false }
    }
    private suspend fun save(role: ChatRole, text: String, emotion: EmotionLabel): String {
        val id = UUID.randomUUID().toString()
        dao.insert(ChatTurnEntity(id, "default", role.name, text, emotion.name, System.currentTimeMillis(), LocalDate.now().toString(), null))
        return id
    }
}

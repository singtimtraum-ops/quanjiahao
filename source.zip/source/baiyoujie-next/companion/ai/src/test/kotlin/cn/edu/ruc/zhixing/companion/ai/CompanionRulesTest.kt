package cn.edu.ruc.zhixing.companion.ai

import cn.edu.ruc.zhixing.companion.ai.emotion.EmotionDetector
import cn.edu.ruc.zhixing.companion.ai.shape.ResponseShaper
import cn.edu.ruc.zhixing.companion.ai.openai.*
import cn.edu.ruc.zhixing.companion.ai.config.*
import cn.edu.ruc.zhixing.core.model.companion.*
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class CompanionRulesTest {
    @Test fun soothingNeverShowsAnInstructionList() {
        val shaped = ResponseShaper().shape("作为一个AI，首先你应该学习。1.制定任务。2.快去完成！".repeat(10), ChatMode.SOOTHING, EmotionLabel.STRESSED)
        assertTrue(shaped.length <= 60)
        assertFalse(Regex("首先|应该|学习|任务|\\d+[.、]|AI").containsMatchIn(shaped))
    }
    @Test fun crisisUsesLocalSupportWithoutTasks() {
        val emotion = EmotionDetector().detect("我真的撑不下去了，活着好没意思")
        assertEquals(EmotionLabel.CRISIS, emotion)
        val text = ResponseShaper().shape("制定计划", ChatMode.SOOTHING, emotion)
        assertTrue(text.contains("12356")); assertFalse(text.contains("计划")); assertTrue(text.length <= 60)
    }
    @Test fun oversizedSentenceUsesBoundedFallback() {
        assertTrue(ResponseShaper().shape("长".repeat(1000), ChatMode.NORMAL, EmotionLabel.NEUTRAL).length <= 60)
    }
    @Test fun sseParsesDeltaAndSplitToolArguments() {
        val decoder = SseDecoder()
        assertTrue(decoder.line("data: {\"choices\":[{\"delta\":{\"content\":\"你好\"}}]}").isEmpty())
        assertEquals(listOf(LlmEvent.Delta("你好")), decoder.line(""))
        decoder.line("data: {\"choices\":[{\"delta\":{\"tool_calls\":[{\"index\":0,\"function\":{\"name\":\"create_todo\",\"arguments\":\"{\"}}]}}]}")
        decoder.line("")
        decoder.line("data: {\"choices\":[{\"delta\":{\"tool_calls\":[{\"index\":0,\"function\":{\"arguments\":\"}\"}}]},\"finish_reason\":\"tool_calls\"}]}")
        decoder.line(""); decoder.line("data: [DONE]")
        val result = decoder.line("")
        assertEquals(LlmEvent.ToolCall("create_todo", "{}"), result[0]); assertTrue(decoder.finished)
    }
    @Test fun cloudOffRejectsBeforeSanitizerOrNetwork() = runBlocking {
        var sanitized = false
        val client = OpenAiLlmClient(LlmConfigProvider { LlmConfig(allowCloud = false) }) { sanitized = true; it }
        try { client.chat("test", emptyList()); fail("Cloud gate missing") } catch (_: IllegalStateException) { }
        assertFalse(sanitized)
    }
    @Test fun emptyKeyRejectsBeforeSanitizerOrNetwork() = runBlocking {
        var sanitized = false
        val client = OpenAiLlmClient(LlmConfigProvider { LlmConfig(allowCloud = true) }) { sanitized = true; it }
        try { client.chat("test", emptyList()); fail("Key gate missing") } catch (_: IllegalStateException) { }
        assertFalse(sanitized)
    }
}

package cn.edu.ruc.zhixing.companion.ai.config

/** 密钥由应用层加密保存；不得写入日志、导出或安装包。 */
data class LlmConfig(
    val baseUrl: String = "https://api.deepseek.com", val apiKey: String = "",
    val model: String = "deepseek-chat", val allowCloud: Boolean = false,
    val personaName: String = "小行",
)
/** 每次请求读取最新配置，以确保关闭云端开关立即生效。 */
fun interface LlmConfigProvider { suspend fun current(): LlmConfig }

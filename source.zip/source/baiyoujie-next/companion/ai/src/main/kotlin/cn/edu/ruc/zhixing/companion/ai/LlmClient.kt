package cn.edu.ruc.zhixing.companion.ai

import cn.edu.ruc.zhixing.core.model.companion.LlmMsg
import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.json.JsonObject

/** 可替换的模型通道，不直接执行模型提出的工具调用。 */
interface LlmClient {
    suspend fun chat(system: String, messages: List<LlmMsg>, tools: List<LlmTool> = emptyList()): LlmResult
    fun chatStream(system: String, messages: List<LlmMsg>, tools: List<LlmTool> = emptyList()): Flow<LlmEvent>
}
data class LlmTool(val name: String, val description: String, val parameters: JsonObject)
data class LlmResult(val text: String, val calls: List<LlmEvent.ToolCall> = emptyList())
sealed class LlmEvent {
    data class Delta(val text: String) : LlmEvent()
    data class ToolCall(val name: String, val argsJson: String) : LlmEvent()
    data class Done(val stopReason: String?) : LlmEvent()
}

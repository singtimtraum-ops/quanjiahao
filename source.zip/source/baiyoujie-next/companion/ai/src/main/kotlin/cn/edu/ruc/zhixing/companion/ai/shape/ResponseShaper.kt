package cn.edu.ruc.zhixing.companion.ai.shape

import cn.edu.ruc.zhixing.core.model.companion.*

/** 输出侧硬约束；流式显示也只能使用本层处理后的文本。 */
class ResponseShaper {
    fun shape(raw: String, mode: ChatMode, emotion: EmotionLabel): String {
        if (emotion == EmotionLabel.CRISIS) return "我很在意你的安全。请联系信任的人，或拨打心理援助热线12356；眼下有危险请拨120或110。"
        var text = raw.replace(Regex("\\[emotion:[^]]*]", RegexOption.IGNORE_CASE), "")
            .replace(Regex("作为(一个|一名)?\\s*(AI|人工智能|语言模型)[，,：:]?", RegexOption.IGNORE_CASE), "")
            .trim()
        if (mode == ChatMode.SOOTHING && Regex("首先|其次|最后|\\d+[.、]|你应该|你必须|快去|你可以试试|计划|学习|任务").containsMatchIn(text)) {
            return "听起来这会儿真的很难受。我在，愿意听你说。"
        }
        text = text.replace(Regex("(?m)^\\s*([-*]|\\d+[.、])\\s*"), "")
        if (mode == ChatMode.SOOTHING && text.count { it == '?' || it == '？' } > 1) {
            text = text.substringBefore('？').substringBefore('?') + "。"
        }
        val sentences = Regex("[^。！？.!?]+[。！？.!?]?").findAll(text).take(3).map { it.value }.toList()
        val result = StringBuilder()
        for (sentence in sentences) {
            if (result.length + sentence.length > 60) break
            result.append(sentence)
        }
        return result.toString().ifBlank {
            if (text.isBlank()) "我在，慢慢说。" else "我听到了。你想继续说说吗？"
        }
    }
}

package cn.edu.ruc.zhixing.companion.ai.openai

import cn.edu.ruc.zhixing.companion.ai.*
import cn.edu.ruc.zhixing.companion.ai.config.LlmConfigProvider
import cn.edu.ruc.zhixing.core.model.companion.LlmMsg
import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.http.*
import io.ktor.utils.io.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.serialization.json.*
import java.net.URI

/** HTTPS OpenAI 兼容 SSE 通道，关闭重定向，防止密钥被转发至其他站点。 */
class OpenAiLlmClient(
    private val config: LlmConfigProvider,
    private val sanitize: suspend (String) -> String,
) : LlmClient {
    private val client = HttpClient(OkHttp) {
        followRedirects = false
        install(HttpTimeout) { requestTimeoutMillis = 60000; connectTimeoutMillis = 15000; socketTimeoutMillis = 30000 }
    }

    override suspend fun chat(system: String, messages: List<LlmMsg>, tools: List<LlmTool>): LlmResult {
        val text = StringBuilder()
        val calls = mutableListOf<LlmEvent.ToolCall>()
        chatStream(system, messages, tools).collect {
            when (it) {
                is LlmEvent.Delta -> text.append(it.text)
                is LlmEvent.ToolCall -> calls.add(it)
                is LlmEvent.Done -> Unit
            }
        }
        return LlmResult(text.toString(), calls)
    }

    override fun chatStream(system: String, messages: List<LlmMsg>, tools: List<LlmTool>): Flow<LlmEvent> = flow {
        val settings = config.current()
        check(settings.allowCloud) { "云端理解未开启，请在设置中确认后开启。" }
        check(settings.apiKey.isNotBlank()) { "尚未填写 API Key，请前往设置。" }
        check(settings.model.isNotBlank()) { "尚未填写模型名称。" }
        val uri = runCatching { URI(settings.baseUrl.trim()) }.getOrNull()
        require(uri?.scheme == "https" && !uri.host.isNullOrBlank() && uri.userInfo == null && uri.query == null && uri.fragment == null) {
            "服务地址需为 HTTPS 地址，不能包含账号、查询参数或片段。"
        }
        val safeSystem = sanitize(system)
        val safeMessages = messages.map { it.copy(content = sanitize(it.content.orEmpty())) }
        val payload = buildJsonObject {
            put("model", settings.model); put("stream", true)
            putJsonArray("messages") {
                add(buildJsonObject { put("role", "system"); put("content", safeSystem) })
                for (message in safeMessages) add(buildJsonObject {
                    put("role", message.role); put("content", message.content.orEmpty())
                })
            }
            if (tools.isNotEmpty()) putJsonArray("tools") {
                tools.forEach { tool -> add(buildJsonObject {
                    put("type", "function")
                    putJsonObject("function") { put("name", tool.name); put("description", tool.description); put("parameters", tool.parameters) }
                }) }
            }
        }
        // 脱敏期间也可能撤回同意，因此在真正联网前再检查一次。
        check(config.current() == settings) { "模型配置或授权已改变，请重新发送。" }
        val decoder = SseDecoder()
        client.preparePost(settings.baseUrl.trim().trimEnd('/') + "/chat/completions") {
            bearerAuth(settings.apiKey); contentType(ContentType.Application.Json)
            accept(ContentType.Text.EventStream); setBody(payload.toString())
        }.execute { response ->
            check(response.status.value in 200..299) {
                when (response.status.value) {
                    401, 403 -> "模型认证失败，请检查 Key 和访问权限。"
                    429 -> "模型请求额度或频率受限，请稍后重试。"
                    else -> "模型服务暂时不可用（${response.status.value}）。"
                }
            }
            val channel = response.bodyAsChannel()
            while (!channel.isClosedForRead) {
                if (config.current() != settings) throw CancellationException("模型配置或授权已改变")
                val line = channel.readUTF8Line() ?: break
                for (event in decoder.line(line)) emit(event)
                if (decoder.finished) break
            }
            for (event in decoder.line("")) emit(event)
            check(decoder.finished) { "模型连接提前结束，请重试。" }
        }
    }.flowOn(Dispatchers.IO)
}

/** 按 SSE 事件边界组装文本及分片工具参数；不把元数据当作回复展示。 */
class SseDecoder {
    private val data = StringBuilder()
    private val calls = sortedMapOf<Int, Pair<StringBuilder, StringBuilder>>()
    private var reason: String? = null
    var finished = false
        private set
    fun line(line: String): List<LlmEvent> {
        if (finished) return emptyList()
        if (line.startsWith("data:")) {
            check(data.length + line.length <= 128000) { "模型事件过长。" }
            data.append(line.substring(5).trimStart()).append('\n'); return emptyList()
        }
        if (line.isNotEmpty() || data.isEmpty()) return emptyList()
        val value = data.toString().trim(); data.clear()
        if (value == "[DONE]") {
            finished = true
            return calls.values.map { LlmEvent.ToolCall(it.first.toString(), it.second.toString()) } + LlmEvent.Done(reason)
        }
        val root = Json.parseToJsonElement(value).jsonObject
        check(root["error"] == null) { "模型服务返回错误。" }
        val choice = root["choices"]?.jsonArray?.firstOrNull()?.jsonObject ?: return emptyList()
        reason = choice["finish_reason"]?.jsonPrimitive?.contentOrNull ?: reason
        val delta = choice["delta"]?.jsonObject ?: return emptyList()
        delta["tool_calls"]?.jsonArray?.forEach { item ->
            val obj = item.jsonObject
            val index = obj["index"]!!.jsonPrimitive.int
            check(index in 0..15) { "模型工具数量超限。" }
            val pair = calls.getOrPut(index) { StringBuilder() to StringBuilder() }
            val function = obj["function"]?.jsonObject
            pair.first.append(function?.get("name")?.jsonPrimitive?.contentOrNull.orEmpty())
            pair.second.append(function?.get("arguments")?.jsonPrimitive?.contentOrNull.orEmpty())
            check(pair.second.length <= 32000) { "模型工具结果过长。" }
        }
        return delta["content"]?.jsonPrimitive?.contentOrNull?.let { listOf(LlmEvent.Delta(it)) } ?: emptyList()
    }
}

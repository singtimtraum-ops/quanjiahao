package cn.edu.ruc.zhixing.companion.ai.emotion

import cn.edu.ruc.zhixing.core.model.companion.*

/** 规则优先识别危机；模型情绪标签不得降低本地危机等级。 */
class EmotionDetector {
    fun detect(text: String): EmotionLabel = when {
        listOf("自杀", "自伤", "不想活", "活着没意思", "活着好没意思", "结束生命", "伤害自己").any(text::contains) -> EmotionLabel.CRISIS
        listOf("崩溃", "撑不下去", "受不了").any(text::contains) -> EmotionLabel.OVERWHELMED
        listOf("累", "烦", "焦虑", "失眠", "睡不着", "不想", "算了", "压力").any(text::contains) -> EmotionLabel.STRESSED
        listOf("难过", "伤心", "孤独").any(text::contains) -> EmotionLabel.SAD
        listOf("开心", "考完", "成功", "好消息").any(text::contains) -> EmotionLabel.HAPPY
        else -> EmotionLabel.NEUTRAL
    }
}

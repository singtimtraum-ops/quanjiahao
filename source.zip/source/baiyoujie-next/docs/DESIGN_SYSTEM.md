# 设计系统

全局视觉由你负责，zzk 提供形象与美术资产。zzj 的日程页面必须使用同一套 MaterialTheme。

## 基础规则

- 页面背景、文字、按钮和状态颜色只从 MaterialTheme.colorScheme 获取。
- 除形象绘制外，不在页面中硬编码颜色。
- 普通卡片圆角不超过 8dp，不在卡片内部再嵌套装饰卡片。
- 工具操作优先使用标准图标；陌生图标必须有 contentDescription。
- 主页面保持可扫描、可重复操作，不使用营销式大标题或装饰性渐变。
- 所有页面最低检查约 320dp 宽，文字不得遮挡或截断关键字段。
- 公共控件放入 presentation/ui/.../components/，业务页面不得复制主题颜色。
- 全局主题仅由集成分支修改。zzk 在 docs/art/ 提交调色、字体和形象提案。

## 形象资源

- 目录使用 UI 模块的 drawable、font 或 raw。
- 命名使用 avatar_<mood>_<scene>_<variant>，全小写英文和下划线。
- 位图首选透明 WebP；大型源设计文件不打入 APK。
- 每个状态必须有 NEUTRAL 回退，资源缺失时不可崩溃或空白。
- 动画不得持有 Activity，离开页面后停止，并尊重系统减少动态效果设置。
- 美术提交附主页白天、夜间和 320dp 宽三张截图。

## 页面职责

- features/chat/：你负责对话列表、输入、流式状态和确认卡片。
- features/schedule/：zzj 负责日历、日程、课表和消息建议展示。
- avatar/：zzk 负责形象绘制与动画，不包含导航和业务数据读取。
- CompanionScaffold.kt：只保留导航和跨页面接线，由集成 Agent 管理。

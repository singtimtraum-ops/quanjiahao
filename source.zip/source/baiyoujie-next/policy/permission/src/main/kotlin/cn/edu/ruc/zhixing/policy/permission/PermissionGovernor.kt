package cn.edu.ruc.zhixing.policy.permission

import android.content.Context
import android.content.SharedPreferences
import cn.edu.ruc.zhixing.core.model.SourceQuality

/**
 * 权限与合规治理中心。
 *
 * 统一管理三层采集的授权状态与“是否已同意协议”，供 UI 展示开关、供采集层在
 * 启动前校验。遵循最小化采集原则：
 *  - 通知层：默认（需授予通知使用权）
 *  - 无障碍增强：默认关闭，用户显式开启
 *  - Root 取库：默认关闭，且需同意强提示
 */
class PermissionGovernor(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("zhixing_policy", Context.MODE_PRIVATE)

    fun hasConsent(quality: SourceQuality): Boolean = when (quality) {
        // 通知采集也必须由用户显式同意，不把系统权限等同于产品同意。
        SourceQuality.NOTIFICATION -> prefs.getBoolean(KEY_CONSENT_NOTIFY, false)
        // 高级采集默认关闭：需用户显式同意后才开启。
        SourceQuality.ACCESSIBILITY -> prefs.getBoolean(KEY_CONSENT_ACCESS, false)
        SourceQuality.DATABASE -> prefs.getBoolean(KEY_CONSENT_DB, false)
    }

    fun grantConsent(quality: SourceQuality) {
        val key = when (quality) {
            SourceQuality.NOTIFICATION -> KEY_CONSENT_NOTIFY
            SourceQuality.ACCESSIBILITY -> KEY_CONSENT_ACCESS
            SourceQuality.DATABASE -> KEY_CONSENT_DB
        }
        prefs.edit().putBoolean(key, true).apply()
    }

    fun revokeConsent(quality: SourceQuality) {
        val key = when (quality) {
            SourceQuality.NOTIFICATION -> KEY_CONSENT_NOTIFY
            SourceQuality.ACCESSIBILITY -> KEY_CONSENT_ACCESS
            SourceQuality.DATABASE -> KEY_CONSENT_DB
        }
        prefs.edit().putBoolean(key, false).apply()
    }

    /** 是否允许云端处理（默认 false = 全部本机）。 */
    var allowCloud: Boolean
        get() = prefs.getBoolean(KEY_CLOUD, false)
        set(v) = prefs.edit().putBoolean(KEY_CLOUD, v).apply()

    /** 记录一条采集审计日志（供用户查看/导出）。 */
    fun recordAudit(event: AuditEvent) {
        // TODO: 落盘到本地审计表，暴露「数据导出/清除」入口
    }

    data class AuditEvent(
        val quality: SourceQuality,
        val channel: String,
        val timestamp: Long,
        val summary: String,
    )

    companion object {
        private const val KEY_CONSENT_NOTIFY = "consent_notify"
        private const val KEY_CONSENT_ACCESS = "consent_access"
        private const val KEY_CONSENT_DB = "consent_db"
        private const val KEY_CLOUD = "allow_cloud"
    }
}

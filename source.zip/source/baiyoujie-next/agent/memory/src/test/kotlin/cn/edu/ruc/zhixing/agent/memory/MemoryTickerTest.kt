package cn.edu.ruc.zhixing.agent.memory

import cn.edu.ruc.zhixing.core.model.memory.*
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class MemoryTickerTest {
    @Test fun expiresOnlyWhenEventEnds() = runBlocking {
        val items = mutableListOf(
            MemoryItem("future", MemoryType.EVENT, "下午组会", 15000, 16000, source = "chat", createdAt = 0),
            MemoryItem("past", MemoryType.EVENT, "已经结束", 1000, 2000, source = "chat", createdAt = 0),
            MemoryItem("fact", MemoryType.FACT, "偏好", endTime = 1, source = "chat", createdAt = 0),
        )
        val store = object : MemoryStore {
            override suspend fun add(item: MemoryItem) { items.add(item) }
            override suspend fun active(now: Long, limit: Int) = items.filter { it.status == MemoryStatus.ACTIVE }.take(limit)
            override suspend fun expirableEvents(now: Long) = items.toList()
            override suspend fun updateStatus(id: String, status: MemoryStatus) { val i = items.indexOfFirst { it.id == id }; items[i] = items[i].copy(status = status) }
        }
        MemoryTicker(store).tick(3000)
        assertEquals(MemoryStatus.ACTIVE, items[0].status)
        assertEquals(MemoryStatus.EXPIRED, items[1].status)
        assertEquals(MemoryStatus.ACTIVE, items[2].status)
        MemoryTicker(store).tick(16000)
        assertEquals(MemoryStatus.EXPIRED, items[0].status)
    }
}

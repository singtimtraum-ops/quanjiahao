package cn.edu.ruc.zhixing.agent.memory

import cn.edu.ruc.zhixing.core.model.memory.*

/** 存储接口，Android Room 实现在基础设施层提供。 */
interface MemoryStore {
    suspend fun add(item: MemoryItem)
    suspend fun active(now: Long, limit: Int = 10): List<MemoryItem>
    suspend fun expirableEvents(now: Long): List<MemoryItem>
    suspend fun updateStatus(id: String, status: MemoryStatus)
}
/** 只依据结束时间流转，不在午夜提前结束未来事件。 */
class MemoryTicker(private val store: MemoryStore) {
    suspend fun tick(now: Long) {
        store.expirableEvents(now).forEach {
            val end = it.endTime
            if (it.type == MemoryType.EVENT && it.status == MemoryStatus.ACTIVE && end != null && end <= now) {
                store.updateStatus(it.id, MemoryStatus.EXPIRED)
            }
        }
    }
}

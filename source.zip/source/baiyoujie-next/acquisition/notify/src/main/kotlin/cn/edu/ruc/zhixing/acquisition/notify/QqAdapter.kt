package cn.edu.ruc.zhixing.acquisition.notify

import cn.edu.ruc.zhixing.core.model.Channel

/** QQ 通知解析器。结构上与微信相近，预留差异点。 */
class QqAdapter : AbstractChatAdapter() {
    override val channel: Channel = Channel.QQ

    override fun detectGroup(title: String, body: String): Boolean =
        title.contains("群") || body.contains("[") || body.startsWith("来自")

    override fun extractSender(title: String, body: String, isGroup: Boolean): String {
        if (!isGroup) return title
        val m = Regex("^(.+?):").find(body)
        return m?.groupValues?.getOrNull(1)?.takeIf { it.isNotEmpty() } ?: title
    }
}

package cn.edu.ruc.zhixing.acquisition.notify

import cn.edu.ruc.zhixing.core.model.Channel

/** 微信通知解析器。 */
class WeChatAdapter : AbstractChatAdapter() {
    override val channel: Channel = Channel.WECHAT

    override fun detectGroup(title: String, body: String): Boolean =
        // 微信群通知：标题为群名，正文通常以发送者名+冒号开头
        (title.length < 20 && !body.startsWith(title)) ||
            body.matches(Regex("^\\[.+?].*"))

    override fun extractSender(title: String, body: String, isGroup: Boolean): String {
        if (!isGroup) return title
        val m = Regex("^\\[(.+?)]|^(.+?):").find(body)
        return m?.groupValues?.getOrNull(1).orEmpty()
            .ifEmpty { m?.groupValues?.getOrNull(2).orEmpty() }
            .ifEmpty { title }
    }
}

package cn.edu.ruc.zhixing.acquisition.notify

import cn.edu.ruc.zhixing.core.model.Channel

/** 系统短信解析器（在通知里走 channel 为 SMS）。 */
class SmsAdapter : AbstractChatAdapter() {
    override val channel: Channel = Channel.SMS
}

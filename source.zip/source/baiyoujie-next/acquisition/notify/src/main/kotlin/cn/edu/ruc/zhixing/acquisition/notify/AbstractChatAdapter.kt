package cn.edu.ruc.zhixing.acquisition.notify

import cn.edu.ruc.zhixing.acquisition.api.ChatAdapter
import cn.edu.ruc.zhixing.core.model.ChatMessage
import cn.edu.ruc.zhixing.core.model.SourceQuality
import java.security.MessageDigest

/**
 * 通知解析器的公共逻辑：生成稳定 id、判断群聊、兜底字段。
 * 各 App 继承它，只需实现各自的字段提取差异。
 */
abstract class AbstractChatAdapter : ChatAdapter {

    override fun parse(
        packageName: String,
        title: String?,
        text: String?,
        extras: Map<String, Any?>,
        timestamp: Long,
        quality: SourceQuality,
    ): ChatMessage? {
        val t = title?.trim().orEmpty()
        val body = text?.trim().orEmpty()
        if (t.isEmpty() && body.isEmpty()) return null
        if (isSystemNoise(t, body)) return null

        val isGroup = detectGroup(t, body)
        val senderName = extractSender(t, body, isGroup)
        val senderId = senderName

        return ChatMessage(
            id = stableId(channel.name, packageName, senderName, body, timestamp.toString()),
            channel = channel,
            senderId = senderId,
            senderName = senderName.ifEmpty { "未知" },
            isGroup = isGroup,
            content = body.ifEmpty { t },
            timestamp = timestamp,
            isSelf = false,
            quality = quality,
            raw = "title=$t|text=$body",
        )
    }

    protected open fun detectGroup(title: String, body: String): Boolean =
        title.contains("群") && title.length < 20

    protected open fun extractSender(title: String, body: String, isGroup: Boolean): String {
        // 群聊：正文常为 "发送者: 内容" 或 "[发送者] 内容"
        if (isGroup) {
            val m = Regex("^\\[(.+?)]|^(.+?):").find(body)
            return m?.groupValues?.getOrNull(1).orEmpty().ifEmpty { m?.groupValues?.getOrNull(2).orEmpty() }
                .ifEmpty { title }
        }
        return title
    }

    /** 过滤明显的系统/广告类噪音（如 "正在输入…"、"某某加入了群聊"）。 */
    protected open fun isSystemNoise(title: String, body: String): Boolean {
        val noiseCues = listOf("正在输入", "加入了群聊", "撤回了一条消息", "微信支付", "验证码")
        return noiseCues.any { body.contains(it) || title.contains(it) }
    }

    private fun stableId(vararg parts: String): String =
        md5(parts.joinToString("|"))

    private fun md5(s: String): String = MessageDigest.getInstance("MD5")
        .digest(s.toByteArray())
        .joinToString("") { "%02x".format(it) }
}

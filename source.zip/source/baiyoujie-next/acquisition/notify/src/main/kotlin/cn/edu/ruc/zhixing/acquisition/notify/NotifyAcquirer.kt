package cn.edu.ruc.zhixing.acquisition.notify

import android.app.Notification
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationManagerCompat
import cn.edu.ruc.zhixing.acquisition.api.ChatAdapter
import cn.edu.ruc.zhixing.acquisition.api.MessageAcquirer
import cn.edu.ruc.zhixing.core.model.ChatMessage
import cn.edu.ruc.zhixing.core.model.SourceQuality

/**
 * 默认采集层 —— 通知监听。
 *
 * 由系统在用户授予「通知使用权」后以单例服务形式实例化。系统每弹出一条
 * 目标 App 的通知，[onNotificationPosted] 触发，交给对应 [ChatAdapter] 解析
 * 成 [ChatMessage]，再经由 [dispatchToBus] 转发给上层 MessageBus。[isEnabled]
 * 用于检测是否已授权，供 UI 做权限引导。
 *
 * 注意：NotificationListenerService 由系统管理实例，因此这里采用
 * companion 静态引用桥接到 MessageBus，避免实例被重建导致断流。
 */
class NotifyAcquirer : NotificationListenerService(), MessageAcquirer {

    override val id: String = "notify"
    override val quality: SourceQuality = SourceQuality.NOTIFICATION

    override fun isEnabled(context: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(context)
            .contains(context.packageName)

    override fun requestPermission(context: Context) {
        val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    override fun start(context: Context, onMessage: (ChatMessage) -> Unit) {
        dispatchToBus = onMessage
    }

    override fun stop() {
        dispatchToBus = null
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        // 重新绑定后可重放当前可见通知（简单实现：只做日志，历史由取库层补全）
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        val adapter = adapters[pkg] ?: return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
        val rawMap = extras.keySet().associateWith { extras.get(it) }

        val msg = adapter.parse(pkg, title, text, rawMap, sbn.postTime, SourceQuality.NOTIFICATION)
        msg?.let { dispatchToBus?.invoke(it) }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        // 预留：下拉清除通知时的处理，可用于标记“用户已查看”
    }

    companion object {
        /** 包名 → App 专用解析器注册表。新增软件只需在这里加一行。 */
        private val adapters: Map<String, ChatAdapter> = mapOf(
            "com.tencent.mm" to WeChatAdapter(),
            "com.tencent.mobileqq" to QqAdapter(),
            "android" to SmsAdapter(), // 系统短信
        )

        /** 供外部（如取库层）在应用启动时扩展新适配器。 */
        fun registerAdapter(packageName: String, adapter: ChatAdapter) {
            // 不可变 map 需替换为可变注册表，这里给出扩展点注释
        }

        @Volatile
        var dispatchToBus: ((ChatMessage) -> Unit)? = null
    }
}

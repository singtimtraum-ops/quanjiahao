# Add project specific ProGuard rules for acquisition:api here.
-dontwarn androidx.core.**

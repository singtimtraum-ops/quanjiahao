package cn.edu.ruc.zhixing.acquisition.api

import cn.edu.ruc.zhixing.core.model.Channel
import cn.edu.ruc.zhixing.core.model.ChatMessage
import cn.edu.ruc.zhixing.core.model.SourceQuality

/**
 * 单个聊天软件的消息解析器。
 *
 * 不同 App 的通知 / 界面结构不同，但都统一落到 [ChatMessage]。
 * 例如 WeChat 与 QQ 的 group 判断、字段提取逻辑不同，各自实现一个 adapter，
 * 通过 Map<Channel, ChatAdapter> 注册到 [NotifyAcquirer]。
 */
interface ChatAdapter {

    val channel: Channel

    /**
     * @param packageName 目标 App 的包名（可用于二次校验）。
     * @param title 通知标题（通常为发送者名或群名）。
     * @param text 通知正文。
     * @param extras 通知原始扩展字段（不同 App 结构不同）。
     * @return 解析后的消息；若本条不属于本 adapter（如系统类通知）返回 null。
     */
    fun parse(
        packageName: String,
        title: String?,
        text: String?,
        extras: Map<String, Any?>,
        timestamp: Long,
        quality: SourceQuality,
    ): ChatMessage?
}

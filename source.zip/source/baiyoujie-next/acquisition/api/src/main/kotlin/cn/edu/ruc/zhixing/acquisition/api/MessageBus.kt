package cn.edu.ruc.zhixing.acquisition.api

import android.content.Context
import cn.edu.ruc.zhixing.core.model.ChatMessage
import cn.edu.ruc.zhixing.core.model.SourceQuality
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * 采集汇流总线。
 *
 * 各采集层（通知 / 无障碍 / 取库）把消息投递到此处，
 * 这里完成：跨层去重 → 高质量覆盖 → 按 id 排序 → 以 [messages] 暴露给分类引擎。
 *
 * **启动判定**：一个采集器只有同时满足
 *   1. 系统权限就绪 `isEnabled()` 且
 *   2. 用户已同意（[consentCheck]，来自 PermissionGovernor）
 * 才会被启动（即真正开始回调投递消息）。
 *
 * **幂等启动**：`start()`/`register()` 可被重复调用（例如授权从系统设置返回后
 * 再次检查），已启动的采集器不会重复拉活，但对“新变为满足条件”的采集器会补充启动，
 * 从而避免“页面显示已开启但收不到消息”。
 */
class MessageBus(private val deduplicator: MessageDeduplicator = MessageDeduplicator()) {

    private val _messages = MutableSharedFlow<ChatMessage>(extraBufferCapacity = 256)
    val messages: SharedFlow<ChatMessage> = _messages.asSharedFlow()

    private val acquirers = mutableListOf<MessageAcquirer>()
    private val startedAcquirers = mutableSetOf<String>()
    private var started = false

    private var consentCheck: (SourceQuality) -> Boolean = { false }

    /** 注入“是否已同意”判定（来自 PermissionGovernor）。 */
    fun setConsentCheck(block: (SourceQuality) -> Boolean) {
        consentCheck = block
    }

    /** 注册采集器。若总线已启动且该采集器已满足条件，则立即拉活。 */
    fun register(acquirer: MessageAcquirer) {
        acquirers.add(acquirer)
        if (started) maybeStart(acquirer)
    }

    fun start(context: Context) {
        applicationContext = context.applicationContext
        started = true
        acquirers.forEach { maybeStart(it) }
    }

    fun stop() {
        acquirers.forEach { it.stop() }
        startedAcquirers.clear()
        started = false
    }

    /** 供各个采集层回调投递消息。 */
    fun emit(msg: ChatMessage) {
        if (!consentCheck(msg.quality)) return
        val key = "${msg.channel}:${msg.id}"
        val ok = deduplicator.shouldProcess(key, msg.quality.name, msg.timestamp)
        if (!ok) return
        _messages.tryEmit(msg)
    }

    /**
     * 判定并（首次）拉活某个采集器。可重复调用：
     * - 未同意 → 跳过（合规：高级采集默认关闭）
     * - 未具备系统权限 → 跳过
     * - 已启动过 → 不再重复拉活（避免 Root 取库重复导入）
     * - 新满足条件 → 启动
     */
    private fun maybeStart(acquirer: MessageAcquirer) {
        if (!consentCheck(acquirer.quality)) {
            if (startedAcquirers.remove(acquirer.id)) acquirer.stop()
            zhixingLog("skipped ${acquirer.id}: not consented")
            return
        }
        if (!acquirer.isEnabled(applicationContext)) {
            if (startedAcquirers.remove(acquirer.id)) acquirer.stop()
            zhixingLog("skipped ${acquirer.id}: permission not granted")
            return
        }
        if (startedAcquirers.add(acquirer.id)) {
            zhixingLog("started ${acquirer.id}")
            acquirer.start(applicationContext, ::emit)
        }
    }

    private fun zhixingLog(msg: String) {
        android.util.Log.i("MessageBus", msg)
    }

    private lateinit var applicationContext: Context
}

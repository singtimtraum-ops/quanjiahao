package cn.edu.ruc.zhixing.acquisition.api

import android.content.Context
import cn.edu.ruc.zhixing.core.model.ChatMessage
import cn.edu.ruc.zhixing.core.model.SourceQuality

/**
 * 数据源采集器的统一契约 —— 模块化的核心接口。
 *
 * 三个采集层（通知 / 无障碍 / Root 取库）各自实现本接口，
 * 并通过 [MessageBus.register] 注册，上层分类引擎对它们无感知。
 * 新增数据源（新的聊天软件 / 新的采集方式）时只需新写一个实现，
 * 不需要改动分类、存储、UI。
 */
interface MessageAcquirer {

    /** 采集器唯一标识，用于日志与配置开关（如 "notify.wechat"）。 */
    val id: String

    /** 本采集层的数据完整度。 */
    val quality: SourceQuality

    /** 是否需要用户显式开启（用于 UI 判断是否展示开关）。 */
    val requiresUserOptIn: Boolean get() = true

    /** 当前是否具备采集条件（通知权限已授予 / 已 Root 等）。 */
    fun isEnabled(context: Context): Boolean

    /** 启动采集。onMessage 回调交给 MessageBus 去重后统一分发。 */
    fun start(context: Context, onMessage: (ChatMessage) -> Unit)

    /** 停止采集。 */
    fun stop()

    /** 主动申请运行所需权限（由 app 在合适时机调用）。 */
    fun requestPermission(context: Context) {}
}

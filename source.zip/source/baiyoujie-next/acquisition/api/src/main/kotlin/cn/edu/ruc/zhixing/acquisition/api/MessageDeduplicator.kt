package cn.edu.ruc.zhixing.acquisition.api

import java.util.concurrent.ConcurrentHashMap

/**
 * 全局去重器。
 *
 * 同一句消息可能被「通知层」与「无障碍层」各上报一次；
 * 同一会话在时间窗内可能有多条连续消息。这里按 `id + 时间窗` 去重，
 * 且遵循“**高质量覆盖低质量**”原则：当同 id 出现更高 quality 的消息时，
 * 用高质量数据替换并返回 true 以便重新分类；否则视为重复忽略。
 */
class MessageDeduplicator(private val maxEntries: Int = 20_000) {

    private data class Entry(val rank: Int, val ts: Long)

    private val cache = ConcurrentHashMap<String, Entry>()

    private val qualityRank = mapOf(
        "NOTIFICATION" to 1,
        "ACCESSIBILITY" to 2,
        "DATABASE" to 3,
    )

    /**
     * 尝试登记一条消息。
     * @return true = 应当继续处理（新消息或高质量替换）；false = 重复，忽略。
     */
    fun shouldProcess(key: String, quality: String, timestamp: Long): Boolean {
        val rank = qualityRank[quality] ?: 0
        if (cache.size > maxEntries) cache.clear()

        val prev = cache[key]
        if (prev == null) {
            cache[key] = Entry(rank, timestamp)
            return true
        }
        // 更高质量覆盖
        if (rank > prev.rank) {
            cache[key] = Entry(rank, timestamp)
            return true
        }
        // 同一质量、同一时间窗内（如 2 秒）视为重复
        return timestamp - prev.ts > 2_000L
    }
}

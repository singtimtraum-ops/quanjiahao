plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.serialization)
}

android {
    namespace = "cn.edu.ruc.zhixing.acquisition.db"
    compileSdk = 35

    defaultConfig { minSdk = 26 }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // 仅取库层用得到，且默认不启用（避免无 Root 设备报错）。
    packagingOptions {
        jniLibs { useLegacyPackaging = true }
    }
}

dependencies {
    api(project(":acquisition:api"))
    implementation(libs.androidx.core.ktx)
    implementation(libs.kotlinx.coroutines.android)
    // 解密微信加密库时使用；未部署 Root 层可不引入，标注为可选。
    implementation(libs.sqlcipher.android)
    implementation(libs.androidx.sqlite)
}

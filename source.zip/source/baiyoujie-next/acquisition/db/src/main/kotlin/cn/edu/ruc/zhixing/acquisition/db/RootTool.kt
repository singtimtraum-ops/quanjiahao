package cn.edu.ruc.zhixing.acquisition.db

import java.io.File
import java.io.FileOutputStream

/**
 * Root 探测与库文件拷贝。
 *
 * 说明：读取微信数据库需要 Root（或等效 shell+SELinux 放行）权限。此处仅提供
 * 前置探测与拷贝骨架，具体路径与密钥推导因微信版本而异，需在实际设备上适配。
 * 本模块默认不激活，属“自用/内测”高级层。
 */
object RootTool {

    data class DeviceInfo(val isRoot: Boolean, val shellAvailable: Boolean)

    fun probe(): DeviceInfo {
        val isRoot = run("su -c id").isNullOrEmpty().not() && run("su -c id")?.contains("uid=0") == true
        val shell = run("id").isNullOrEmpty().not()
        return DeviceInfo(isRoot, shell)
    }

    /** 微信聊天数据库常见位置（需按版本适配 md5 目录）。 */
    const val WECHAT_DB_DIR: String = "/data/user/0/com.tencent.mm/MicroMsg"

    /** 拷贝加密库到应用私有目录（需 Root + SELinux 放行）。 */
    fun copyDb(context: android.content.Context, remote: String, localName: String): File? {
        val local = File(context.filesDir, localName)
        val result = run("su -c cp '$remote' '${local.absolutePath}'")
        return if (result?.contains("cannot") == true) null else local
    }

    /** 执行 shell 命令（Root 层使用 su）。 */
    private fun run(cmd: String): String? = try {
        val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (e: Exception) {
        null
    }
}

package cn.edu.ruc.zhixing.acquisition.db

import android.content.Context
import cn.edu.ruc.zhixing.acquisition.api.MessageAcquirer
import cn.edu.ruc.zhixing.core.model.ChatMessage
import cn.edu.ruc.zhixing.core.model.Channel
import cn.edu.ruc.zhixing.core.model.SourceQuality
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Root 取库层 —— 一次性导入历史消息。
 *
 * 与通知/无障碍的“实时流”不同，这里是“批量导入”。它读取并解密微信库，
 * 把历史会话映射成像一条条 [ChatMessage]（quality=DATABASE）投递给 MessageBus。
 *
 * 安全与合规：此层需要 Root，仅应在用户显式开启「导入历史」且同意协议后运行；
 * 原文默认只落本地数据库，不上云。
 */
class DbAcquirer : MessageAcquirer {

    override val id: String = "db"
    override val quality: SourceQuality = SourceQuality.DATABASE

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var callback: ((ChatMessage) -> Unit)? = null

    override fun isEnabled(context: Context): Boolean =
        RootTool.probe().isRoot

    override fun start(context: Context, onMessage: (ChatMessage) -> Unit) {
        callback = onMessage
        scope.launch { importHistory(context) }
    }

    override fun stop() {
        callback = null
    }

    override fun requestPermission(context: Context) {
        // Root 属系统级权限，无法由 App 直接申请；仅提示用户自行确认。
    }

    private suspend fun importHistory(context: Context) {
        if (!isEnabled(context)) {
            zhixingLog("Root 未开启，跳过取库。")
            return
        }
        // 1. 拷贝库文件（路径需按微信版本适配）
        val remote = "${RootTool.WECHAT_DB_DIR}/<md5_uin>/EnMicroMsg.db"
        // val local = RootTool.copyDb(context, remote, "EnMicroMsg.db") ?: return

        // 2. 推导密钥（MD5(...) 取前 7 位 + 固定盐）—— 需按版本适配
        // 3. 用 SQLCipher 打开并读取 message 表 → 逐条映射为 ChatMessage
        // val db = openDecryptedDb(context, local, passphrase)
        // db.rawQuery("SELECT talker, content, isSend, createTime, type FROM message ...")
        //    .forEach { callback?.invoke(chatMessageFromRow(it)) }

        zhixingLog("取库导入骨架已就绪，需在真机适配微信库路径与密钥。")
    }

    private fun openDecryptedDb(context: Context, file: java.io.File, passphrase: String) {
        // TODO(适配层): 使用 net.zetetic.database.sqlcipher.SQLiteDatabase 打开并 PRAGMA key 解密。
    }

    private fun chatMessageFromRow(row: android.database.Cursor): ChatMessage =
        ChatMessage(
            id = "db-${row.getLong(4)}",
            channel = Channel.WECHAT,
            senderId = row.getString(0) ?: "",
            senderName = row.getString(0) ?: "",
            isGroup = false,
            content = row.getString(1) ?: "",
            timestamp = row.getLong(3),
            isSelf = row.getInt(2) == 1,
            quality = SourceQuality.DATABASE,
            raw = "type=${row.getInt(4)}",
        )

    private fun zhixingLog(m: String) {
        android.util.Log.i("DbAcquirer", m)
    }
}

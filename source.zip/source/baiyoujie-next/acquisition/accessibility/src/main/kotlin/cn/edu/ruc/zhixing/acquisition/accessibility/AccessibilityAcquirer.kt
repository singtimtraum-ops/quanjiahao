package cn.edu.ruc.zhixing.acquisition.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import cn.edu.ruc.zhixing.acquisition.api.MessageAcquirer
import cn.edu.ruc.zhixing.core.model.ChatMessage
import cn.edu.ruc.zhixing.core.model.Channel
import cn.edu.ruc.zhixing.core.model.SourceQuality
import cn.edu.ruc.zhixing.core.common.time.TimeKt

/**
 * 可选增强层 —— 无障碍读屏。
 *
 * 系统在用户开启服务后实例化。此层能拿到通知监听看不到的、当前屏内可见的
 * 更多正文，从而提升分类精度。**默认关闭**，由用户在 App 内显式开启。
 * 与通知层的消息由上层 MessageBus 统一去重合并（此层 quality 更高，同 id 会覆盖）。
 */
class AccessibilityAcquirer : AccessibilityService(), MessageAcquirer {

    override val id: String = "accessibility"
    override val quality: SourceQuality = SourceQuality.ACCESSIBILITY
    override val requiresUserOptIn: Boolean = true

    override fun isEnabled(context: Context): Boolean {
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
        ) ?: return false
        return enabled.split(':')
            .any { it.equals(context.packageName + "/" + javaClass.name, true) }
    }

    override fun requestPermission(context: Context) {
        context.startActivity(
            android.content.Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }

    override fun start(context: Context, onMessage: (ChatMessage) -> Unit) {
        dispatchToBus = onMessage
    }

    override fun stop() {
        dispatchToBus = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg !in TARGET_PACKAGES) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED
        ) return

        val text = event.text?.joinToString("\n")?.trim().orEmpty()
        if (text.isEmpty()) return

        val channel = when (pkg) {
            "com.tencent.mm" -> Channel.WECHAT
            "com.tencent.mobileqq" -> Channel.QQ
            else -> Channel.OTHER
        }

        val msg = ChatMessage(
            id = "acc-$pkg-${event.source?.hashCode()}-${TimeKt.nowMillis()}",
            channel = channel,
            senderId = "",
            senderName = "",
            isGroup = pkg == "com.tencent.mobileqq" || text.contains("群"),
            content = text,
            timestamp = TimeKt.nowMillis(),
            quality = SourceQuality.ACCESSIBILITY,
            raw = "event=$pkg",
        )
        dispatchToBus?.invoke(msg)
    }

    override fun onInterrupt() {
        // 系统中断无障碍服务时回调
    }

    companion object {
        private val TARGET_PACKAGES = setOf("com.tencent.mm", "com.tencent.mobileqq", "com.alibaba.android.rimet")

        @Volatile
        var dispatchToBus: ((ChatMessage) -> Unit)? = null
    }
}

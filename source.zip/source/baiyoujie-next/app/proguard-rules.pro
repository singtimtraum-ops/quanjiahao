# Add project specific ProGuard rules here.
# 若启用 minify，保留用于反射/序列化的类（示例）。
# -keep class cn.edu.ruc.zhixing.core.model.** { *; }

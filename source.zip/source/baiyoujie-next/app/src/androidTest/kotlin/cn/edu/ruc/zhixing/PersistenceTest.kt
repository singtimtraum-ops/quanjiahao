package cn.edu.ruc.zhixing

import androidx.room.Room
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import cn.edu.ruc.zhixing.core.model.planner.*
import cn.edu.ruc.zhixing.planner.calendar.CourseRepository
import cn.edu.ruc.zhixing.storage.room.*
import cn.edu.ruc.zhixing.storage.room.chat.ChatTurnEntity
import cn.edu.ruc.zhixing.storage.room.planner.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.util.UUID

/** 所有测试只操作随机命名的临时数据库，不清除应用实际数据库。 */
@RunWith(AndroidJUnit4::class)
class PersistenceTest {
    private val context get() = InstrumentationRegistry.getInstrumentation().targetContext
    private fun open(name: String) = Room.databaseBuilder(context, AppDatabase::class.java, name)
        .addMigrations(CompanionMigrations.FROM_1, CompanionMigrations.FROM_2, CompanionMigrations.FROM_3, CompanionMigrations.FROM_4).build()
    private suspend fun isolated(block: suspend (AppDatabase) -> Unit) {
        val name = "verification-${UUID.randomUUID()}.db"
        val db = open(name)
        try { block(db) } finally { db.close(); context.deleteDatabase(name) }
    }
    @Test fun migrationsPreserveOriginalMessagesAndFeedback() = runBlocking {
        for (version in 1..4) {
            val name = "migration-v$version-${UUID.randomUUID()}.db"
            val helper = FrameworkSQLiteOpenHelperFactory().create(SupportSQLiteOpenHelper.Configuration.builder(context).name(name)
                .callback(object : SupportSQLiteOpenHelper.Callback(version) {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        db.execSQL("CREATE TABLE message (id TEXT NOT NULL PRIMARY KEY, channel TEXT NOT NULL, senderId TEXT NOT NULL, senderName TEXT NOT NULL, isGroup INTEGER NOT NULL, content TEXT NOT NULL, timestamp INTEGER NOT NULL, isSelf INTEGER NOT NULL, quality TEXT NOT NULL, level TEXT NOT NULL, score REAL NOT NULL, category TEXT NOT NULL, reason TEXT NOT NULL)")
                        db.execSQL("CREATE INDEX index_message_channel_timestamp ON message(channel, timestamp)")
                        db.execSQL("CREATE INDEX index_message_channel_senderId ON message(channel, senderId)")
                        db.execSQL("INSERT INTO message VALUES ('legacy', 'WECHAT', 'person', '测试用户', 0, '升级前消息', 1, 0, 'NOTIFICATION', 'P1_IMPORTANT', 0.8, 'OTHER', 'test')")
                        if (version >= 2) {
                            CompanionMigrations.FROM_1.migrate(db)
                            db.execSQL("INSERT INTO feedback VALUES (1, 'legacy', 'WECHAT', '测试用户', '升级前消息', 0, 1.0, 1)")
                        }
                        if (version >= 3) {
                            CompanionMigrations.FROM_2.migrate(db)
                            db.execSQL("INSERT INTO chat_turn VALUES ('old-chat','default','USER','升级前对话','NEUTRAL',1,'2030-01-01',NULL)")
                        }
                        if (version >= 4) CompanionMigrations.FROM_3.migrate(db)
                    }
                    override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
                }).build())
            helper.writableDatabase
            helper.close()
            val db = open(name)
            try {
                assertEquals("升级前消息", db.messageDao().getById("legacy")?.content)
                assertEquals(5, db.openHelper.writableDatabase.version)
                if (version >= 2) db.openHelper.readableDatabase.query("SELECT COUNT(*) FROM feedback").use { it.moveToFirst(); assertEquals(1, it.getInt(0)) }
                if (version >= 3) assertEquals("升级前对话", db.chatDao().recent(1).single().content)
                assertNull(db.coursePlanDao().observe().first())
            } finally { db.close(); context.deleteDatabase(name) }
        }
    }
    @Test fun confirmationIsConcurrentAndIdempotent() = runBlocking {
        isolated { db ->
            val row = SuggestionEntity("todo-1", "s", "CHAT", "TODO", "原始标题", null, null, 2000, null, "PENDING", 1000)
            db.suggestionDao().insert(row)
            val repository = SuggestionRepository(db)
            coroutineScope { repeat(10) { launch(Dispatchers.IO) { repository.confirm(row.id, "修改标题") } } }
            assertEquals(1, db.todoDao().observeAll().first().size)
            assertEquals("修改标题", db.todoDao().observeAll().first().single().title)
            assertEquals("修改标题", db.suggestionDao().get(row.id)?.title)
            assertEquals("ACCEPTED", db.suggestionDao().get(row.id)?.status)
        }
    }
    @Test fun dismissedSuggestionCannotBeConfirmed() = runBlocking {
        isolated { db ->
            db.suggestionDao().insert(SuggestionEntity("s1", "source", "CHAT", "TODO", "事项", null, null, null, null, "PENDING", 1))
            val repository = SuggestionRepository(db)
            repository.dismiss("s1"); repository.confirm("s1", "事项")
            assertTrue(db.todoDao().observeAll().first().isEmpty())
            assertEquals("DISMISSED", db.suggestionDao().get("s1")?.status)
        }
    }
    @Test fun invalidEventRollsBackAcceptance() = runBlocking {
        isolated { db ->
            db.suggestionDao().insert(SuggestionEntity("s1", "source", "CHAT", "EVENT", "事项", 2, 1, null, null, "PENDING", 1))
            try { SuggestionRepository(db).confirm("s1", "事项"); fail("Invalid event accepted") } catch (_: IllegalArgumentException) { }
            assertEquals("PENDING", db.suggestionDao().get("s1")?.status)
            assertTrue(db.scheduleDao().observeAll().first().isEmpty())
        }
    }
    @Test fun courseRegenerationPreservesManualEventsAndHasNoDuplicates() = runBlocking {
        isolated { db ->
            db.scheduleDao().upsert(ScheduleEntity("manual", "手动日程", 1, 2, null, null, "MANUAL", "UPCOMING", 0))
            val plan = CoursePlan("2030-09-02", 4, "Asia/Shanghai", listOf(LessonSlot(1, "08:00", "08:45")),
                listOf(Course("c1", "课程", 1, 1, 1, 1, 4)))
            val repo = CourseRepository(db)
            assertEquals(4, repo.save(plan)); assertEquals(4, repo.save(plan))
            assertEquals(5, db.scheduleDao().observeAll().first().size)
            repo.save(plan.copy(courses = emptyList()))
            assertEquals("manual", db.scheduleDao().observeAll().first().single().id)
        }
    }
    @Test fun chatAndSuggestionSurviveDatabaseReopen() = runBlocking {
        val name = "reopen-${UUID.randomUUID()}.db"
        var db = open(name)
        try {
            db.chatDao().insert(ChatTurnEntity("turn", "default", "USER", "本地测试", "NEUTRAL", 1, "2030-09-02", null))
            db.suggestionDao().insert(SuggestionEntity("s1", "turn", "CHAT", "TODO", "测试", null, null, null, null, "PENDING", 1))
            db.close(); db = open(name)
            assertEquals("本地测试", db.chatDao().recent(1).single().content)
            assertEquals("PENDING", db.suggestionDao().get("s1")?.status)
        } finally { db.close(); context.deleteDatabase(name) }
    }
}

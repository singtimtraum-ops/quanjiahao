package cn.edu.ruc.zhixing

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import cn.edu.ruc.zhixing.storage.room.AppDatabase
import cn.edu.ruc.zhixing.storage.room.chat.ChatTurnEntity
import cn.edu.ruc.zhixing.storage.room.planner.SuggestionEntity
import kotlinx.coroutines.runBlocking
import org.junit.Assume.assumeTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.time.LocalDate

/** 仅在显式参数启用时提供标记清楚的本地 UI 测试卡片，不依赖或调用真实模型。 */
@RunWith(AndroidJUnit4::class)
class UiFixtureTest {
    @Test fun prepareOrRemoveFixtures() = runBlocking {
        val args = InstrumentationRegistry.getArguments()
        val action = args.getString("ui_fixture")
        assumeTrue(action == "seed" || action == "remove")
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        check(context.packageName == "cn.edu.ruc.zhixing.dev")
        val db = AppDatabase.get(context)
        val id = "verification-ui-suggestion"
        if (action == "seed") {
            val now = System.currentTimeMillis()
            db.suggestionDao().insert(SuggestionEntity(id, "verification-ui", "CHAT", "TODO", "[本地测试]交报告",
                null, null, now + 86400000, null, "PENDING", now))
            db.chatDao().insert(ChatTurnEntity("card-$id", "default", "SYSTEM", "本地测试建议", "NEUTRAL", now, LocalDate.now().toString(), id))
        } else {
            db.openHelper.writableDatabase.execSQL("DELETE FROM chat_turn WHERE id = ?", arrayOf("card-$id"))
            db.openHelper.writableDatabase.execSQL("DELETE FROM suggestion WHERE id = ?", arrayOf(id))
            db.todoDao().delete(id)
            db.openHelper.writableDatabase.execSQL("DELETE FROM todo WHERE title = 'Local-QA-0904'")
        }
    }
}

package cn.edu.ruc.zhixing

import android.app.Application

/**
 * 应用入口：构建运行时容器并在启动时开启采集。
 */
class ZhixingApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        container.start()
    }
}

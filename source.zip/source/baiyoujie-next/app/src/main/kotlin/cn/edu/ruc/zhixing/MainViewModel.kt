package cn.edu.ruc.zhixing

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import cn.edu.ruc.zhixing.core.model.PriorityLevel
import cn.edu.ruc.zhixing.presentation.ui.model.AdaptiveStatus
import cn.edu.ruc.zhixing.presentation.ui.model.MessageSection
import cn.edu.ruc.zhixing.presentation.ui.model.ModuleState
import cn.edu.ruc.zhixing.presentation.ui.model.UiMessage
import cn.edu.ruc.zhixing.storage.room.MessageEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * 验证版 ViewModel：把「采集模块状态」「分类结果分组」「通知权限」以流暴露给 UI，
 * 并提供开启模块、发送测试消息、刷新等操作。真实采集/分类在 AppContainer 完成。
 */
class MainViewModel(private val container: AppContainer) : ViewModel() {

    private val _moduleStates = MutableStateFlow<List<ModuleState>>(emptyList())
    val moduleStates: StateFlow<List<ModuleState>> = _moduleStates.asStateFlow()

    private val _postPermissionGranted = MutableStateFlow(false)
    val postPermissionGranted: StateFlow<Boolean> = _postPermissionGranted.asStateFlow()

    private val _adaptiveStatus = MutableStateFlow(buildAdaptiveStatus())
    val adaptiveStatus: StateFlow<AdaptiveStatus> = _adaptiveStatus.asStateFlow()

    private val levelOrder = listOf(
        PriorityLevel.P0_URGENT,
        PriorityLevel.P1_IMPORTANT,
        PriorityLevel.P2_NORMAL,
        PriorityLevel.P3_IGNORABLE,
    )

    /** 按重要性分组的分类结果（P0~P3）。 */
    val messageSections: StateFlow<List<MessageSection>> =
        container.messageDao.observeAll()
            .map { rows ->
                rows.groupBy { PriorityLevel.valueOf(it.level) }
                    .mapNotNull { (level, list) ->
                        if (list.isEmpty()) null
                        else MessageSection(
                            level = level,
                            messages = list
                                .sortedByDescending { it.timestamp }
                                .take(50)
                                .map { it.toUi() },
                        )
                    }
                    .sortedBy { levelOrder.indexOf(it.level) }
            }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** 重建状态（IO 线程），并补启动新满足条件的采集器。 */
    fun refresh() {
        viewModelScope.launch(Dispatchers.IO) {
            _postPermissionGranted.value = container.isPostNotifGranted()
            _moduleStates.value = buildModules()
            _adaptiveStatus.value = buildAdaptiveStatus()
            container.syncAcquirers()
        }
    }

    /** 开启某采集层（同意 + 打开系统授权页），随后刷新。 */
    fun onEnableModule(id: String) {
        container.enableModule(id)
        refresh()
    }

    /** 发一条测试消息验证分类管线。 */
    fun onSendTest(sender: String, content: String, isGroup: Boolean) {
        container.emitTestMessage(sender, content, isGroup)
    }

    /** 用户反馈：提升/降低某条消息重要性 → 驱动在线学习，并立即刷新学习状态。 */
    fun onFeedback(messageId: String, moreImportant: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            container.recordFeedback(messageId, moreImportant)
            _adaptiveStatus.value = buildAdaptiveStatus()
        }
    }

    private fun buildAdaptiveStatus(): AdaptiveStatus = AdaptiveStatus(
        sampleCount = container.adaptiveSampleCount,
        topSignals = container.adaptiveTopSignals().map { (label, w) ->
            "${label} ${"%+.2f".format(w)}"
        },
        learningActive = container.isLearningActive(),
    )

    private fun buildModules(): List<ModuleState> = listOf(
        ModuleState(
            id = AppContainer.ModuleId.NOTIFY,
            name = "通知监听",
            desc = "默认 · 读取通知可见摘要，进行重要性分级",
            enabled = container.isModuleEnabled(AppContainer.ModuleId.NOTIFY),
        ),
        ModuleState(
            id = AppContainer.ModuleId.ACCESSIBILITY,
            name = "无障碍增强",
            desc = "可选 · 读取屏内更多正文（默认关闭）",
            enabled = container.isModuleEnabled(AppContainer.ModuleId.ACCESSIBILITY),
        ),
        ModuleState(
            id = AppContainer.ModuleId.DB,
            name = "Root 取库",
            desc = "高级 · 导入完整历史（仅自用/内测）",
            enabled = container.isModuleEnabled(AppContainer.ModuleId.DB),
        ),
    )
}

/** Room 实体 → 展示模型。 */
private fun MessageEntity.toUi(): UiMessage = UiMessage(
    id = id,
    channel = channel,
    sender = senderName.ifEmpty { channel },
    content = content,
    isGroup = isGroup,
    category = category,
    score = score,
    reason = reason,
    level = PriorityLevel.valueOf(level),
    timestamp = timestamp,
)

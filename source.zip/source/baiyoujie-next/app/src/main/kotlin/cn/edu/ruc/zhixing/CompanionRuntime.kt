package cn.edu.ruc.zhixing

import android.content.Context
import cn.edu.ruc.zhixing.agent.memory.MemoryTicker
import cn.edu.ruc.zhixing.companion.ai.openai.OpenAiLlmClient
import cn.edu.ruc.zhixing.companion.chat.ChatRepository
import cn.edu.ruc.zhixing.companion.chat.desensitize.Desensitizer
import cn.edu.ruc.zhixing.storage.room.AppDatabase
import cn.edu.ruc.zhixing.storage.room.memory.RoomMemoryStore
import kotlinx.coroutines.flow.first
import java.time.*
import androidx.room.withTransaction
import cn.edu.ruc.zhixing.planner.extract.ExtractionService
import cn.edu.ruc.zhixing.storage.room.MessageEntity
import cn.edu.ruc.zhixing.storage.room.planner.*
import cn.edu.ruc.zhixing.storage.room.chat.ChatTurnEntity
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.flow.MutableStateFlow

/** AppContainer 装配的陪伴域运行时；不申请通知发送权限。 */
class CompanionRuntime(context: Context, val db: AppDatabase) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val extractionLock = Mutex()
    val extractionStatus = MutableStateFlow("")
    val settings = CompanionSettings(context)
    val memories = RoomMemoryStore(db.memoryDao())
    val ticker = MemoryTicker(memories)
    val suggestions = SuggestionRepository(db)
    val courses = cn.edu.ruc.zhixing.planner.calendar.CourseRepository(db)
    val client = OpenAiLlmClient(settings) { text ->
        Desensitizer().clean(text, db.messageDao().knownNames(false), db.messageDao().knownNames(true))
    }
    private val extractor = ExtractionService(client)
    val chat = ChatRepository(db.chatDao(), client, settings, context = {
        val now = System.currentTimeMillis()
        ticker.tick(now)
        val memory = memories.active(now, 10).joinToString("\n") { it.content }
        val schedules = db.scheduleDao().startingWithin(now, now + 2 * 86400000L).take(5).joinToString("\n") {
            "${it.title} ${Instant.ofEpochMilli(it.startTime).atZone(ZoneId.systemDefault())}"
        }
        "有效记忆：\n$memory\n今日/明日日程：\n$schedules"
    }, afterTurn = { id, text, plans -> enqueue(id, "CHAT", text, System.currentTimeMillis(), plans) })

    fun onMessage(message: MessageEntity) {
        if (message.level in setOf("P0_URGENT", "P1_IMPORTANT"))
            enqueue(message.id, "MESSAGE", message.content, message.timestamp, true)
    }
    suspend fun retryRecentMessages() {
        if (!settings.current().allowCloud) return
        db.messageDao().extractionCandidates(System.currentTimeMillis() - 86400000L).forEach(::onMessage)
    }
    suspend fun cancelExtractions() {
        scope.coroutineContext[Job]?.children?.toList()?.forEach { it.cancelAndJoin() }
        extractionStatus.value = ""
    }
    private fun enqueue(id: String, source: String, text: String, at: Long, plans: Boolean) {
        scope.launch {
            extractionLock.withLock {
                val config = settings.current()
                if (!config.allowCloud || config.apiKey.isBlank()) return@withLock
                val receipt = db.extractionReceiptDao().get(id)
                val now = System.currentTimeMillis()
                if (receipt?.state == "DONE" || (receipt?.attempts ?: 0) >= 3) return@withLock
                if (receipt != null && now - receipt.updatedAt < 60000) return@withLock
                val attempts = (receipt?.attempts ?: 0) + 1
                db.extractionReceiptDao().put(ExtractionReceipt(id, "PROCESSING", attempts, now))
                try {
                    val result = extractor.extract(id, source, text, at, plans)
                    ensureActive()
                    if (!settings.current().allowCloud) return@withLock
                    db.withTransaction {
                        result.suggestions.forEach { suggestion ->
                            if (db.suggestionDao().insert(suggestion.toEntity()) != -1L) {
                                db.chatDao().insert(ChatTurnEntity("card-${suggestion.id}", "default", "SYSTEM",
                                    "这件事要记下来吗？", "NEUTRAL", now, LocalDate.now().toString(), suggestion.id))
                            }
                        }
                        result.memories.forEach { memories.add(it) }
                        db.extractionReceiptDao().put(ExtractionReceipt(id, "DONE", attempts, now))
                    }
                    extractionStatus.value = ""
                } catch (e: CancellationException) { throw e
                } catch (_: Exception) {
                    db.extractionReceiptDao().put(ExtractionReceipt(id, "FAILED", attempts, now))
                    extractionStatus.value = "有内容尚未整理，可稍后重试。"
                }
            }
        }
    }
}

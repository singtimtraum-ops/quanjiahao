package cn.edu.ruc.zhixing

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import cn.edu.ruc.zhixing.companion.ai.config.LlmConfig
import cn.edu.ruc.zhixing.core.model.companion.*
import cn.edu.ruc.zhixing.core.model.memory.*
import cn.edu.ruc.zhixing.core.model.planner.*
import cn.edu.ruc.zhixing.storage.room.planner.*
import cn.edu.ruc.zhixing.storage.room.memory.toModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.time.*
import java.util.UUID

/** UI 操作在 IO 协程中持久化；同一时间只发送一轮对话。 */
class CompanionViewModel(private val runtime: CompanionRuntime) : ViewModel() {
    val config = MutableStateFlow(LlmConfig())
    val status = MutableStateFlow("")
    val chat = runtime.chat
    val extractionStatus = runtime.extractionStatus
    val coursePlan = runtime.courses.plan.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CoursePlan())
    fun saveCourses(plan: CoursePlan) = action {
        val count = runtime.courses.save(plan)
        status.value = "课表已保存，共 $count 节课程安排。"
    }
    val suggestions = runtime.db.suggestionDao().observeAll().map { rows -> rows.map { it.toModel() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    private var sending: Job? = null
    val turns = runtime.db.chatDao().observeAll().map { list -> list.map {
        ChatTurn(it.id, it.sessionId, ChatRole.valueOf(it.role), it.content, EmotionLabel.valueOf(it.emotion), it.timestamp, it.dayBucket, it.cardId?.let(::CardRef))
    } }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val events = runtime.db.scheduleDao().observeAll().map { rows -> rows.map {
        ScheduleEvent(it.id, it.title, it.startTime, it.endTime, it.location, it.rrule, EventSource.valueOf(it.source), EventStatus.valueOf(it.status), it.remindBeforeMin)
    } }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val todos = runtime.db.todoDao().observeAll().map { rows -> rows.map {
        TodoItem(it.id, it.title, it.dueTime, it.done, it.sourceMessageId, it.createdAt)
    } }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val memories = runtime.db.memoryDao().observeAll().map { rows -> rows.map { it.toModel() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    init { refresh() }
    fun refresh() = action {
        config.value = runtime.settings.current()
        runtime.ticker.tick(System.currentTimeMillis())
        runtime.retryRecentMessages()
    }
    fun saveConfig(value: LlmConfig) = action {
        sending?.cancelAndJoin()
        runtime.cancelExtractions()
        runtime.settings.save(value); config.value = runtime.settings.current(); status.value = "设置已保存"
    }
    fun cloud(enabled: Boolean) = action {
        runtime.settings.setCloud(enabled)
        if (!enabled) { sending?.cancelAndJoin(); runtime.cancelExtractions() }
        config.value = runtime.settings.current()
        if (enabled) runtime.retryRecentMessages()
    }
    fun testConnection() = action {
        val answer = runtime.client.chat("请仅用中文回复：连接成功。", listOf(LlmMsg("user", "连接测试")))
        status.value = if (answer.text.isNotBlank()) "模型连接成功" else "服务返回了空回复，请检查模型名称。"
    }
    fun send(text: String) {
        if (sending?.isActive == true) return
        sending = viewModelScope.launch(Dispatchers.IO) { runtime.chat.send(text) }
    }
    fun stopReply() { sending?.cancel() }
    fun addTodo(title: String, due: Long?) = action {
        require(title.isNotBlank()) { "请填写待办标题。" }
        runtime.db.todoDao().upsert(TodoEntity(UUID.randomUUID().toString(), title.trim().take(200), due, false, null, System.currentTimeMillis()))
    }
    fun done(id: String, value: Boolean) = action { runtime.db.todoDao().setDone(id, value) }
    fun addEvent(title: String, start: Long, end: Long) = action {
        require(title.isNotBlank() && end > start) { "请填写标题，并确保结束时间晚于开始时间。" }
        runtime.db.scheduleDao().upsert(ScheduleEntity(UUID.randomUUID().toString(), title.trim().take(200), start, end, null, null, "MANUAL", "UPCOMING", 10))
    }
    fun deleteEvent(id: String) = action { runtime.db.scheduleDao().delete(id) }
    fun deleteMemory(id: String) = action { runtime.db.memoryDao().delete(id) }
    fun confirmSuggestion(id: String, title: String) = action { runtime.suggestions.confirm(id, title) }
    fun dismissSuggestion(id: String) = action { runtime.suggestions.dismiss(id) }
    private fun action(block: suspend () -> Unit) = viewModelScope.launch(Dispatchers.IO) {
        try { block() } catch (e: CancellationException) { throw e } catch (e: Exception) {
            status.value = if (e is IllegalArgumentException || e is IllegalStateException) e.message.orEmpty() else "操作未完成，请检查网络或重试。"
        }
    }
}

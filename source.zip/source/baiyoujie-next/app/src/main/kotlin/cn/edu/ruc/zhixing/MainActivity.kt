package cn.edu.ruc.zhixing

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import cn.edu.ruc.zhixing.presentation.ui.CompanionScaffold
import cn.edu.ruc.zhixing.presentation.ui.messages.MessageListScreen
import cn.edu.ruc.zhixing.presentation.ui.theme.ZhixingTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ZhixingTheme {
                MainScreen()
            }
        }
    }
}

@Composable
private fun MainScreen() {
    val app = (LocalContext.current.applicationContext as ZhixingApp)
    val vm: MainViewModel = viewModel { MainViewModel(app.container) }
    val companion: CompanionViewModel = viewModel { CompanionViewModel(app.container.companion) }

    val modules by vm.moduleStates.collectAsState()
    val sections by vm.messageSections.collectAsState()
    val adaptiveStatus by vm.adaptiveStatus.collectAsState()
    val config by companion.config.collectAsState()
    val turns by companion.turns.collectAsState()
    val events by companion.events.collectAsState()
    val todos by companion.todos.collectAsState()
    val memories by companion.memories.collectAsState()
    val suggestions by companion.suggestions.collectAsState()
    val coursePlan by companion.coursePlan.collectAsState()
    val extractionStatus by companion.extractionStatus.collectAsState()
    val status by companion.status.collectAsState()
    val preview by companion.chat.preview.collectAsState()
    val busy by companion.chat.busy.collectAsState()
    val error by companion.chat.error.collectAsState()

    // 每次回到前台刷新，确保「从系统设置授权返回」后状态与采集器正确更新。
    LifecycleResumeEffect(Unit) {
        vm.refresh()
        companion.refresh()
        onPauseOrDispose { }
    }

    CompanionScaffold(
        config = config, turns = turns, preview = preview, busy = busy, error = error,
        suggestions = suggestions, extractionStatus = extractionStatus,
        coursePlan = coursePlan, onSaveCourses = { companion.saveCourses(it) },
        onConfirmSuggestion = { id, title -> companion.confirmSuggestion(id, title) },
        onDismissSuggestion = { companion.dismissSuggestion(it) },
        events = events, todos = todos, memories = memories, status = status, modules = modules,
        onSend = companion::send, onStop = companion::stopReply,
        onSaveConfig = { companion.saveConfig(it) }, onCloud = { companion.cloud(it) },
        onTest = { companion.testConnection() }, onEnable = vm::onEnableModule,
        onDisable = { app.container.disableModule(it); vm.refresh() },
        onAddTodo = { title, due -> companion.addTodo(title, due) },
        onDone = { id, value -> companion.done(id, value) },
        onAddEvent = { title, start, end -> companion.addEvent(title, start, end) },
        onDeleteEvent = { companion.deleteEvent(it) }, onDeleteMemory = { companion.deleteMemory(it) },
        messages = { MessageListScreen(sections, adaptiveStatus, vm::onSendTest, vm::onFeedback) },
    )
}

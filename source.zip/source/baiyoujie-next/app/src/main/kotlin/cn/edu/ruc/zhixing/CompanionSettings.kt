package cn.edu.ruc.zhixing

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import cn.edu.ruc.zhixing.companion.ai.config.*
import kotlinx.coroutines.flow.first
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private val Context.companionPreferences by preferencesDataStore("companion_settings")

/** DataStore 保存配置；密钥用 Keystore AES-GCM 加密，解密失败要求重新填写。 */
class CompanionSettings(private val context: Context) : LlmConfigProvider {
    private val base = stringPreferencesKey("base_url")
    private val model = stringPreferencesKey("model")
    private val secret = stringPreferencesKey("encrypted_key")
    private val cloud = booleanPreferencesKey("cloud_enabled")
    private val name = stringPreferencesKey("persona_name")
    override suspend fun current(): LlmConfig {
        val p = context.companionPreferences.data.first()
        val key = p[secret]?.let { runCatching { decrypt(it) }.getOrDefault("") }.orEmpty()
        return LlmConfig(p[base] ?: "https://api.deepseek.com", key, p[model] ?: "deepseek-chat", p[cloud] ?: false, p[name] ?: "小行")
    }
    suspend fun save(value: LlmConfig) {
        val encrypted = if (value.apiKey.isBlank()) "" else encrypt(value.apiKey.trim())
        context.companionPreferences.edit {
            val sameProvider = (it[base] ?: "https://api.deepseek.com").trimEnd('/') == value.baseUrl.trim().trimEnd('/')
            val keepConsent = sameProvider && it[cloud] == true && value.allowCloud
            it[base] = value.baseUrl.trim(); it[model] = value.model.trim()
            it[secret] = encrypted; it[cloud] = keepConsent
            it[name] = value.personaName.trim().take(20).ifBlank { "小行" }
        }
    }
    suspend fun setCloud(enabled: Boolean) { context.companionPreferences.edit { it[cloud] = enabled } }
    suspend fun clear() { context.companionPreferences.edit { it.clear() } }
    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey("baiyoujie_llm", null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder("baiyoujie_llm", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        }.generateKey()
    }
    private fun encrypt(text: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key()) }
        return Base64.encodeToString(cipher.iv + cipher.doFinal(text.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
    }
    private fun decrypt(value: String): String {
        if (value.isBlank()) return ""
        val bytes = Base64.decode(value, Base64.NO_WRAP)
        require(bytes.size >= 28)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, bytes.copyOfRange(0, 12))) }
        return cipher.doFinal(bytes.copyOfRange(12, bytes.size)).toString(Charsets.UTF_8)
    }
}

package cn.edu.ruc.zhixing

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import cn.edu.ruc.zhixing.acquisition.accessibility.AccessibilityAcquirer
import cn.edu.ruc.zhixing.acquisition.api.MessageBus
import cn.edu.ruc.zhixing.acquisition.db.DbAcquirer
import cn.edu.ruc.zhixing.acquisition.notify.NotifyAcquirer
import cn.edu.ruc.zhixing.core.model.Channel
import cn.edu.ruc.zhixing.core.model.ChatMessage
import cn.edu.ruc.zhixing.core.model.Classification
import cn.edu.ruc.zhixing.core.model.SourceQuality
import cn.edu.ruc.zhixing.engine.adaptive.AdaptiveImportanceClassifier
import cn.edu.ruc.zhixing.engine.adaptive.AdaptiveModel
import cn.edu.ruc.zhixing.engine.adaptive.FeatureVectorizer
import cn.edu.ruc.zhixing.engine.classifier.ImportanceEngine
import cn.edu.ruc.zhixing.engine.feature.FeatureExtractor
import cn.edu.ruc.zhixing.engine.rule.RuleClassifier
import cn.edu.ruc.zhixing.policy.permission.PermissionGovernor
import cn.edu.ruc.zhixing.storage.room.AppDatabase
import cn.edu.ruc.zhixing.storage.room.FeedbackDao
import cn.edu.ruc.zhixing.storage.room.FeedbackEvent
import cn.edu.ruc.zhixing.storage.room.MessageDao
import cn.edu.ruc.zhixing.storage.room.MessageEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * 运行时装配容器（手动依赖注入，未引入 Hilt 以保持骨架轻量）。
 *
 * 关键职责：
 *  - 把「采集流 → 分类 → 存储」串起来，并注册三个采集层；
 *  - 接入**自适应分类器**（规则 + 在线学习混合），学习模型从用户反馈在线更新；
 *  - 提供 `recordFeedback`：把用户「提升/降低重要性」作为训练样本喂给模型，
 *    并持久化模型权重，实现“越用越准”。
 */
class AppContainer(private val context: Context) {

    val governor = PermissionGovernor(context)
    private val db = AppDatabase.get(context)
    val companion = CompanionRuntime(context, db)
    val messageDao: MessageDao = db.messageDao()
    private val feedbackDao: FeedbackDao = db.feedbackDao()

    val messageBus = MessageBus()

    // ---- 自适应分类 ----
    private val featureExtractor = FeatureExtractor()
    private val vectorizer = FeatureVectorizer()
    private val baseRule = RuleClassifier()
    private val adaptiveModel = AdaptiveModel(vectorizer.dim)
    private val burstContext = object : FeatureExtractor.FeatureContext {
        private val recent = mutableMapOf<String, Long>()
        override fun recentBurst(senderName: String): Boolean {
            val now = System.currentTimeMillis()
            val last = recent[senderName]
            recent[senderName] = now
            return last != null && now - last < 30_000L
        }
    }
    private val adaptiveClassifier = AdaptiveImportanceClassifier(
        base = baseRule,
        model = adaptiveModel,
        featureExtractor = featureExtractor,
        burstContext = burstContext,
        vectorizer = vectorizer,
    )

    val engine = ImportanceEngine(
        classifier = adaptiveClassifier,
        onExternal = { /* 策略层可在此做免打扰/提醒 */ },
    )

    // 采集层实例保留引用，供权限状态查询与授权入口使用。
    val notifyAcquirer = NotifyAcquirer()
    val accessibilityAcquirer = AccessibilityAcquirer()
    val dbAcquirer = DbAcquirer()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    init {
        // 合规：采集启动必须同时满足“系统权限”和“用户同意”，否则不采集。
        messageBus.setConsentCheck { quality -> governor.hasConsent(quality) }

        loadModel()

        // 1) 采集流 → 分类 → 落库
        messageBus.messages
            .onEach { msg ->
                val c = engine.classify(msg)
                val entity = msg.toEntity(c)
                messageDao.upsert(entity)
                companion.onMessage(entity)
            }
            .launchIn(scope)

        // 2) 注册采集层（模块化扩展点）
        messageBus.register(notifyAcquirer)
        messageBus.register(accessibilityAcquirer)
        // Root 取库仅保留工程占位，不接入产品采集主流程。
    }

    fun start() = messageBus.start(context)
    fun stop() = messageBus.stop()

    /** 授权/权限变化后再次检查：把“新满足条件”的采集器拉活（幂等）。 */
    fun syncAcquirers() = messageBus.start(context)

    fun disableModule(moduleId: String) {
        governor.revokeConsent(moduleQuality(moduleId))
        syncAcquirers()
    }

    // ---- 模块/权限状态（供 UI 展示与授权入口）----

    fun isModuleEnabled(moduleId: String): Boolean = when (moduleId) {
        ModuleId.NOTIFY -> governor.hasConsent(SourceQuality.NOTIFICATION) && notifyAcquirer.isEnabled(context)
        ModuleId.ACCESSIBILITY -> governor.hasConsent(SourceQuality.ACCESSIBILITY) && accessibilityAcquirer.isEnabled(context)
        ModuleId.DB -> governor.hasConsent(SourceQuality.DATABASE) && dbAcquirer.isEnabled(context)
        else -> false
    }

    /** 用户点击“去开启”：同意该采集层 + 打开对应系统授权页 + 触发一次重新检查。 */
    fun enableModule(moduleId: String) {
        governor.grantConsent(moduleQuality(moduleId))
        requestModulePermission(moduleId)
        syncAcquirers()
    }

    fun requestModulePermission(moduleId: String) {
        when (moduleId) {
            ModuleId.NOTIFY -> notifyAcquirer.requestPermission(context)
            ModuleId.ACCESSIBILITY -> accessibilityAcquirer.requestPermission(context)
            ModuleId.DB -> dbAcquirer.requestPermission(context)
        }
    }

    private fun moduleQuality(moduleId: String): SourceQuality = when (moduleId) {
        ModuleId.NOTIFY -> SourceQuality.NOTIFICATION
        ModuleId.ACCESSIBILITY -> SourceQuality.ACCESSIBILITY
        ModuleId.DB -> SourceQuality.DATABASE
        else -> SourceQuality.NOTIFICATION
    }

    // ---- 自适应学习 ----

    /** 已积累的反馈样本数（供 UI/调试展示学习状态）。 */
    val adaptiveSampleCount: Int get() = adaptiveModel.sampleCount

    /** 模型当前“最看重”的特征信号（按权重绝对值取前 4）。 */
    fun adaptiveTopSignals(): List<Pair<String, Float>> {
        val arr = adaptiveModel.toArray()
        val labels = vectorizer.featureLabels
        return labels.indices
            .filter { arr[it] != 0f }
            .sortedByDescending { kotlin.math.abs(arr[it]) }
            .take(4)
            .map { labels[it] to arr[it] }
    }

    /** 是否已经积累足够反馈、让学习结果开始介入（样本数阈值）。 */
    fun isLearningActive(): Boolean = adaptiveModel.sampleCount >= 4

    /**
     * 记录用户反馈（提升/降低重要性）→ 用于在线更新分类模型，并持久化。
     * 标签：moreImportant=true → 1.0（重要），false → 0.0（不重要）。
     * 挂起直至模型更新完成，便于调用方立即读取最新学习状态。
     */
    suspend fun recordFeedback(messageId: String, moreImportant: Boolean) {
        val entity = messageDao.getById(messageId) ?: return
        val msg = entity.toChatMessage()
        val features = featureExtractor.extract(msg, burstContext)
        val x = vectorizer.vectorize(features)
        adaptiveModel.update(x, if (moreImportant) 1f else 0f)
        saveModel()
        feedbackDao.insert(
            FeedbackEvent(
                messageId = messageId,
                channel = entity.channel,
                senderName = entity.senderName,
                content = entity.content,
                isGroup = entity.isGroup,
                label = if (moreImportant) 1f else 0f,
                timestamp = System.currentTimeMillis(),
            ),
        )
    }

    // ---- 验证辅助 ----

    /** Android 13+ 运行时通知显示权限（低版本视为已授权）。 */
    fun isPostNotifGranted(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    /** 注入一条测试消息，走完整的「MessageBus→去重→分类→落库」管线（用于验证）。 */
    fun emitTestMessage(sender: String, content: String, isGroup: Boolean) {
        val msg = ChatMessage(
            id = "test-${System.currentTimeMillis()}-${(0..9999).random()}",
            channel = Channel.WECHAT,
            senderId = sender,
            senderName = sender,
            isGroup = isGroup,
            content = content,
            timestamp = System.currentTimeMillis(),
            quality = SourceQuality.NOTIFICATION,
            raw = "test-inject",
        )
        // 测试数据来自用户显式操作，不冒用真实采集权限，也不上传到模型。
        scope.launch { messageDao.upsert(msg.toEntity(engine.classify(msg))) }
    }

    // ---- 模型持久化 ----

    private fun loadModel() {
        val f = File(context.filesDir, MODEL_FILE)
        if (!f.exists()) return
        try {
            DataInputStream(FileInputStream(f)).use { input ->
                val n = input.readInt()
                val weights = FloatArray(n) { input.readFloat() }
                val sc = input.readInt()
                adaptiveModel.fromArray(weights)
                adaptiveModel.setSampleCount(sc)
            }
        } catch (e: Exception) {
            // 损坏则忽略，回退默认模型
        }
    }

    private fun saveModel() {
        val f = File(context.filesDir, MODEL_FILE)
        try {
            DataOutputStream(FileOutputStream(f)).use { out ->
                val weights = adaptiveModel.toArray()
                out.writeInt(weights.size)
                weights.forEach { out.writeFloat(it) }
                out.writeInt(adaptiveModel.sampleCount)
            }
        } catch (e: Exception) {
            // 写入失败不影响主流程
        }
    }

    object ModuleId {
        const val NOTIFY = "notify"
        const val ACCESSIBILITY = "accessibility"
        const val DB = "db"
    }

    private companion object {
        const val MODEL_FILE = "adaptive_model.bin"
    }
}

/** 消息 → 落库实体。 */
private fun ChatMessage.toEntity(c: Classification): MessageEntity = MessageEntity(
    id = id,
    channel = channel.name,
    senderId = senderId,
    senderName = senderName,
    isGroup = isGroup,
    content = content,
    timestamp = timestamp,
    isSelf = isSelf,
    quality = quality.name,
    level = c.level.name,
    score = c.score,
    category = c.category.name,
    reason = c.reason,
)

/** 落库实体 → 消息（供反馈时重算特征）。 */
private fun MessageEntity.toChatMessage(): ChatMessage = ChatMessage(
    id = id,
    channel = Channel.valueOf(channel),
    senderId = senderId,
    senderName = senderName,
    isGroup = isGroup,
    content = content,
    timestamp = timestamp,
    isSelf = isSelf,
    quality = SourceQuality.valueOf(quality),
    raw = "",
)

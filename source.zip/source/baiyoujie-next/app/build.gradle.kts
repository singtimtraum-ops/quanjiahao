plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "cn.edu.ruc.zhixing"
    compileSdk = 35

    defaultConfig {
        applicationId = "cn.edu.ruc.zhixing"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "0.3.0-dev"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        debug { applicationIdSuffix = ".dev" }
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    androidTestImplementation(libs.androidx.test.runner)
    androidTestImplementation(libs.androidx.test.junit)
    implementation(project(":companion:ai"))
    implementation(project(":companion:chat"))
    implementation(project(":agent:memory"))
    implementation(project(":planner:calendar"))
    implementation(project(":planner:extract"))
    implementation(project(":focus:ctdp"))
    implementation(libs.datastore.preferences)
    implementation(libs.kotlinx.serialization.json)
    // 模块装配（app 依赖所有功能模块，模块之间通过 core/acquisition-api 解耦）
    implementation(project(":core:model"))
    implementation(project(":core:common"))
    implementation(project(":acquisition:api"))
    implementation(project(":acquisition:notify"))
    implementation(project(":acquisition:accessibility"))
    implementation(project(":acquisition:db"))
    implementation(project(":engine:feature"))
    implementation(project(":engine:rule"))
    implementation(project(":engine:adaptive"))
    implementation(project(":engine:classifier"))
    implementation(project(":storage:room"))
    implementation(project(":policy:permission"))
    implementation(project(":presentation:ui"))

    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.material3)
    implementation(libs.compose.ui.tooling.preview)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.kotlinx.coroutines.android)
    debugImplementation(libs.compose.ui.tooling)
}

package cn.edu.ruc.zhixing.planner.extract

import cn.edu.ruc.zhixing.companion.ai.LlmEvent
import cn.edu.ruc.zhixing.core.model.memory.*
import cn.edu.ruc.zhixing.core.model.planner.*
import org.junit.Assert.*
import org.junit.Test

class ExtractionServiceTest {
    private fun parse(name: String, json: String, plans: Boolean = true) =
        ExtractionService.parse(listOf(LlmEvent.ToolCall(name, json)), "source-1", "CHAT", 1000L, plans)
    @Test fun todoIsPendingNotAnExecutedAction() {
        val item = parse("create_todo", """{"title":"交报告","dueTime":null}""").suggestions.single()
        assertEquals(SuggestionStatus.PENDING, item.status)
        assertNull(item.dueTime)
    }
    @Test fun eventNeedsBothTimes() {
        assertTrue(parse("create_event", """{"title":"组会","startTime":"2030-01-01T15:00:00+08:00"}""").suggestions.isEmpty())
    }
    @Test fun eventCannotEndBeforeItStarts() {
        assertTrue(parse("create_event", """{"title":"组会","startTime":"2030-01-01T15:00:00+08:00","endTime":"2030-01-01T14:00:00+08:00"}""").suggestions.isEmpty())
    }
    @Test fun eventCannotHaveZeroDuration() {
        assertTrue(parse("create_event", """{"title":"组会","startTime":"2030-01-01T15:00:00+08:00","endTime":"2030-01-01T15:00:00+08:00"}""").suggestions.isEmpty())
    }
    @Test fun ambiguousLocalTimeIsRejected() {
        assertTrue(parse("create_todo", """{"title":"交报告","dueTime":"2030-01-01T15:00:00"}""").suggestions.isEmpty())
    }
    @Test fun nonexistentDateIsRejected() {
        assertTrue(parse("create_todo", """{"title":"交报告","dueTime":"2030-02-30T15:00:00+08:00"}""").suggestions.isEmpty())
    }
    @Test fun knownOffsetIsConvertedExactly() {
        val item = parse("create_todo", """{"title":"交报告","dueTime":"2030-01-01T08:00:00+08:00"}""").suggestions.single()
        assertEquals(java.time.Instant.parse("2030-01-01T00:00:00Z").toEpochMilli(), item.dueTime)
    }
    @Test fun unknownToolCannotExecute() { assertTrue(parse("send_wechat", """{"title":"你好"}""").suggestions.isEmpty()) }
    @Test fun invalidJsonIsIgnored() { assertTrue(parse("create_todo", "{").suggestions.isEmpty()) }
    @Test fun blankTitleIsRejected() { assertTrue(parse("create_todo", """{"title":" "}""").suggestions.isEmpty()) }
    @Test fun numericTitleIsRejected() { assertTrue(parse("create_todo", """{"title":123}""").suggestions.isEmpty()) }
    @Test fun oversizedTitleIsRejected() { assertTrue(parse("create_todo", """{"title":"${"x".repeat(201)}"}""").suggestions.isEmpty()) }
    @Test fun soothingRejectsPlanningToolEvenIfModelReturnsIt() {
        assertTrue(parse("create_todo", """{"title":"学习"}""", false).suggestions.isEmpty())
    }
    @Test fun incompleteEventMemoryBecomesFact() {
        val item = parse("mark_info", """{"type":"EVENT","content":"有场时间未定的会议"}""").memories.single()
        assertEquals(MemoryType.FACT, item.type); assertNull(item.endTime)
    }
    @Test fun pastEventIsExpired() {
        val item = parse("mark_info", """{"type":"EVENT","content":"会议","startTime":"2000-01-01T15:00:00+08:00","endTime":"2000-01-01T16:00:00+08:00"}""").memories.single()
        assertEquals(MemoryStatus.EXPIRED, item.status)
    }
    @Test fun preferenceHasNoAccidentalExpiry() {
        val item = parse("mark_info", """{"type":"PREFERENCE","content":"喜欢安静","endTime":"2000-01-01T16:00:00+08:00"}""").memories.single()
        assertEquals(MemoryStatus.ACTIVE, item.status); assertNull(item.endTime)
    }
    @Test fun retryKeepsSameId() {
        assertEquals(parse("create_todo", """{"title":"交报告"}"""), parse("create_todo", """{"title":"交报告"}"""))
    }
    @Test fun duplicateCallsAreCollapsed() {
        val call = LlmEvent.ToolCall("create_todo", """{"title":"交报告"}""")
        assertEquals(1, ExtractionService.parse(listOf(call, call), "s", "CHAT", 1, true).suggestions.size)
    }
    @Test fun maximumFiveItems() {
        val calls = (1..10).map { LlmEvent.ToolCall("create_todo", """{"title":"事项$it"}""") }
        assertEquals(5, ExtractionService.parse(calls, "s", "CHAT", 1, true).suggestions.size)
    }
    @Test fun missingAndInvalidMemoryAreIgnored() {
        assertTrue(parse("mark_info", """{"type":"EVIL","content":"内容"}""").memories.isEmpty())
        assertTrue(parse("mark_info", """{"type":"FACT"}""").memories.isEmpty())
    }
}

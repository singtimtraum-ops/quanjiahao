package cn.edu.ruc.zhixing.planner.calendar

import cn.edu.ruc.zhixing.core.model.planner.*
import org.junit.Assert.*
import org.junit.Test
import java.time.*

class CoursePlannerTest {
    private val course = Course("math", "数学", 3, 1, 2, 1, 4, WeekPattern.ALL, "A101")
    private val plan = CoursePlan("2030-09-02", 4, "Asia/Shanghai",
        listOf(LessonSlot(1, "08:00", "08:45"), LessonSlot(2, "08:55", "09:40")), listOf(course))
    @Test fun entireTermHasCorrectTimes() {
        val events = CoursePlanner.expand(plan)
        assertEquals(4, events.size)
        assertEquals(Instant.parse("2030-09-04T00:00:00Z").toEpochMilli(), events.first().startTime)
        assertEquals(Instant.parse("2030-09-04T01:40:00Z").toEpochMilli(), events.first().endTime)
        assertEquals("A101", events.first().location)
    }
    @Test fun oddAndEvenWeeksFollowTeachingWeekNotCalendarWeek() {
        val odd = CoursePlanner.expand(plan.copy(courses = listOf(course.copy(pattern = WeekPattern.ODD))))
        val even = CoursePlanner.expand(plan.copy(courses = listOf(course.copy(pattern = WeekPattern.EVEN))))
        assertEquals(2, odd.size); assertEquals(2, even.size)
        assertEquals(7 * 86400000L, even.first().startTime - odd.first().startTime)
    }
    @Test fun repeatedSaveUsesStableIds() { assertEquals(CoursePlanner.expand(plan), CoursePlanner.expand(plan)) }
    @Test fun semesterCrossesYear() {
        val events = CoursePlanner.expand(plan.copy(termStart = "2030-12-23"))
        assertEquals(2031, Instant.ofEpochMilli(events.last().startTime).atZone(ZoneId.of("Asia/Shanghai")).year)
    }
    @Test fun zeroCoursesAllowed() { assertTrue(CoursePlanner.expand(plan.copy(courses = emptyList())).isEmpty()) }
    @Test(expected = IllegalArgumentException::class) fun missingSlotRejected() { CoursePlanner.expand(plan.copy(slots = plan.slots.take(1))) }
    @Test(expected = IllegalArgumentException::class) fun overlappingSlotsRejected() { CoursePlanner.expand(plan.copy(slots = listOf(LessonSlot(1, "08:00", "09:00"), LessonSlot(2, "08:45", "09:40")))) }
    @Test(expected = IllegalArgumentException::class) fun beyondTermRejected() { CoursePlanner.expand(plan.copy(courses = listOf(course.copy(lastWeek = 5)))) }
    @Test(expected = IllegalArgumentException::class) fun nonMondayRejected() { CoursePlanner.expand(plan.copy(termStart = "2030-09-03")) }
    @Test fun recurrenceKeepsOddWeekInterval() { assertEquals("FREQ=WEEKLY;INTERVAL=2;BYDAY=WE;COUNT=2", CoursePlanner.recurrence(course.copy(pattern = WeekPattern.ODD), plan)) }
}

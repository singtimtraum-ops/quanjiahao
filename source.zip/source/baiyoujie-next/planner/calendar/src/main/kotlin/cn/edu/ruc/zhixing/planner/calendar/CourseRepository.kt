package cn.edu.ruc.zhixing.planner.calendar

import androidx.room.withTransaction
import cn.edu.ruc.zhixing.core.model.planner.*
import cn.edu.ruc.zhixing.storage.room.AppDatabase
import cn.edu.ruc.zhixing.storage.room.planner.*
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class CourseRepository(private val db: AppDatabase) {
    val plan = db.coursePlanDao().observe().map { row -> row?.let { Json.decodeFromString<CoursePlan>(it.payload) } ?: CoursePlan() }
    suspend fun save(value: CoursePlan): Int {
        val events = CoursePlanner.expand(value)
        val normalized = value.copy(recurrences = value.courses.associate { it.id to CoursePlanner.recurrence(it, value) })
        db.withTransaction {
            db.coursePlanDao().save(CoursePlanEntity(payload = Json.encodeToString(normalized)))
            db.scheduleDao().deleteCourses()
            events.forEach { db.scheduleDao().upsert(ScheduleEntity(it.id, it.title, it.startTime, it.endTime, it.location, null, "COURSE", "UPCOMING", 0)) }
        }
        return events.size
    }
}

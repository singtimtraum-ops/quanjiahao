pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "ZhixingChat"

include(
    ":companion:ai", ":companion:chat", ":agent:memory",
    ":planner:calendar", ":planner:extract", ":focus:ctdp",
    // ---- core ----
    ":core:model",
    ":core:common",
    // ---- acquisition (可插拔数据源) ----
    ":acquisition:api",
    ":acquisition:notify",
    ":acquisition:accessibility",
    ":acquisition:db",
    // ---- engine (分类引擎) ----
    ":engine:feature",
    ":engine:rule",
    ":engine:adaptive",
    ":engine:classifier",
    // ---- infrastructure ----
    ":storage:room",
    ":policy:permission",
    // ---- presentation / app ----
    ":presentation:ui",
    ":app",
)

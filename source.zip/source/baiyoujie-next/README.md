# 百忧解

百忧解是一款本机优先的 Android 陪伴与信息整理应用。当前版本包含对话、建议确认、待办与课表、消息重要性分类、记忆管理和虚拟形象框架。

## 当前边界

- APP 当前不向用户发送系统通知，也不实现免打扰。
- 番茄钟支持 25/45 分钟专注、后台经过时间恢复、环境声、本地音频导入和背景选择；暂不接入 CTDP 链条或系统通知。
- 微信等消息只通过用户明确授权的 Android 通知监听或无障碍能力获取；不自动登录、破解数据库或代替用户发送消息。
- 云端模型默认关闭，Key 只由用户在 APP 设置页填写，不提交到仓库。
- AstrBot 暂不部署。

## 构建

使用 Android Studio 打开项目，安装 Android SDK 35，并使用 JDK 21。命令行验证：

```powershell
.\gradlew.bat :app:assembleDebug :companion:ai:test :agent:memory:test :planner:extract:test :planner:calendar:testDebugUnitTest
```

调试 APK 位于 `app/build/outputs/apk/debug/app-debug.apk`。

## 三人协作

- 分工与文件边界：`docs/OWNERSHIP.md`
- 稳定接口：`docs/CONTRACTS.md`
- 设计规范：`docs/DESIGN_SYSTEM.md`
- 日常开发与合并流程：`docs/TEAM_WORKFLOW.md`
- AI Agent 操作规则：`AGENTS.md`
- 当前进度：`docs/PROGRESS.md`

功能分支只合并到 `integration`，验证通过后再进入 `main`。每次提交前运行：

```powershell
.\tools\team-check.ps1 -Role auto
```

## 主要模块

| 模块 | 职责 |
|---|---|
| `presentation/ui` | Compose 页面、对话、日程、虚拟形象 |
| `companion/ai`、`agent/memory` | 对话服务、工具调用、记忆 |
| `planner/*` | 课表、日程和建议抽取 |
| `acquisition/*`、`engine/*` | 消息采集与重要性分类 |
| `storage/room` | 本机持久化与数据库迁移 |
| `core/model` | 跨模块公共数据契约 |

package cn.edu.ruc.zhixing.storage.room.chat

import androidx.room.Entity
import androidx.room.PrimaryKey

/** chat_turn 的持久化记录，与领域模型分离。 */
@Entity(tableName = "chat_turn")
data class ChatTurnEntity(
    @PrimaryKey val id: String,
    val sessionId: String,
    val role: String,
    val content: String,
    val emotion: String,
    val timestamp: Long,
    val dayBucket: String,
    val cardId: String?,
)


package cn.edu.ruc.zhixing.storage.room.chat

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/** 对话按日期查阅；调用者负责区分用户和 AI 角色。 */
@Dao interface ChatDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(turn: ChatTurnEntity)
    @Query("SELECT * FROM chat_turn ORDER BY timestamp ASC") fun observeAll(): Flow<List<ChatTurnEntity>>
    @Query("SELECT * FROM chat_turn WHERE dayBucket = :day ORDER BY timestamp ASC") fun pagingByDay(day: String): Flow<List<ChatTurnEntity>>
    @Query("SELECT DISTINCT dayBucket FROM chat_turn ORDER BY dayBucket DESC") fun daysWithMessages(): Flow<List<String>>
    @Query("SELECT * FROM chat_turn ORDER BY timestamp DESC LIMIT :limit") suspend fun recent(limit: Int): List<ChatTurnEntity>
}

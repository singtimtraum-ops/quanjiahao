package cn.edu.ruc.zhixing.storage.room.planner

import androidx.room.Entity
import androidx.room.PrimaryKey

/** todo 的持久化记录，与领域模型分离。 */
@Entity(tableName = "todo")
data class TodoEntity(
    @PrimaryKey val id: String,
    val title: String,
    val dueTime: Long?,
    val done: Boolean,
    val sourceMessageId: String?,
    val createdAt: Long,
)


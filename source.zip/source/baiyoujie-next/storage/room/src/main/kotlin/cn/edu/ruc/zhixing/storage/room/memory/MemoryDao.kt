package cn.edu.ruc.zhixing.storage.room.memory

import androidx.room.*
import kotlinx.coroutines.flow.Flow
import cn.edu.ruc.zhixing.agent.memory.MemoryStore
import cn.edu.ruc.zhixing.core.model.memory.*

@Dao interface MemoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(item: MemoryEntity)
    @Query("SELECT * FROM memory ORDER BY createdAt DESC") fun observeAll(): Flow<List<MemoryEntity>>
    @Query("SELECT * FROM memory WHERE status = 'ACTIVE' AND (endTime IS NULL OR endTime > :now) ORDER BY confidence DESC, createdAt DESC LIMIT :limit") suspend fun active(now: Long, limit: Int): List<MemoryEntity>
    @Query("SELECT * FROM memory WHERE type = 'EVENT' AND status = 'ACTIVE' AND endTime <= :now") suspend fun expirable(now: Long): List<MemoryEntity>
    @Query("UPDATE memory SET status = :status WHERE id = :id") suspend fun updateStatus(id: String, status: String)
    @Query("DELETE FROM memory WHERE id = :id") suspend fun delete(id: String)
}
/** Room 与纯 Kotlin 记忆域的适配器。 */
class RoomMemoryStore(private val dao: MemoryDao) : MemoryStore {
    override suspend fun add(item: MemoryItem) = dao.insert(MemoryEntity(item.id, item.type.name, item.content, item.startTime, item.endTime, item.status.name, item.source, item.confidence, item.createdAt))
    override suspend fun active(now: Long, limit: Int) = dao.active(now, limit).map { it.toModel() }
    override suspend fun expirableEvents(now: Long) = dao.expirable(now).map { it.toModel() }
    override suspend fun updateStatus(id: String, status: MemoryStatus) = dao.updateStatus(id, status.name)
}
fun MemoryEntity.toModel() = MemoryItem(id, MemoryType.valueOf(type), content, startTime, endTime, MemoryStatus.valueOf(status), source, confidence, createdAt)

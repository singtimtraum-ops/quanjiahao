package cn.edu.ruc.zhixing.storage.room.planner

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/** 使用重叠区间查询，跨午夜事件也能出现在当天视图。 */
@Dao interface ScheduleDao {
    @Query("DELETE FROM schedule WHERE source = 'COURSE'") suspend fun deleteCourses()
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(event: ScheduleEntity)
    @Query("SELECT * FROM schedule WHERE endTime > :from AND startTime < :to AND status != 'CANCELLED' ORDER BY startTime") fun range(from: Long, to: Long): Flow<List<ScheduleEntity>>
    @Query("SELECT * FROM schedule ORDER BY startTime") fun observeAll(): Flow<List<ScheduleEntity>>
    @Query("SELECT * FROM schedule WHERE startTime >= :now AND startTime <= :untilMs AND status = 'UPCOMING' ORDER BY startTime") suspend fun startingWithin(now: Long, untilMs: Long): List<ScheduleEntity>
    @Query("DELETE FROM schedule WHERE id = :id") suspend fun delete(id: String)
}
@Dao interface TodoDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(todo: TodoEntity)
    @Query("SELECT * FROM todo WHERE done = 0 ORDER BY dueTime IS NULL, dueTime, createdAt") fun undone(): Flow<List<TodoEntity>>
    @Query("SELECT * FROM todo ORDER BY done, createdAt DESC") fun observeAll(): Flow<List<TodoEntity>>
    @Query("UPDATE todo SET done = :done WHERE id = :id") suspend fun setDone(id: String, done: Boolean)
    @Query("DELETE FROM todo WHERE id = :id") suspend fun delete(id: String)
}

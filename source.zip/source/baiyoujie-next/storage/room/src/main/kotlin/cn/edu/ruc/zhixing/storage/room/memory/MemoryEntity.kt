package cn.edu.ruc.zhixing.storage.room.memory

import androidx.room.Entity
import androidx.room.PrimaryKey

/** memory 的持久化记录，与领域模型分离。 */
@Entity(tableName = "memory")
data class MemoryEntity(
    @PrimaryKey val id: String,
    val type: String,
    val content: String,
    val startTime: Long?,
    val endTime: Long?,
    val status: String,
    val source: String,
    val confidence: Float,
    val createdAt: Long,
)


package cn.edu.ruc.zhixing.storage.room

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * 用户反馈事件（显式/隐式标签）。
 *
 * 用户对某条消息点击「提升/降低重要性」时写入一条，作为在线学习模型的
 * 训练样本来源。同时保留 [content]/[senderName] 等字段，便于回溯与审计。
 */
@Entity(tableName = "feedback")
data class FeedbackEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    /** 对应的消息 id（关联 message 表）。 */
    val messageId: String,
    val channel: String,
    val senderName: String,
    val content: String,
    val isGroup: Boolean,
    /** 标签：1f = 更重要，0f = 不重要。 */
    val label: Float,
    /** 反馈产生时间（用于学习时序与审计）。 */
    val timestamp: Long,
)

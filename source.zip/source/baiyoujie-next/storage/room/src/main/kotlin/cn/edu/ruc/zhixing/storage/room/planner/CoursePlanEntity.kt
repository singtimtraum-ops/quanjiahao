package cn.edu.ruc.zhixing.storage.room.planner

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "course_plan")
data class CoursePlanEntity(@PrimaryKey val id: String = "default", val payload: String)
@Dao interface CoursePlanDao {
    @Query("SELECT * FROM course_plan WHERE id = 'default'") fun observe(): Flow<CoursePlanEntity?>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun save(value: CoursePlanEntity)
}

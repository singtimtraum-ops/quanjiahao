package cn.edu.ruc.zhixing.storage.room.planner

import androidx.room.*
import cn.edu.ruc.zhixing.core.model.planner.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "suggestion")
data class SuggestionEntity(
    @PrimaryKey val id: String, val sourceId: String, val source: String, val kind: String,
    val title: String, val startTime: Long?, val endTime: Long?, val dueTime: Long?,
    val location: String?, val status: String, val createdAt: Long,
)
fun Suggestion.toEntity() = SuggestionEntity(id, sourceId, source, kind.name, title, startTime, endTime, dueTime, location, status.name, createdAt)
fun SuggestionEntity.toModel() = Suggestion(id, sourceId, source, SuggestionKind.valueOf(kind), title, startTime, endTime, dueTime, location, SuggestionStatus.valueOf(status), createdAt)
@Dao interface SuggestionDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insert(item: SuggestionEntity): Long
    @Query("SELECT * FROM suggestion ORDER BY createdAt") fun observeAll(): Flow<List<SuggestionEntity>>
    @Query("SELECT * FROM suggestion WHERE id = :id") suspend fun get(id: String): SuggestionEntity?
    @Query("UPDATE suggestion SET status = :status WHERE id = :id AND status = 'PENDING'") suspend fun resolve(id: String, status: String): Int
    @Query("UPDATE suggestion SET title = :title WHERE id = :id") suspend fun rename(id: String, title: String)
}
@Entity(tableName = "extraction_receipt")
data class ExtractionReceipt(@PrimaryKey val id: String, val state: String, val attempts: Int, val updatedAt: Long)
@Dao interface ExtractionReceiptDao {
    @Query("SELECT * FROM extraction_receipt WHERE id = :id") suspend fun get(id: String): ExtractionReceipt?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(value: ExtractionReceipt)
}

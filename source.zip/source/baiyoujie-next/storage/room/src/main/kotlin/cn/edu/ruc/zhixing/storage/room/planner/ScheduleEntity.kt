package cn.edu.ruc.zhixing.storage.room.planner

import androidx.room.Entity
import androidx.room.PrimaryKey

/** schedule 的持久化记录，与领域模型分离。 */
@Entity(tableName = "schedule")
data class ScheduleEntity(
    @PrimaryKey val id: String,
    val title: String,
    val startTime: Long,
    val endTime: Long,
    val location: String?,
    val rrule: String?,
    val source: String,
    val status: String,
    val remindBeforeMin: Int,
)


package cn.edu.ruc.zhixing.storage.room

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/** 保留旧消息和分类反馈；不允许隐式删库迁移。 */
object CompanionMigrations {
    val FROM_4 = object : Migration(4, 5) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("CREATE TABLE IF NOT EXISTS course_plan (id TEXT NOT NULL PRIMARY KEY, payload TEXT NOT NULL)")
        }
    }
    val FROM_3 = object : Migration(3, 4) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("CREATE TABLE IF NOT EXISTS suggestion (id TEXT NOT NULL PRIMARY KEY, sourceId TEXT NOT NULL, source TEXT NOT NULL, kind TEXT NOT NULL, title TEXT NOT NULL, startTime INTEGER, endTime INTEGER, dueTime INTEGER, location TEXT, status TEXT NOT NULL, createdAt INTEGER NOT NULL)")
            db.execSQL("CREATE TABLE IF NOT EXISTS extraction_receipt (id TEXT NOT NULL PRIMARY KEY, state TEXT NOT NULL, attempts INTEGER NOT NULL, updatedAt INTEGER NOT NULL)")
        }
    }
    val FROM_1 = object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("CREATE TABLE IF NOT EXISTS feedback (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, messageId TEXT NOT NULL, channel TEXT NOT NULL, senderName TEXT NOT NULL, content TEXT NOT NULL, isGroup INTEGER NOT NULL, label REAL NOT NULL, timestamp INTEGER NOT NULL)")
        }
    }
    val FROM_2 = object : Migration(2, 3) {
        override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS chat_turn (`id` TEXT NOT NULL PRIMARY KEY, `sessionId` TEXT NOT NULL, `role` TEXT NOT NULL, `content` TEXT NOT NULL, `emotion` TEXT NOT NULL, `timestamp` INTEGER NOT NULL, `dayBucket` TEXT NOT NULL, `cardId` TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS memory (`id` TEXT NOT NULL PRIMARY KEY, `type` TEXT NOT NULL, `content` TEXT NOT NULL, `startTime` INTEGER, `endTime` INTEGER, `status` TEXT NOT NULL, `source` TEXT NOT NULL, `confidence` REAL NOT NULL, `createdAt` INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS schedule (`id` TEXT NOT NULL PRIMARY KEY, `title` TEXT NOT NULL, `startTime` INTEGER NOT NULL, `endTime` INTEGER NOT NULL, `location` TEXT, `rrule` TEXT, `source` TEXT NOT NULL, `status` TEXT NOT NULL, `remindBeforeMin` INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS todo (`id` TEXT NOT NULL PRIMARY KEY, `title` TEXT NOT NULL, `dueTime` INTEGER, `done` INTEGER NOT NULL, `sourceMessageId` TEXT, `createdAt` INTEGER NOT NULL)")
        }
    }
}

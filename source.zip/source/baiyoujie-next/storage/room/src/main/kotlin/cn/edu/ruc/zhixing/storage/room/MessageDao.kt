package cn.edu.ruc.zhixing.storage.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {
    @Query("SELECT DISTINCT senderName FROM message WHERE isGroup = :group")
    suspend fun knownNames(group: Boolean): List<String>

    @Query("SELECT * FROM message WHERE level IN ('P0_URGENT', 'P1_IMPORTANT') AND id NOT LIKE 'test-%' AND timestamp >= :since ORDER BY timestamp DESC LIMIT 10")
    suspend fun extractionCandidates(since: Long): List<MessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: MessageEntity)

    @Query("SELECT * FROM message WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): MessageEntity?

    @Query("SELECT * FROM message ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM message WHERE level = :level ORDER BY timestamp DESC")
    fun observeByLevel(level: String): Flow<List<MessageEntity>>

    @Query("DELETE FROM message WHERE id = :id")
    suspend fun delete(id: String)

    @Query("DELETE FROM message")
    suspend fun clear()
}

package cn.edu.ruc.zhixing.storage.room

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import cn.edu.ruc.zhixing.storage.room.chat.*
import cn.edu.ruc.zhixing.storage.room.memory.*
import cn.edu.ruc.zhixing.storage.room.planner.*

@Database(
    entities = [MessageEntity::class, FeedbackEvent::class, ChatTurnEntity::class, MemoryEntity::class, ScheduleEntity::class, TodoEntity::class, SuggestionEntity::class, ExtractionReceipt::class, CoursePlanEntity::class],
    version = 5,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun messageDao(): MessageDao
    abstract fun feedbackDao(): FeedbackDao
    abstract fun chatDao(): ChatDao
    abstract fun memoryDao(): MemoryDao
    abstract fun scheduleDao(): ScheduleDao
    abstract fun todoDao(): TodoDao
    abstract fun suggestionDao(): SuggestionDao
    abstract fun extractionReceiptDao(): ExtractionReceiptDao
    abstract fun coursePlanDao(): CoursePlanDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "zhixing.db",
                )
                    .addMigrations(CompanionMigrations.FROM_1, CompanionMigrations.FROM_2, CompanionMigrations.FROM_3, CompanionMigrations.FROM_4)
                    .build()
                    .also { INSTANCE = it }
            }
    }
}

package cn.edu.ruc.zhixing.storage.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface FeedbackDao {

    @Insert
    suspend fun insert(event: FeedbackEvent)

    @Query("SELECT * FROM feedback ORDER BY id")
    fun observeAll(): Flow<List<FeedbackEvent>>

    @Query("SELECT COUNT(*) FROM feedback")
    suspend fun count(): Int
}

package cn.edu.ruc.zhixing.storage.room

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** 消息落库实体。索引 channel+sender+timestamp 用于查询与去重。 */
@Entity(
    tableName = "message",
    indices = [
        Index(value = ["channel", "timestamp"]),
        Index(value = ["channel", "senderId"]),
    ],
)
data class MessageEntity(
    @PrimaryKey val id: String,
    val channel: String,
    val senderId: String,
    val senderName: String,
    val isGroup: Boolean,
    val content: String,
    val timestamp: Long,
    val isSelf: Boolean,
    val quality: String,
    // 分类结果
    val level: String,
    val score: Float,
    val category: String,
    val reason: String,
)

package cn.edu.ruc.zhixing.storage.room.planner

import androidx.room.withTransaction
import cn.edu.ruc.zhixing.storage.room.AppDatabase

class SuggestionRepository(private val db: AppDatabase) {
    suspend fun confirm(id: String, title: String) = db.withTransaction {
        require(title.isNotBlank() && title.length <= 200) { "请填写有效标题。" }
        val row = db.suggestionDao().get(id) ?: return@withTransaction
        if (db.suggestionDao().resolve(id, "ACCEPTED") != 1) return@withTransaction
        db.suggestionDao().rename(id, title.trim())
        when (row.kind) {
            "TODO" -> db.todoDao().upsert(TodoEntity(id, title.trim(), row.dueTime, false, row.sourceId, System.currentTimeMillis()))
            "EVENT" -> {
                val start = requireNotNull(row.startTime); val end = requireNotNull(row.endTime)
                require(end > start) { "事件起止时间无效。" }
                db.scheduleDao().upsert(ScheduleEntity(id, title.trim(), start, end, row.location, null, row.source, "UPCOMING", 0))
            }
            else -> error("无法识别的建议类型。")
        }
    }
    suspend fun dismiss(id: String) { db.suggestionDao().resolve(id, "DISMISSED") }
}

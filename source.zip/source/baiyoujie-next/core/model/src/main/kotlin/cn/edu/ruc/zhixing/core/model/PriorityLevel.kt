package cn.edu.ruc.zhixing.core.model

import kotlinx.serialization.Serializable

/**
 * 消息的重要性级别（最终输出给用户的分级）。
 * 对应产品里的差异化提醒策略。
 */
@Serializable
enum class PriorityLevel {
    /** 紧急：应立刻打断用户（强提醒 + 震动 + 横幅）。 */
    P0_URGENT,

    /** 重要：普通但需要近期处理。 */
    P1_IMPORTANT,

    /** 普通：可稍后查看。 */
    P2_NORMAL,

    /** 可忽略：折叠 / 免打扰。 */
    P3_IGNORABLE,
}

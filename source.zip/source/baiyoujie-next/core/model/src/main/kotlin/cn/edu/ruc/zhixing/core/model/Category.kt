package cn.edu.ruc.zhixing.core.model

import kotlinx.serialization.Serializable

/**
 * 消息的业务类别。用于细分“为什么这条消息重要/不重要”。
 */
@Serializable
enum class Category {
    WORK,       // 工作
    FAMILY,     // 家人
    CONTACT,    // 熟人/联系人
    AFFAIR,     // 事务效率（快递/预约/缴费等）
    PROMOTION,  // 广告/营销
    CHAT,       // 闲聊
    SYSTEM,     // 系统/验证码
    UNKNOWN,
}

package cn.edu.ruc.zhixing.core.model

import kotlinx.serialization.Serializable

/**
 * 聊天软件渠道。每个渠道对应一个 [MessageAcquirer]/解析器，
 * 新增软件时只需在此枚举增加一项并注册对应 SourceAdapter。
 */
@Serializable
enum class Channel {
    WECHAT,       // 微信
    QQ,           // 腾讯 QQ
    DINGTALK,     // 钉钉
    WECHAT_WORK,  // 企业微信
    SMS,          // 短信
    TELEGRAM,     // 预留
    OTHER,
}

package cn.edu.ruc.zhixing.core.model.companion

import kotlinx.serialization.Serializable

/** 本地对话角色，不包含代用户发送外部消息的角色。 */
@Serializable enum class ChatRole { USER, AI, SYSTEM }
@Serializable enum class EmotionLabel { NEUTRAL, HAPPY, SAD, ANGRY, STRESSED, OVERWHELMED, PROCRASTINATING, CRISIS }
@Serializable enum class ChatMode { NORMAL, SOOTHING, PLANNING, FOCUS }
@Serializable data class CardRef(val id: String)
/** 按本地日期分桶保存的对话记录。 */
@Serializable data class ChatTurn(
    val id: String, val sessionId: String = "default", val role: ChatRole,
    val content: String, val emotion: EmotionLabel = EmotionLabel.NEUTRAL,
    val timestamp: Long, val dayBucket: String, val hasCard: CardRef? = null,
)
@Serializable data class LlmMsg(val role: String, val content: String?)

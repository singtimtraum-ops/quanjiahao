package cn.edu.ruc.zhixing.core.model.focus

import kotlinx.serialization.Serializable

@Serializable enum class AppointmentState { PENDING, STARTED, EXPIRED, CANCELLED }
@Serializable data class Appointment(
    val id: String, val taskTitle: String, val pomodoroMin: Int = 25,
    val deadlineAt: Long, val state: AppointmentState,
)
/** 后续计时以持久化的起止时间恢复；本阶段不启动实际专注会话。 */
@Serializable data class FocusSession(
    val id: String, val appointmentId: String?, val taskTitle: String,
    val plannedMin: Int, val startedAt: Long, val endedAt: Long?,
    val completed: Boolean, val interrupted: Boolean = false,
)
@Serializable data class FocusChain(val id: String = "main", val count: Int = 0, val lastCompletedDay: String? = null)
@Serializable data class ChainException(val id: String, val description: String, val createdAt: Long)

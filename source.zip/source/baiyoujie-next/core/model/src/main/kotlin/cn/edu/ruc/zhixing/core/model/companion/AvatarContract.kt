package cn.edu.ruc.zhixing.core.model.companion

import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.Serializable

/** Stable semantic contract between chat/app logic and zzk's visual implementation. */
@Serializable enum class AvatarMood { NEUTRAL, HAPPY, SAD, STRESSED, FOCUS }
@Serializable enum class AvatarScene { DAY, NIGHT, CHATTING, FOCUSING }
@Serializable data class AvatarState(
    val mood: AvatarMood = AvatarMood.NEUTRAL,
    val scene: AvatarScene = AvatarScene.DAY,
    val speaking: Boolean = false,
)
@Serializable sealed interface AvatarSignal {
    @Serializable data class EmotionChanged(val emotion: EmotionLabel) : AvatarSignal
    @Serializable data class SpeakingChanged(val speaking: Boolean) : AvatarSignal
    @Serializable data class SceneChanged(val scene: AvatarScene) : AvatarSignal
}
interface AvatarController {
    val state: StateFlow<AvatarState>
    fun accept(signal: AvatarSignal)
}

package cn.edu.ruc.zhixing.core.model

import kotlinx.serialization.Serializable

/**
 * 分类结果。除等级和置信度外，特别保留 [reason] 作为**可解释性**输出，
 * 让用户看到“为什么判它重要”，这是本产品赢得信任的关键。
 */
@Serializable
data class Classification(
    val level: PriorityLevel,
    /** 0..1 归一化得分。 */
    val score: Float,
    val category: Category,
    val reason: String,
)

package cn.edu.ruc.zhixing.core.model.planner

import kotlinx.serialization.Serializable
import java.time.*
import java.util.UUID

@Serializable data class LessonSlot(val number: Int, val start: String, val end: String)
@Serializable enum class WeekPattern { ALL, ODD, EVEN }
@Serializable data class Course(
    val id: String, val title: String, val dayOfWeek: Int, val firstLesson: Int, val lastLesson: Int,
    val firstWeek: Int, val lastWeek: Int, val pattern: WeekPattern = WeekPattern.ALL, val location: String = "",
)
@Serializable data class CoursePlan(
    val termStart: String = "", val totalWeeks: Int = 20,
    val zoneId: String = ZoneId.systemDefault().id,
    val slots: List<LessonSlot> = emptyList(), val courses: List<Course> = emptyList(),
    val recurrences: Map<String, String> = emptyMap(),
)

/** 教学周模板按确定的日期展开；不把已展开实例再次当作 RRULE 主事件。 */
object CoursePlanner {
    fun validate(plan: CoursePlan) {
        val start = runCatching { LocalDate.parse(plan.termStart) }.getOrNull()
        require(start != null && start.dayOfWeek == DayOfWeek.MONDAY) { "请填写第一教学周的周一日期。" }
        require(plan.totalWeeks in 1..40) { "学期长度应为 1 至 40 周。" }
        ZoneId.of(plan.zoneId)
        require(plan.slots.size <= 20 && plan.slots.map { it.number }.distinct().size == plan.slots.size) { "节次不能重复，最多设置 20 节。" }
        val slots = plan.slots.sortedBy { it.number }
        slots.forEach {
            require(it.number in 1..20) { "节次应为 1 至 20。" }
            require(LocalTime.parse(it.end) > LocalTime.parse(it.start)) { "每节课的结束时间必须晚于开始时间。" }
        }
        slots.zipWithNext().forEach { (a, b) ->
            require(LocalTime.parse(a.end) <= LocalTime.parse(b.start)) { "节次时间不能重叠或倒序。" }
        }
        require(plan.courses.size <= 60 && plan.courses.map { it.id }.distinct().size == plan.courses.size) { "课程不能重复，最多添加 60 门。" }
        plan.courses.forEach { course ->
            require(course.title.isNotBlank() && course.title.length <= 100) { "请填写课程名称（最多 100 字）。" }
            require(course.dayOfWeek in 1..7) { "请选择星期。" }
            require(course.firstWeek in 1..plan.totalWeeks && course.lastWeek in course.firstWeek..plan.totalWeeks) { "课程周次必须在学期范围内。" }
            require((course.firstWeek..course.lastWeek).any { week -> course.pattern == WeekPattern.ALL ||
                (course.pattern == WeekPattern.ODD && week % 2 == 1) || (course.pattern == WeekPattern.EVEN && week % 2 == 0) }) { "单双周与周次范围不匹配，无法生成课程。" }
            require(course.firstLesson <= course.lastLesson && course.firstLesson >= 1 && course.lastLesson <= 20) { "请检查课程节次范围。" }
            require((course.firstLesson..course.lastLesson).all { n -> slots.any { it.number == n } }) { "请先补齐课程使用的全部节次时间。" }
        }
    }
    fun expand(plan: CoursePlan): List<ScheduleEvent> {
        validate(plan)
        val monday = LocalDate.parse(plan.termStart)
        val zone = ZoneId.of(plan.zoneId)
        return plan.courses.flatMap { course ->
            (course.firstWeek..course.lastWeek).filter { week ->
                course.pattern == WeekPattern.ALL || (course.pattern == WeekPattern.ODD && week % 2 == 1) ||
                    (course.pattern == WeekPattern.EVEN && week % 2 == 0)
            }.map { week ->
                val day = monday.plusWeeks((week - 1).toLong()).plusDays((course.dayOfWeek - 1).toLong())
                val start = day.atTime(LocalTime.parse(plan.slots.first { it.number == course.firstLesson }.start)).atZone(zone).toInstant().toEpochMilli()
                val end = day.atTime(LocalTime.parse(plan.slots.first { it.number == course.lastLesson }.end)).atZone(zone).toInstant().toEpochMilli()
                val id = "course-" + UUID.nameUUIDFromBytes("${course.id}:$day".toByteArray(Charsets.UTF_8))
                ScheduleEvent(id, course.title, start, end, course.location.ifBlank { null }, source = EventSource.COURSE, remindBeforeMin = 0)
            }
        }.sortedBy { it.startTime }
    }
    fun recurrence(course: Course, plan: CoursePlan): String {
        validate(plan.copy(courses = listOf(course)))
        val day = listOf("MO", "TU", "WE", "TH", "FR", "SA", "SU")[course.dayOfWeek - 1]
        val count = expand(plan.copy(courses = listOf(course))).size
        return "FREQ=WEEKLY;INTERVAL=${if (course.pattern == WeekPattern.ALL) 1 else 2};BYDAY=$day;COUNT=$count"
    }
}

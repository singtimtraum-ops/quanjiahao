package cn.edu.ruc.zhixing.core.model.planner

import kotlinx.serialization.Serializable

@Serializable enum class SuggestionKind { TODO, EVENT }
@Serializable enum class SuggestionStatus { PENDING, ACCEPTED, DISMISSED }
@Serializable data class Suggestion(
    val id: String, val sourceId: String, val source: String, val kind: SuggestionKind,
    val title: String, val startTime: Long? = null, val endTime: Long? = null,
    val dueTime: Long? = null, val location: String? = null,
    val status: SuggestionStatus = SuggestionStatus.PENDING, val createdAt: Long,
)

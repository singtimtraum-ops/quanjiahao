package cn.edu.ruc.zhixing.core.model.memory

import kotlinx.serialization.Serializable

@Serializable enum class MemoryType { FACT, EVENT, PREFERENCE, OBLIGATION }
@Serializable enum class MemoryStatus { ACTIVE, EXPIRED, DONE, INVALID }
/** 事件结束后才过期；完成、失效和过期记忆均不进入活动上下文。 */
@Serializable data class MemoryItem(
    val id: String, val type: MemoryType, val content: String,
    val startTime: Long? = null, val endTime: Long? = null,
    val status: MemoryStatus = MemoryStatus.ACTIVE, val source: String,
    val confidence: Float = 1f, val createdAt: Long,
)

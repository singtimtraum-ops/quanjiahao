package cn.edu.ruc.zhixing.core.model.planner

import kotlinx.serialization.Serializable
import kotlinx.coroutines.flow.Flow

@Serializable enum class EventSource { SYSTEM_CALENDAR, COURSE, CHAT, MESSAGE, MANUAL }
@Serializable enum class EventStatus { UPCOMING, ONGOING, DONE, CANCELLED }
@Serializable data class ScheduleEvent(
    val id: String, val title: String, val startTime: Long, val endTime: Long,
    val location: String? = null, val rrule: String? = null, val source: EventSource,
    val status: EventStatus = EventStatus.UPCOMING, val remindBeforeMin: Int = 10,
)
@Serializable data class TodoItem(
    val id: String, val title: String, val dueTime: Long? = null,
    val done: Boolean = false, val sourceMessageId: String? = null, val createdAt: Long,
)
/** 领域层的日程读取接口，不依赖 Room 或 Android。 */
interface ScheduleStore {
    suspend fun upcoming(from: Long, until: Long): List<ScheduleEvent>
    fun observeEvents(): Flow<List<ScheduleEvent>>
    suspend fun save(event: ScheduleEvent)
}

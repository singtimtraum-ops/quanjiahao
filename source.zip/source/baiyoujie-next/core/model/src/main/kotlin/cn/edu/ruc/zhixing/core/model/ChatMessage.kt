package cn.edu.ruc.zhixing.core.model

import kotlinx.serialization.Serializable

/**
 * 统一消息模型 —— 屏蔽不同聊天软件、不同采集层（通知/无障碍/取库）的字段差异。
 * 这是整个模块化体系的数据核心，采集层产出它，分类层消费它。
 */
@Serializable
data class ChatMessage(
    /** 全局唯一 id：由 channel + 源头 id + 时间戳合成，用于跨层去重。 */
    val id: String,
    val channel: Channel,
    val senderId: String,
    val senderName: String,
    /** 是否群聊（用于特征与分类）。 */
    val isGroup: Boolean,
    val content: String,
    val timestamp: Long,
    /** 是否本人发送（取库层有 isSend，通知层通常无）。 */
    val isSelf: Boolean = false,
    /** 数据来源质量。 */
    val quality: SourceQuality,
    /** 原始载荷兜底，便于溯源与调试，不入分类主链路。 */
    val raw: String = "",
)

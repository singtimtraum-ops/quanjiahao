package cn.edu.ruc.zhixing.core.model

import kotlinx.serialization.Serializable

/**
 * 一条消息的来源质量（数据完整度）。
 * 上层分类引擎可据此差异对待：DATABASE 层的消息字段最全（含历史与全文），
 * NOTIFICATION 层只有摘要，ACCESSIBILITY 层介于二者之间。
 */
@Serializable
enum class SourceQuality {
    /** 通知监听摘要：实时、免 Root，但通常只有 title+text 摘要。 */
    NOTIFICATION,

    /** 无障碍读屏增强：能拿到当前屏内更多正文，但受界面结构限制。 */
    ACCESSIBILITY,

    /** Root 取库：完整历史聊天记录（字段最全，仅自用/内测层）。 */
    DATABASE,
}

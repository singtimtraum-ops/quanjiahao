package cn.edu.ruc.zhixing.core.common.time

import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset

/**
 * 时间工具。分类引擎需要“时段”特征（深夜/工作/休息），这里统一提供。
 */
object TimeKt {
    fun nowMillis(): Long = System.currentTimeMillis()

    fun hourOfDay(millis: Long, zone: ZoneId = ZoneId.systemDefault()): Int =
        LocalDateTime.ofInstant(Instant.ofEpochMilli(millis), zone).hour

    fun dateKey(millis: Long, zone: ZoneId = ZoneId.systemDefault()): Long =
        Instant.ofEpochMilli(millis).atZone(zone).toLocalDate()
            .atStartOfDay(zone).toInstant().toEpochMilli()

    /** 简单时段归类：0-6 深夜，7-12 上午，12-18 下午，18-24 晚间。 */
    fun timeSlot(millis: Long): TimeSlot {
        return when (hourOfDay(millis)) {
            in 0..6 -> TimeSlot.NIGHT
            in 7..11 -> TimeSlot.MORNING
            in 12..17 -> TimeSlot.AFTERNOON
            else -> TimeSlot.EVENING
        }
    }

    enum class TimeSlot { NIGHT, MORNING, AFTERNOON, EVENING }
}

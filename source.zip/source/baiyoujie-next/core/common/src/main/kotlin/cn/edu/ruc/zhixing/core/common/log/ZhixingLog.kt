package cn.edu.ruc.zhixing.core.common.log

/**
 * 轻量日志抽象。生产可换成 Timber / 自有实现，模块间不直接依赖具体日志库。
 */
object ZhixingLog {
    private var impl: LogImpl = NoOpLog

    fun set(implementation: LogImpl) { impl = implementation }

    fun d(tag: String, msg: String) = impl.d(tag, msg)
    fun i(tag: String, msg: String) = impl.i(tag, msg)
    fun w(tag: String, msg: String) = impl.w(tag, msg)
    fun e(tag: String, msg: String, t: Throwable? = null) = impl.e(tag, msg, t)

    interface LogImpl {
        fun d(tag: String, msg: String)
        fun i(tag: String, msg: String)
        fun w(tag: String, msg: String)
        fun e(tag: String, msg: String, t: Throwable?)
    }

    private object NoOpLog : LogImpl {
        override fun d(tag: String, msg: String) {}
        override fun i(tag: String, msg: String) {}
        override fun w(tag: String, msg: String) {}
        override fun e(tag: String, msg: String, t: Throwable?) {}
    }
}

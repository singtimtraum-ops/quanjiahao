package cn.edu.ruc.zhixing.engine.adaptive

import cn.edu.ruc.zhixing.core.model.Category
import cn.edu.ruc.zhixing.core.model.ChatMessage
import cn.edu.ruc.zhixing.core.model.Classification
import cn.edu.ruc.zhixing.core.model.PriorityLevel
import cn.edu.ruc.zhixing.engine.classifier.ImportanceClassifier
import cn.edu.ruc.zhixing.engine.feature.FeatureExtractor
import cn.edu.ruc.zhixing.engine.rule.RuleClassifier

/**
 * 自适应分类器：规则版（可解释、冷启动兜底） + 在线学习模型（从你的反馈学）。
 *
 * 对每条消息特征向量用 [AdaptiveModel] 给出“学习分”与 [conf] 置信度：
 *  - *置信度低*（样本少/预测模糊）→ 完全退回规则基分，保证冷启动不瞎猜；
 *  - *置信度高* → 用置信度加权混合「规则基分」与「学习分」，并按新得分重定级别；
 *  - 结果仍带可解释 [Classification.reason]，并注明学习是否介入。
 *
 * 学习模型由用户对历史消息的「提升/降低重要性」反馈驱动（见 AppContainer.recordFeedback）。
 */
class AdaptiveImportanceClassifier(
    private val base: RuleClassifier,
    private val model: AdaptiveModel,
    private val featureExtractor: FeatureExtractor,
    private val burstContext: FeatureExtractor.FeatureContext,
    private val vectorizer: FeatureVectorizer,
) : ImportanceClassifier {

    override fun classify(msg: ChatMessage): Classification {
        val features = featureExtractor.extract(msg, burstContext)
        val x = vectorizer.vectorize(features)
        val baseClassification = base.classify(features)

        val (learned, conf) = model.predict(x)
        val confText = "%.2f".format(conf)

        // 冷启动 / 预测模糊：保守，只用规则
        if (conf < MIN_CONFIDENCE) {
            return baseClassification.copy(reason = "${baseClassification.reason}｜习惯学习未介入(置信 $confText)")
        }

        val blended = blend(baseClassification.score, learned, conf)
        val level = base.levelFor(blended)
        val category = if (conf >= HIGH_CONF) categoryFor(level, baseClassification.category)
        else baseClassification.category
        val reason = "${baseClassification.reason}｜叠加你的习惯(置信 $confText)"

        return Classification(level, blended, category, reason)
    }

    private fun blend(baseScore: Float, learned: Float, conf: Float): Float =
        (baseScore * (1 - conf) + learned * conf).coerceIn(0f, 1f)

    private fun categoryFor(level: PriorityLevel, fallback: Category): Category = when (level) {
        PriorityLevel.P0_URGENT, PriorityLevel.P1_IMPORTANT -> Category.WORK
        else -> fallback
    }

    private companion object {
        const val MIN_CONFIDENCE = 0.35f
        const val HIGH_CONF = 0.7f
    }
}

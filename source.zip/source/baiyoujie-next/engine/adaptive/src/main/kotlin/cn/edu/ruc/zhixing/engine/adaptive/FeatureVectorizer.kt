package cn.edu.ruc.zhixing.engine.adaptive

import cn.edu.ruc.zhixing.core.common.time.TimeKt
import cn.edu.ruc.zhixing.engine.feature.MessageFeatures

/**
 * 把特征 [MessageFeatures] 转成数值向量，供在线学习模型使用。
 * 维度固定（[dim]），在 [AdaptiveModel] 初始化时保持一致。
 */
class FeatureVectorizer {

    val dim = 15

    /** 与 vectorize 顺序一一对应的特征名（用于把模型权重映射回人类可读信号）。 */
    val featureLabels: List<String> = listOf(
        "发送者白名单", "发送者黑名单", "群聊", "含关键词", "关键词命中",
        "连发", "询问", "长度", "夜间时段", "上午时段", "下午时段", "晚间时段",
        "工作时段", "含附件", "官方号",
    )

    fun vectorize(f: MessageFeatures): FloatArray {
        val x = FloatArray(dim)
        var i = 0
        // 发送者
        x[i++] = bool(f.isWhitelisted)
        x[i++] = bool(f.isBlacklisted)
        // 内容
        x[i++] = bool(f.isGroup)
        x[i++] = bool(f.containsKeyword)
        x[i++] = (f.keywordHits / 5f).coerceIn(0f, 1f)
        x[i++] = bool(f.isBurst)
        x[i++] = bool(f.isQuestion)
        x[i++] = (f.length / 100f).coerceIn(0f, 1f)
        // 时段 one-hot
        x[i++] = if (f.timeSlot == TimeKt.TimeSlot.NIGHT) 1f else 0f
        x[i++] = if (f.timeSlot == TimeKt.TimeSlot.MORNING) 1f else 0f
        x[i++] = if (f.timeSlot == TimeKt.TimeSlot.AFTERNOON) 1f else 0f
        x[i++] = if (f.timeSlot == TimeKt.TimeSlot.EVENING) 1f else 0f
        // 其他
        x[i++] = bool(f.inWorkingHours)
        x[i++] = bool(f.hasAttachment)
        x[i++] = bool(f.isVerifiedSender)
        return x
    }

    private fun bool(b: Boolean): Float = if (b) 1f else 0f
}

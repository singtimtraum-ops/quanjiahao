package cn.edu.ruc.zhixing.engine.adaptive

import kotlin.math.abs
import kotlin.math.exp

/**
 * 在线逻辑回归模型（本地、极小、离线）。
 *
 * 输入特征向量 x，输出“重要性预测” sigmoid(w·x + b) ∈ [0,1]，以及一个
 * [confidence]。训练用在线梯度下降（每次一条样本更新），带 L2 正则防过拟合；
 * [confidence] 结合“样本数（冷启动衰减）”与“输出距 0.5 的边距”，
 * 供上层决定是否用学习结果覆盖规则基分——样本少或预测接近 0.5 时就保守退回规则。
 *
 * 模型本身是纯 JVM、无状态持久化要求；权重可用 [toArray]/[fromArray] 拿到外部持久化。
 */
class AdaptiveModel(private val featureDim: Int) {

    private val w = DoubleArray(featureDim)
    private var bias = 0.0
    private var samples = 0

    /** 训练样本数（用于冷启动置信度与外部展示）。 */
    val sampleCount: Int get() = samples

    /**
     * 预测。
     * @return Pair(score 0..1, confidence 0..1)
     */
    @Synchronized
    fun predict(x: FloatArray): Pair<Float, Float> {
        val p = sigmoid(dot(x) + bias)
        return p.toFloat() to confidence(p)
    }

    /** 在线更新。label ∈ {0,1}（0=不重要,1=重要）。 */
    @Synchronized
    fun update(x: FloatArray, label: Float, lr: Double = 0.3) {
        val p = sigmoid(dot(x) + bias)
        val err = p - label
        for (i in w.indices) {
            w[i] -= lr * err * x[i] + REG * w[i]
        }
        bias -= lr * err
        samples++
    }

    private fun dot(x: FloatArray): Double {
        var s = 0.0
        for (i in w.indices) s += w[i] * x[i]
        return s
    }

    private fun confidence(p: Double): Float {
        // 样本越多越敢用；输出越远离 0.5 越有信心
        val nFactor = samples.toFloat() / (samples + 6f).toFloat()
        val margin = abs(2.0 * p - 1.0).toFloat()
        return (nFactor * (0.25f + 0.75f * margin)).coerceIn(0f, 1f)
    }

    // ---- 持久化辅助 ----
    fun toArray(): FloatArray {
        val arr = FloatArray(w.size + 1)
        for (i in w.indices) arr[i] = w[i].toFloat()
        arr[w.size] = bias.toFloat()
        return arr
    }

    fun fromArray(arr: FloatArray) {
        if (arr.size != w.size + 1) return
        for (i in w.indices) w[i] = arr[i].toDouble()
        bias = arr[arr.size - 1].toDouble()
    }

    fun setSampleCount(n: Int) { samples = n }

    private fun sigmoid(z: Double): Double = 1.0 / (1.0 + exp(-z))

    private companion object { const val REG = 1e-4 }
}

package cn.edu.ruc.zhixing.engine.rule

import kotlinx.serialization.Serializable

/**
 * 可配置的规则权重。为支持“不重新发版即可调整分类策略”，规则库独立成
 * 可序列化模型，可落盘为 JSON 或从远端下拉热更新。
 */
@Serializable
data class RuleConfig(
    val weights: Weights = Weights(),
    val thresholds: Thresholds = Thresholds(),
)

@Serializable
data class Weights(
    val whitelisted: Float = 0.45f,
    val blacklisted: Float = -0.6f,
    val group: Float = -0.15f,
    val keyword: Float = 0.35f,
    val burst: Float = 0.15f,
    val question: Float = 0.2f,
    val workingHours: Float = 0.1f,
    val attachment: Float = 0.15f,
    val verifiedSender: Float = 0.25f,
)

@Serializable
data class Thresholds(
    val p0: Float = 0.80f,
    val p1: Float = 0.55f,
    val p2: Float = 0.30f,
)

/** 构造可解释 reason 的贡献项。 */
internal data class Contribution(val label: String, val weight: Float)

package cn.edu.ruc.zhixing.engine.rule

import cn.edu.ruc.zhixing.core.model.Category
import cn.edu.ruc.zhixing.core.model.Classification
import cn.edu.ruc.zhixing.core.model.PriorityLevel
import cn.edu.ruc.zhixing.engine.feature.MessageFeatures

/**
 * 规则分类器 —— MVP 主引擎（毫秒级、可解释、可热更）。
 *
 * 对特征加权求和得到 0..1 得分，按阈值映射到 P0~P3，并生成中文 reason
 * 说明“为什么这么判”。后续替换为模型时，分类器接口不变。
 */
class RuleClassifier(private val config: RuleConfig = RuleConfig()) {

    val thresholds: Thresholds get() = config.thresholds

    /** 按阈值把得分映射为重要性级别（供自适应层复用，避免重复实现）。 */
    fun levelFor(score: Float): PriorityLevel = when {
        score >= config.thresholds.p0 -> PriorityLevel.P0_URGENT
        score >= config.thresholds.p1 -> PriorityLevel.P1_IMPORTANT
        score >= config.thresholds.p2 -> PriorityLevel.P2_NORMAL
        else -> PriorityLevel.P3_IGNORABLE
    }

    fun classify(f: MessageFeatures): Classification {
        val contributions = buildList {
            if (f.isWhitelisted) add(Contribution("联系人", config.weights.whitelisted))
            if (f.isBlacklisted) add(Contribution("黑名单", config.weights.blacklisted))
            if (f.isGroup) add(Contribution("群聊", config.weights.group))
            if (f.containsKeyword) add(Contribution("关键词×${f.keywordHits}", config.weights.keyword))
            if (f.isBurst) add(Contribution("连发", config.weights.burst))
            if (f.isQuestion) add(Contribution("询问", config.weights.question))
            if (f.inWorkingHours) add(Contribution("工作时段", config.weights.workingHours))
            if (f.hasAttachment) add(Contribution("含链接/附件", config.weights.attachment))
            if (f.isVerifiedSender) add(Contribution("官方号", config.weights.verifiedSender))
        }

        val raw = contributions.sumOf { it.weight.toDouble() }.toFloat()
        val score = raw.coerceIn(0f, 1f)
        val level = levelFor(score)
        val category = inferCategory(f)
        val reason = if (contributions.isEmpty()) {
            "无明显重要特征，按普通消息处理"
        } else {
            contributions.joinToString("，") { "${it.label} +${it.weight}" }
        }

        return Classification(level, score, category, reason)
    }

    private fun inferCategory(f: MessageFeatures): Category = when {
        f.isBlacklisted -> Category.PROMOTION
        f.isGroup && f.containsKeyword -> Category.WORK
        f.isVerifiedSender -> Category.SYSTEM
        f.isWhitelisted -> Category.CONTACT
        else -> Category.CHAT
    }
}

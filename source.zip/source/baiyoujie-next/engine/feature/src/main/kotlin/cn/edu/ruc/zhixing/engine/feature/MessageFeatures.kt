package cn.edu.ruc.zhixing.engine.feature

import cn.edu.ruc.zhixing.core.common.time.TimeKt
import cn.edu.ruc.zhixing.core.model.ChatMessage

/**
 * 消息特征 —— 分类引擎的输入。
 *
 * 特征工程把原始消息转成结构化、可打分的向量，规则分类器与未来的模型分类器
 * 都消费同一份特征，做到“换分类器不改特征层”。
 */
data class MessageFeatures(
    // 发送者
    val isWhitelisted: Boolean,
    val isBlacklisted: Boolean,
    val isGroup: Boolean,
    // 内容
    val containsKeyword: Boolean,
    val keywordHits: Int,
    val isBurst: Boolean,          // 是否连发刷屏
    val isQuestion: Boolean,       // 是否含疑问请求（"？"/等/吗/在吗）
    val length: Int,
    // 时间
    val timeSlot: TimeKt.TimeSlot,
    val inWorkingHours: Boolean,
    // 其他
    val hasAttachment: Boolean,    // 链接/图/文件等
    val isVerifiedSender: Boolean, // 企业/官方号等
)

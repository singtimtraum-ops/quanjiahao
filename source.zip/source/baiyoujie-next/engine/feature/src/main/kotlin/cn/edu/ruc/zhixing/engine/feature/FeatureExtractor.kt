package cn.edu.ruc.zhixing.engine.feature

import cn.edu.ruc.zhixing.core.common.time.TimeKt
import cn.edu.ruc.zhixing.core.model.ChatMessage

/**
 * 特征提取器。规则与模型共用，保证特征口径一致、可复现。
 */
class FeatureExtractor(
    private val whitelist: Set<String> = emptySet(),
    private val blacklist: Set<String> = emptySet(),
    private val keywordGroups: List<List<String>> = defaultKeywords(),
) {

    fun extract(msg: ChatMessage, context: FeatureContext): MessageFeatures {
        val sender = msg.senderName
        return MessageFeatures(
            isWhitelisted = sender in whitelist || msg.senderId in whitelist,
            isBlacklisted = sender in blacklist || msg.senderId in blacklist,
            isGroup = msg.isGroup,
            containsKeyword = keywordGroups.flatten().any { msg.content.contains(it) },
            keywordHits = keywordGroups.flatten().count { msg.content.contains(it) },
            isBurst = context.recentBurst(sender),
            isQuestion = urgentQuestionPattern.matches(msg.content),
            length = msg.content.length,
            timeSlot = TimeKt.timeSlot(msg.timestamp),
            inWorkingHours = msg.timestamp.isWorkingHours(),
            hasAttachment = msg.content.contains("http") || msg.content.contains("[图") ||
                msg.content.contains("[文件"),
            isVerifiedSender = verifiedSenderSuffixes.any { sender.endsWith(it) },
        )
    }

    interface FeatureContext {
        fun recentBurst(senderName: String): Boolean
    }

    private fun Long.isWorkingHours(): Boolean = when (TimeKt.timeSlot(this)) {
        TimeKt.TimeSlot.MORNING, TimeKt.TimeSlot.AFTERNOON -> true
        else -> false
    }

    private val urgentQuestionPattern = Regex("(在吗|？|\\?|等{1,3}|马上|尽快|急|现在)")
    private val verifiedSenderSuffixes = listOf("官方", "服务号", "企业", "客服")

    companion object {
        fun defaultKeywords(): List<List<String>> = listOf(
            // 紧急
            listOf("紧急", "马上", "立刻", "尽快", "急", "现在", "deadline", "今天之前"),
            // 工作/领导
            listOf("领导", "老板", "合同", "审批", "开会", "汇报", "负责人", "师傅", "老师"),
            // 家人/关系
            listOf("妈", "爸", "家人", "家", "回家", "老婆", "老公", "孩子"),
            // 事务
            listOf("快递", "取件", "缴费", "预约", "发票", "转账", "还款", "面谈"),
            // 弱相关
            listOf("哈哈", "哈哈哈", "在吗?", "有消息", "收到", "好的", "嗯嗯"),
        )
    }
}

package cn.edu.ruc.zhixing.engine.classifier

import cn.edu.ruc.zhixing.core.model.ChatMessage
import cn.edu.ruc.zhixing.core.model.Classification

/**
 * 分类器统一接口 —— 模块化的另一核心。
 *
 * 规则版 / 本地模型版 / LLM 版都实现本接口，[ImportanceEngine] 在外部
 * 以“级联”方式组合它们：先用快的过滤，再交由模型，接口不变。
 * 换实现（把规则换成模型）完全不影响上层。
 */
fun interface ImportanceClassifier {
    fun classify(msg: ChatMessage): Classification
}

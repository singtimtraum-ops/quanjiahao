package cn.edu.ruc.zhixing.engine.classifier

import cn.edu.ruc.zhixing.core.model.Category
import cn.edu.ruc.zhixing.core.model.ChatMessage
import cn.edu.ruc.zhixing.core.model.Classification
import cn.edu.ruc.zhixing.core.model.PriorityLevel
import cn.edu.ruc.zhixing.engine.feature.FeatureExtractor
import cn.edu.ruc.zhixing.engine.rule.RuleClassifier

/**
 * 重要性分类引擎 —— 级联管线。
 *
 *   消息 → 快速过滤(广告/系统噪音) → 分类器(规则/模型) → 输出Classification
 *
 * [fastFilter] 可先做毫秒级的低阶过滤；真正打分交由 [classifier]（默认为规则版）。
 * 上线初期用[RuleClassifier]，后续换成本地模型版，接口不变即可无缝切换。
 */
class ImportanceEngine(
    private val classifier: ImportanceClassifier? = null,
    private val onExternal: (Classification) -> Unit = {},
) {

    private val featureExtractor = FeatureExtractor()
    private val burstContext = object : FeatureExtractor.FeatureContext {
        private val recent = mutableMapOf<String, Long>()
        override fun recentBurst(senderName: String): Boolean {
            val now = System.currentTimeMillis()
            val last = recent[senderName]
            recent[senderName] = now
            return last != null && now - last < 30_000L
        }
    }

    fun classify(msg: ChatMessage): Classification {
        // 1) 快速过滤：明显噪音直接降级，不打分
        fastFilter(msg)?.let { return it }
        // 2) 正式分类
        val c = classifier?.classify(msg) ?: RuleClassifier().classify(featureExtractor.extract(msg, burstContext))
        // 3) 分发回调（供策略层做免打扰/提醒）
        onExternal(c)
        return c
    }

    /** 毫秒级快速过滤：命中即返回固定结果，避免进入复杂打分。 */
    private fun fastFilter(msg: ChatMessage): Classification? {
        if (msg.raw.contains("验证码") || msg.content.contains("验证码")) {
            return Classification(PriorityLevel.P3_IGNORABLE, 0.0f, Category.SYSTEM, "系统验证码，忽略")
        }
        return null
    }
}

package cn.edu.ruc.zhixing.presentation.ui.companion

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** 陪伴页右侧控件栏的图标按钮：半透明圆形背景 + 图标 + 下方短标签。 */
@Composable
internal fun SideButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    active: Boolean = false,
) {
    val bgColor = if (active) MaterialTheme.colorScheme.primary else Color.Black.copy(alpha = 0.28f)
    val contentColor = if (active) MaterialTheme.colorScheme.onPrimary else Color.White
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(bgColor)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, label, tint = contentColor)
        }
        Text(
            label,
            color = Color.White.copy(alpha = 0.85f),
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
        )
    }
}

package cn.edu.ruc.zhixing.presentation.ui.companion

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import cn.edu.ruc.zhixing.presentation.ui.companion.model.*
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.delay

@Composable
fun CompanionScreen(pomodoroRequest: Int = 0, viewModel: CompanionViewModel = viewModel()) {
    val scene by viewModel.scene.collectAsState()
    val character by viewModel.character.collectAsState()
    val noise by viewModel.playingNoise.collectAsState()
    val importedAudio by viewModel.importedAudio.collectAsState()
    val importedPlaying by viewModel.importedPlaying.collectAsState()
    val audioMessage by viewModel.audioMessage.collectAsState()
    val pomodoro by viewModel.pomodoro.collectAsState()
    val squeezeSound by viewModel.squeezeSound.collectAsState()

    var personalizeSheet by rememberSaveable { mutableStateOf(false) }
    var interactionSheet by rememberSaveable { mutableStateOf(false) }
    var immersionSheet by rememberSaveable { mutableStateOf(false) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    val context = LocalContext.current
    val squeezeSoundPlayer = remember { SqueezeSoundPlayer(context) }
    LaunchedEffect(squeezeSound) { squeezeSoundPlayer.load(squeezeSound) }

    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000 - now % 1000)
        }
    }
    LaunchedEffect(pomodoroRequest) { if (pomodoroRequest > 0) immersionSheet = true }
    // 页面销毁时停止页面内音频（P2 后台服务接管后移除）
    DisposableEffect(Unit) { onDispose { viewModel.stopAudio(); squeezeSoundPlayer.release() } }
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { viewModel.stopAudio() }

    val dateTime = Instant.ofEpochMilli(now).atZone(ZoneId.systemDefault())
    // 番茄钟进行中时形象切换为 FOCUS
    val pose = if (pomodoro.isRunning) CharacterPose.FOCUS else defaultPoseFor(scene)

    Box(Modifier.fillMaxSize()) {
        // 1. 底层：场景背景 + 形象（全屏主视觉）
        SceneBackdrop(scene, Modifier.fillMaxSize())
        CharacterInScene(character, scene, pose, dateTime.hour, Modifier.fillMaxSize())

        // 2. 左上角：时间日期（小字，不喧宾夺主）
        Column(
            Modifier.align(Alignment.TopStart).padding(top = 16.dp, start = 16.dp),
        ) {
            Text(
                dateTime.format(DateTimeFormatter.ofPattern("HH:mm")),
                style = MaterialTheme.typography.headlineMedium,
                color = if (scene == SceneOption.NIGHT_WINDOW) Color.White else Color(0xFF202624),
            )
            Text(
                dateTime.format(DateTimeFormatter.ofPattern("yyyy年M月d日 EEEE", Locale.CHINA)),
                style = MaterialTheme.typography.bodyMedium,
                color = if (scene == SceneOption.NIGHT_WINDOW) Color.White.copy(alpha = 0.8f) else Color(0xFF5A5A5A),
            )
        }

        // 3. 右侧控件栏
        Column(
            Modifier.align(Alignment.CenterEnd).padding(end = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            SideButton(Icons.Default.MusicNote, "沉浸", { immersionSheet = true })
            SideButton(Icons.Default.TouchApp, "互动", { interactionSheet = true })
            SideButton(Icons.Default.Palette, "个性化", { personalizeSheet = true })
        }

        // 4. 右下角 Q 版捏脸形象
        SqueezeMascot(
            soundPlayer = squeezeSoundPlayer,
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 16.dp),
        )

        // 5. 底部：当前播放状态提示（沉浸入口激活时显示）
        if (noise != null || importedPlaying || pomodoro.isRunning) {
            Surface(
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp),
                color = Color.Black.copy(alpha = 0.4f),
                shape = RoundedCornerShape(20.dp),
            ) {
                Text(
                    buildString {
                        if (noise != null) append(noise!!.displayName)
                        if (importedPlaying) append(if (isEmpty()) "本地音频" else " · 本地音频")
                        if (pomodoro.isRunning) append(if (isEmpty()) "专注中" else " · 专注中")
                    },
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
        }
    }

    // 抽屉
    if (personalizeSheet) PersonalizeSheet(
        scene = scene,
        character = character,
        onSelectScene = { viewModel.selectScene(it); personalizeSheet = false },
        onSelectCharacter = { viewModel.selectCharacter(it); personalizeSheet = false },
        onDismiss = { personalizeSheet = false },
    )
    if (interactionSheet) InteractionSheet(onDismiss = { interactionSheet = false })
    // P0 阶段"沉浸"入口复用 PomodoroSheet（含噪音+番茄钟+本地音频）；P1 将替换为 ImmersionSheet
    if (immersionSheet) PomodoroSheet(
        state = pomodoro,
        playingNoise = noise,
        importedAudio = importedAudio,
        importedPlaying = importedPlaying,
        onTaskChange = viewModel::updateTask,
        onDuration = viewModel::selectDuration,
        onBackground = viewModel::selectFocusBackground,
        onNoise = viewModel::startNoise,
        onStopAudio = viewModel::stopAudio,
        onImport = viewModel::importAudio,
        onPlayImported = viewModel::playImportedAudio,
        onStart = viewModel::startPomodoro,
        onStop = viewModel::stopPomodoro,
        onDismiss = { immersionSheet = false },
    )
    if (pomodoro.completed) AlertDialog(
        onDismissRequest = viewModel::dismissCompletion,
        title = { Text("专注完成") },
        text = { Text("这一轮做得不错，休息一下吧。") },
        confirmButton = { TextButton(onClick = viewModel::dismissCompletion) { Text("知道了") } },
    )
}

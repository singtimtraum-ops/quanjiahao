package cn.edu.ruc.zhixing.presentation.ui.companion

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Face
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/**
 * 右下角 Q 版虚拟形象（捏脸交互）。
 * 点击时横向拉伸 + 纵向压扁，模拟"被捏了一下"的感觉，随后回弹，并播放音效。
 * 美术资源（mascot_q_halfbody）到位后替换 painterResource 即可。
 */
@Composable
internal fun SqueezeMascot(
    soundPlayer: SqueezeSoundPlayer,
    modifier: Modifier = Modifier,
) {
    var squeezed by remember { mutableStateOf(false) }
    val scaleX by animateFloatAsState(
        targetValue = if (squeezed) 1.3f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "squeezeX",
    )
    val scaleY by animateFloatAsState(
        targetValue = if (squeezed) 0.85f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "squeezeY",
    )

    LaunchedEffect(squeezed) {
        if (squeezed) {
            delay(180)
            squeezed = false
        }
    }

    Box(
        modifier = modifier
            .size(80.dp)
            .graphicsLayer(scaleX = scaleX, scaleY = scaleY)
            .clip(CircleShape)
            .background(Color(0xFFFFE4E1))
            .clickable {
                if (!squeezed) {
                    squeezed = true
                    soundPlayer.play()
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        // 占位：用 Face 图标代替 Q 版半身像，美术资源到位后替换
        Icon(Icons.Default.Face, "捏脸", tint = Color(0xFFE91E63), modifier = Modifier.size(48.dp))
    }
}

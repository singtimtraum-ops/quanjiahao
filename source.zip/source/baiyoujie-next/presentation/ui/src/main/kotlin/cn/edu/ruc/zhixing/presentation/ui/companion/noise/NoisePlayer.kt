package cn.edu.ruc.zhixing.presentation.ui.companion.noise

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import cn.edu.ruc.zhixing.presentation.ui.companion.model.NoiseKind
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.random.Random
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

interface NoisePlayer {
    fun start(kind: NoiseKind)
    fun stop()
    val playingKind: StateFlow<NoiseKind?>
}

class AudioTrackNoisePlayer : NoisePlayer {
    private val mutablePlayingKind = MutableStateFlow<NoiseKind?>(null)
    override val playingKind: StateFlow<NoiseKind?> = mutablePlayingKind
    private val running = AtomicBoolean(false)
    private var track: AudioTrack? = null
    private var worker: Thread? = null

    @Synchronized
    override fun start(kind: NoiseKind) {
        stop()
        val sampleRate = 44_100
        val minBuffer = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
        ).coerceAtLeast(sampleRate / 2)
        val audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setLegacyStreamType(AudioManager.STREAM_MUSIC)
                    .build(),
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build(),
            )
            .setBufferSizeInBytes(minBuffer * 2)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = audioTrack
        running.set(true)
        mutablePlayingKind.value = kind
        audioTrack.play()
        worker = Thread({ writeNoise(audioTrack, kind, minBuffer) }, "BaiyoujieNoise").apply {
            isDaemon = true
            start()
        }
    }

    private fun writeNoise(audioTrack: AudioTrack, kind: NoiseKind, bufferSize: Int) {
        val samples = ShortArray(bufferSize / 2)
        var smooth = 0.0
        while (running.get()) {
            for (index in samples.indices) {
                val raw = Random.nextInt(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toDouble()
                smooth = when (kind) {
                    NoiseKind.WHITE -> raw
                    NoiseKind.RAIN -> smooth * 0.72 + raw * 0.28
                    NoiseKind.CAFE -> smooth * 0.9 + raw * 0.1
                }
                samples[index] = (smooth * 0.22).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }
            if (audioTrack.write(samples, 0, samples.size, AudioTrack.WRITE_BLOCKING) < 0) break
        }
    }

    @Synchronized
    override fun stop() {
        running.set(false)
        mutablePlayingKind.value = null
        track?.let { current ->
            runCatching { current.pause() }
            runCatching { current.flush() }
            runCatching { current.stop() }
            runCatching { current.release() }
        }
        track = null
        worker = null
    }
}

package cn.edu.ruc.zhixing.presentation.ui.companion.model

enum class SceneOption(val displayName: String) {
    STUDY_ROOM("书房"),
    NIGHT_WINDOW("深夜窗边"),
    CLASSROOM("教室"),
}

enum class CharacterOption(val displayName: String) {
    XIAOXING("小行（默认）"),
}

enum class NoiseKind(val displayName: String) {
    WHITE("白噪音"),
    RAIN("雨声"),
    CAFE("咖啡馆"),
}

enum class FocusBackground(val displayName: String) {
    FOREST("林间"),
    PAPER("素纸"),
    NIGHT("夜色"),
}

data class PomodoroState(
    val taskName: String = "",
    val durationMinutes: Int = 25,
    val background: FocusBackground = FocusBackground.FOREST,
    val endAtMillis: Long? = null,
    val remainingMillis: Long = 25 * 60_000L,
    val completed: Boolean = false,
) {
    val isRunning: Boolean get() = endAtMillis != null && remainingMillis > 0
}

fun interface TimeSource {
    fun now(): Long
}

object SystemTimeSource : TimeSource {
    override fun now(): Long = System.currentTimeMillis()
}

fun remainingUntil(endAtMillis: Long, nowMillis: Long): Long = (endAtMillis - nowMillis).coerceAtLeast(0)

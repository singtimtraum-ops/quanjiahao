package cn.edu.ruc.zhixing.presentation.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import cn.edu.ruc.zhixing.presentation.ui.model.ModuleState

/**
 * 验证版·采集页：展示三个采集模块的真实授权状态与「去开启」入口，
 * 并提示如何验证「通知监听 → 分类 → 展示」。
 * 注：此 UI 仅用于验证 M2 闭环，非最终设计。
 */
@Composable
fun HomeScreen(
    moduleStates: List<ModuleState>,
    postPermissionGranted: Boolean,
    onEnableModule: (String) -> Unit,
    onRequestPostPermission: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("知行伴 · 采集状态", style = MaterialTheme.typography.headlineMedium)
        Text("用于验证：通知监听 → 分类 → 数据库 → 页面展示", style = MaterialTheme.typography.bodySmall)

        // 运行时通知显示权限（Android 13+）
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text("通知显示权限", style = MaterialTheme.typography.titleSmall)
                    Text(
                        if (postPermissionGranted) "已授权" else "未授权",
                        color = if (postPermissionGranted) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.error,
                    )
                }
                Text("Android 13+ 需要此权限才能看到/处理通知。", style = MaterialTheme.typography.bodySmall)
                if (!postPermissionGranted) {
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = onRequestPostPermission) { Text("请求通知权限") }
                }
            }
        }

        Text("采集模块", style = MaterialTheme.typography.titleMedium)
        moduleStates.forEach { ModuleCard(it, onEnableModule) }

        Spacer(Modifier.height(8.dp))

        Text("如何验证", style = MaterialTheme.typography.titleMedium)
        Text(
            "1. 开启【通知监听】，用另一台设备给本机微信发消息，通知会进入分类；\n" +
                "2. 或切到「消息」页点“发一条测试消息”，验证分类与列表展示；\n" +
                "3. 回来本页，模块应从“已开启”变为“采集就绪”。",
            style = MaterialTheme.typography.bodySmall,
        )
    }
}

@Composable
private fun ModuleCard(state: ModuleState, onEnableModule: (String) -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(state.name, style = MaterialTheme.typography.titleSmall)
                Text(
                    if (state.enabled) "已开启" else "未开启",
                    color = if (state.enabled) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.outline,
                )
            }
            Text(state.desc, style = MaterialTheme.typography.bodySmall)
            if (!state.enabled) {
                Spacer(Modifier.height(8.dp))
                Button(onClick = { onEnableModule(state.id) }) { Text("去开启") }
            }
        }
    }
}

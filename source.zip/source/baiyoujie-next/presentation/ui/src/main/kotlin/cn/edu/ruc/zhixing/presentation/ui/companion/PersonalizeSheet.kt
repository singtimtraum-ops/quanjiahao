package cn.edu.ruc.zhixing.presentation.ui.companion

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import cn.edu.ruc.zhixing.presentation.ui.companion.model.CharacterOption
import cn.edu.ruc.zhixing.presentation.ui.companion.model.SceneOption

/**
 * 个性化抽屉：合并场景选择与形象选择。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun PersonalizeSheet(
    scene: SceneOption,
    character: CharacterOption,
    onSelectScene: (SceneOption) -> Unit,
    onSelectCharacter: (CharacterOption) -> Unit,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text("个性化", style = MaterialTheme.typography.titleLarge)

            Text("场景", style = MaterialTheme.typography.titleMedium)
            SceneOption.entries.forEach { option ->
                ListItem(
                    headlineContent = { Text(option.displayName) },
                    leadingContent = {
                        Box(Modifier.size(42.dp).background(scenePreviewColor(option), RoundedCornerShape(6.dp)))
                    },
                    trailingContent = { RadioButton(scene == option, { onSelectScene(option) }) },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            ListItem(
                headlineContent = { Text("自定义 / 更多场景") },
                supportingContent = { Text("敬请期待") },
                colors = ListItemDefaults.colors(headlineColor = MaterialTheme.colorScheme.onSurfaceVariant),
            )

            Spacer(Modifier.height(8.dp))

            Text("形象", style = MaterialTheme.typography.titleMedium)
            CharacterOption.entries.forEach { option ->
                ListItem(
                    headlineContent = { Text(option.displayName) },
                    trailingContent = { RadioButton(character == option, { onSelectCharacter(option) }) },
                )
            }
            ListItem(
                headlineContent = { Text("清爽短发 · 校园制服") },
                supportingContent = { Text("敬请期待") },
                colors = ListItemDefaults.colors(headlineColor = MaterialTheme.colorScheme.onSurfaceVariant),
            )

            Spacer(Modifier.height(20.dp))
        }
    }
}

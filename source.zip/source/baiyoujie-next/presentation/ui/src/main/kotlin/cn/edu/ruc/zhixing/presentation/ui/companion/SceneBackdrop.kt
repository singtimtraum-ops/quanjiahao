package cn.edu.ruc.zhixing.presentation.ui.companion

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import cn.edu.ruc.zhixing.presentation.ui.companion.model.SceneOption

/**
 * 场景背景层。
 * MVP：使用渐变 + 场景主色占位，模拟温馨场景氛围。
 * 预留 VideoSceneBackdrop 接口（TODO），未来可替换为视频/Lottie 动态壁纸。
 * 美术资源到位后替换同名 drawable 即可，无需改代码。
 */
@Composable
internal fun SceneBackdrop(scene: SceneOption, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize().background(sceneBrush(scene)))
}

/** 每个场景的渐变配色，模拟氛围。 */
private fun sceneBrush(scene: SceneOption): Brush = when (scene) {
    SceneOption.STUDY_ROOM -> Brush.verticalGradient(
        listOf(Color(0xFFE8DDC4), Color(0xFFB8D8C4), Color(0xFF8FB8A0)),
    )
    SceneOption.NIGHT_WINDOW -> Brush.verticalGradient(
        listOf(Color(0xFF1A2340), Color(0xFF35445D), Color(0xFF5A4A6B)),
    )
    SceneOption.CLASSROOM -> Brush.verticalGradient(
        listOf(Color(0xFFF5E6C8), Color(0xFFD9CFAE), Color(0xFFB8A87E)),
    )
}

package cn.edu.ruc.zhixing.presentation.ui.companion

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.net.Uri
import java.io.File

/**
 * 捏脸音效播放器。
 * 用 SoundPool 播放短音效（延迟低）。
 * 音效来源：用户在设置中选择的本地音频 URI；未设置时静默。
 * 内置默认音效（小黄鸭捏声）由美术后续提供，放在 res/raw/squeeze_default。
 */
class SqueezeSoundPlayer(private val context: Context) {

    private val soundPool: SoundPool = SoundPool.Builder()
        .setMaxStreams(1)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build(),
        )
        .build()

    private var loadedSoundId: Int = 0
    private var currentUri: String? = null

    /** 加载指定 URI 的音效；uri 为 null 时清空。 */
    fun load(uri: String?) {
        if (uri == currentUri) return
        if (loadedSoundId != 0) {
            soundPool.unload(loadedSoundId)
            loadedSoundId = 0
        }
        currentUri = uri
        if (uri == null) return
        runCatching {
            // 优先从 filesDir/user_audio 加载；也支持 content:// URI
            val file = File(uri)
            if (file.exists()) {
                loadedSoundId = soundPool.load(file.absolutePath, 1)
            } else {
                loadedSoundId = soundPool.load(context, Uri.parse(uri), 1)
            }
        }
    }

    /** 播放当前音效；未加载时静默。 */
    fun play() {
        if (loadedSoundId != 0) {
            runCatching { soundPool.play(loadedSoundId, 1f, 1f, 1, 0, 1f) }
        }
    }

    fun release() {
        runCatching { soundPool.release() }
    }
}

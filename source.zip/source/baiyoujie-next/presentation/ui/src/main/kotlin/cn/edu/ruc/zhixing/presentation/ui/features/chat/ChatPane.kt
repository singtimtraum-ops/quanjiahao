package cn.edu.ruc.zhixing.presentation.ui.features.chat

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import coil.request.ImageRequest
import cn.edu.ruc.zhixing.presentation.ui.R
import cn.edu.ruc.zhixing.core.model.companion.*
import cn.edu.ruc.zhixing.core.model.planner.*
import java.time.*
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.launch

@Composable internal fun ChatPane(turns: List<ChatTurn>, preview: String, busy: Boolean, error: String, send: (String) -> Unit, stop: () -> Unit,
    suggestions: List<Suggestion>, events: List<ScheduleEvent>, extractionStatus: String,
    confirm: (String, String) -> Unit, dismiss: (String) -> Unit) {
    var text by rememberSaveable { mutableStateOf("") }
    var day by rememberSaveable { mutableStateOf("") }
    var history by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val avatarStore = remember(context) { UserAvatarStore(context.applicationContext) }
    var avatarVersion by remember { mutableLongStateOf(avatarStore.file.takeIf { it.exists() }?.lastModified() ?: 0L) }
    var avatarError by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val avatarPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            if (avatarStore.save(uri)) {
                avatarVersion = avatarStore.file.lastModified()
                avatarError = ""
            } else avatarError = "头像处理失败，已保留原头像。"
        }
    }
    val userAvatarModel = avatarStore.file.takeIf { it.exists() }?.let { file ->
        ImageRequest.Builder(context).data(file).memoryCacheKey("user-avatar-$avatarVersion").build()
    }
    val userPlaceholder = painterResource(R.drawable.ic_user_avatar_placeholder)
    val companionPlaceholder = painterResource(R.drawable.ic_companion_avatar_placeholder)
    val pickAvatar = {
        avatarPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }
    Column(Modifier.fillMaxSize().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) {
                TextButton(onClick = { history = true }) { Text(if(day.isBlank()) "全部日期" else day) }
                DropdownMenu(expanded = history, onDismissRequest = { history = false }) {
                    DropdownMenuItem(text = { Text("全部日期") }, onClick = { day = ""; history = false })
                    turns.map { it.dayBucket }.distinct().sortedDescending().forEach { d -> DropdownMenuItem(text = { Text(d) }, onClick = { day = d; history = false }) }
                }
            }
            ChatAvatar(userAvatarModel, userPlaceholder, onClick = pickAvatar)
        }
        val list = androidx.compose.foundation.lazy.rememberLazyListState()
        val visible = turns.filter { day.isBlank() || it.dayBucket == day }
        LaunchedEffect(visible.size, preview, busy) { if (visible.isNotEmpty()) list.animateScrollToItem(if (busy) visible.size else visible.size - 1) }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if(visible.isEmpty()) item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ChatAvatar(null, companionPlaceholder)
                    Spacer(Modifier.width(8.dp))
                    Text("想说点什么？", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            items(visible, key = { it.id }) { turn ->
                Column(Modifier.fillMaxWidth(), horizontalAlignment = if(turn.role == ChatRole.USER) Alignment.End else Alignment.Start) {
                    Text("${turn.dayBucket} ${time(turn.timestamp)}", style = MaterialTheme.typography.labelSmall)
                    val suggestion = suggestions.firstOrNull { it.id == turn.hasCard?.id }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (turn.role == ChatRole.USER) Arrangement.End else Arrangement.Start, verticalAlignment = Alignment.Bottom) {
                        if (turn.role != ChatRole.USER) {
                            ChatAvatar(null, companionPlaceholder)
                            Spacer(Modifier.width(8.dp))
                        }
                        if (suggestion != null) {
                            Box(Modifier.weight(1f, fill = false)) { SuggestionCard(suggestion, events, confirm, dismiss) }
                        } else Surface(shape = RoundedCornerShape(8.dp), color = if(turn.role == ChatRole.USER) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.widthIn(max = 260.dp)) {
                            Text(turn.content, Modifier.padding(12.dp))
                        }
                        if (turn.role == ChatRole.USER) {
                            Spacer(Modifier.width(8.dp))
                            ChatAvatar(userAvatarModel, userPlaceholder, onClick = pickAvatar)
                        }
                    }
                }
            }
            if(busy) item {
                Row(verticalAlignment = Alignment.Bottom) {
                    ChatAvatar(null, companionPlaceholder)
                    Spacer(Modifier.width(8.dp))
                    Text(preview.ifBlank { "正在输入…" }, Modifier.padding(12.dp))
                }
            }
        }
        if(avatarError.isNotBlank()) Text(avatarError, Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        if(error.isNotBlank()) Text(error, Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        if(extractionStatus.isNotBlank()) Text(extractionStatus, Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodySmall)
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { if(it.length <= 4000) text = it }, Modifier.weight(1f), placeholder = { Text("说点什么…") }, maxLines = 4)
            IconButton(enabled = busy || text.isNotBlank(), onClick = { if(busy) stop() else { send(text); text = ""; day = "" } }) {
                Icon(if(busy) Icons.Default.Close else Icons.Default.Send, if(busy) "停止回复" else "发送")
            }
        }
    }
}

private fun time(value: Long): String = Instant.ofEpochMilli(value).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm"))

package cn.edu.ruc.zhixing.presentation.ui.model

import cn.edu.ruc.zhixing.core.model.PriorityLevel

/** 采集模块的展示状态。 */
data class ModuleState(
    val id: String,
    val name: String,
    val desc: String,
    val enabled: Boolean,
)

/** 展示层消息模型（由 Room 实体映射而来，避免 UI 层依赖存储实体）。 */
data class UiMessage(
    val id: String,
    val channel: String,
    val sender: String,
    val content: String,
    val isGroup: Boolean,
    val category: String,
    val score: Float,
    val reason: String,
    val level: PriorityLevel,
    val timestamp: Long,
)

/** 按重要性分组的消息分区（用于分类列表）。 */
data class MessageSection(
    val level: PriorityLevel,
    val messages: List<UiMessage>,
)

/** 自适应学习状态（展示“越用越准”的过程）。 */
data class AdaptiveStatus(
    val sampleCount: Int,
    /** 例如 ["关键词 +0.45", "询问 +0.20", ...]。 */
    val topSignals: List<String>,
    /** 是否已开始让学习结果介入（样本足够）。 */
    val learningActive: Boolean,
)

package cn.edu.ruc.zhixing.presentation.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import cn.edu.ruc.zhixing.companion.ai.config.LlmConfig
import cn.edu.ruc.zhixing.core.model.companion.*
import cn.edu.ruc.zhixing.core.model.memory.*
import cn.edu.ruc.zhixing.core.model.planner.*
import cn.edu.ruc.zhixing.presentation.ui.companion.CompanionScreen
import cn.edu.ruc.zhixing.presentation.ui.features.chat.ChatPane
import cn.edu.ruc.zhixing.presentation.ui.features.home.CompanionHome
import cn.edu.ruc.zhixing.presentation.ui.features.schedule.CoursePane
import cn.edu.ruc.zhixing.presentation.ui.features.schedule.SchedulePane
import cn.edu.ruc.zhixing.presentation.ui.features.settings.SettingsPane
import cn.edu.ruc.zhixing.presentation.ui.model.ModuleState

enum class TabDestination(val label: String, val icon: ImageVector) {
    Home("主页", Icons.Default.Home),
    Companion("陪伴", Icons.Default.Favorite),
    Chat("对话", Icons.Default.Email),
    Calendar("日程", Icons.Default.DateRange),
}

private enum class DetailPage(val title: String) {
    SETTINGS("设置"),
    MEMORY("记忆"),
    COURSES("课表"),
    MESSAGES("消息整理"),
}

/** 当前底部标签只有一个状态源；详情页不创建第二套底部导航。 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompanionScaffold(
    config: LlmConfig, turns: List<ChatTurn>, preview: String, busy: Boolean, error: String,
    suggestions: List<Suggestion>, extractionStatus: String,
    onConfirmSuggestion: (String, String) -> Unit, onDismissSuggestion: (String) -> Unit,
    coursePlan: CoursePlan, onSaveCourses: (CoursePlan) -> Unit,
    events: List<ScheduleEvent>, todos: List<TodoItem>, memories: List<MemoryItem>, status: String,
    modules: List<ModuleState>, onSend: (String) -> Unit, onStop: () -> Unit,
    onSaveConfig: (LlmConfig) -> Unit, onCloud: (Boolean) -> Unit, onTest: () -> Unit,
    onEnable: (String) -> Unit, onDisable: (String) -> Unit,
    onAddTodo: (String, Long?) -> Unit, onDone: (String, Boolean) -> Unit,
    onAddEvent: (String, Long, Long) -> Unit, onDeleteEvent: (String) -> Unit,
    onDeleteMemory: (String) -> Unit, messages: @Composable () -> Unit,
) {
    val context = LocalContext.current
    val navigationPreferences = remember(context) { context.getSharedPreferences("navigation_state", android.content.Context.MODE_PRIVATE) }
    var selectedTabName by rememberSaveable {
        mutableStateOf(navigationPreferences.getString("selected_tab", TabDestination.Home.name) ?: TabDestination.Home.name)
    }
    val selectedTab = TabDestination.entries.firstOrNull { it.name == selectedTabName } ?: TabDestination.Home
    var detailName by rememberSaveable { mutableStateOf<String?>(null) }
    val detail = detailName?.let { name -> DetailPage.entries.firstOrNull { it.name == name } }
    var pomodoroRequest by rememberSaveable { mutableIntStateOf(0) }
    val selectTab: (TabDestination) -> Unit = { destination ->
        selectedTabName = destination.name
        detailName = null
        navigationPreferences.edit().putString("selected_tab", destination.name).apply()
    }
    val title = detail?.title ?: when (selectedTab) {
        TabDestination.Home -> "百忧解"
        TabDestination.Companion -> "陪伴"
        TabDestination.Chat -> config.personaName
        TabDestination.Calendar -> "日程"
    }
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(status) { if (status.isNotBlank()) snackbar.showSnackbar(status) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    if (detail != null) IconButton(onClick = { detailName = null }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "返回")
                    }
                },
                actions = {
                    if (detail == null) IconButton(onClick = { detailName = DetailPage.SETTINGS.name }) {
                        Icon(Icons.Default.Settings, "设置")
                    }
                },
            )
        },
        bottomBar = {
            if (detail == null) NavigationBar {
                TabDestination.entries.forEach { destination ->
                    NavigationBarItem(
                        selected = selectedTab == destination,
                        onClick = {
                            selectTab(destination)
                        },
                        icon = { Icon(destination.icon, destination.label) },
                        label = { Text(destination.label) },
                    )
                }
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            if (detail != null) {
                when (detail) {
                    DetailPage.SETTINGS -> SettingsPane(config, status, modules, onSaveConfig, onCloud, onTest, onEnable, onDisable) { detailName = DetailPage.MEMORY.name }
                    DetailPage.MEMORY -> MemoryPage(memories, onDeleteMemory)
                    DetailPage.COURSES -> CoursePane(coursePlan, onSaveCourses)
                    DetailPage.MESSAGES -> messages()
                }
            } else {
                when (selectedTab) {
                    TabDestination.Home -> CompanionHome(
                        config.personaName,
                        events,
                        chat = { selectTab(TabDestination.Chat) },
                        focus = {
                            pomodoroRequest++
                            selectTab(TabDestination.Companion)
                        },
                        messages = { detailName = DetailPage.MESSAGES.name },
                    )
                    TabDestination.Companion -> CompanionScreen(pomodoroRequest = pomodoroRequest)
                    TabDestination.Chat -> ChatPane(turns, preview, busy, error, onSend, onStop, suggestions, events, extractionStatus, onConfirmSuggestion, onDismissSuggestion)
                    TabDestination.Calendar -> SchedulePane(events, todos, onAddTodo, onDone, onAddEvent, onDeleteEvent) { detailName = DetailPage.COURSES.name }
                }
            }
        }
    }
}

@Composable
private fun MemoryPage(memories: List<MemoryItem>, onDeleteMemory: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (memories.isEmpty()) item { Text("暂无记忆") }
        items(memories, key = { it.id }) { memory ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(memory.content)
                    Text(
                        when (memory.status) {
                            MemoryStatus.ACTIVE -> "有效"
                            MemoryStatus.EXPIRED -> "已过期"
                            MemoryStatus.DONE -> "已完成"
                            else -> "已失效"
                        },
                        style = MaterialTheme.typography.labelMedium,
                    )
                }
                IconButton(onClick = { onDeleteMemory(memory.id) }) { Icon(Icons.Default.Delete, "删除记忆") }
            }
        }
    }
}

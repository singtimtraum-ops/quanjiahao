package cn.edu.ruc.zhixing.presentation.ui.companion

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * 互动抽屉（占位）。
 * 与对话页分工明确：在此页面与虚拟形象的简单交互，不是对话。
 * 具体功能待定，本次只搭框架。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun InteractionSheet(onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text("互动", style = MaterialTheme.typography.titleLarge)
            Text("在陪伴页与小行简单互动，不进入对话。", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            // 占位互动项，点击提示开发中
            listOf("戳一戳", "送杯咖啡", "换个表情").forEach { name ->
                ListItem(
                    headlineContent = { Text(name) },
                    supportingContent = { Text("敬请期待") },
                    colors = ListItemDefaults.colors(headlineColor = MaterialTheme.colorScheme.onSurfaceVariant),
                )
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}

/** 互动动作接口，未来具体互动功能实现后填入。 */
interface CompanionInteractor {
    suspend fun poke(): InteractionResult
    suspend fun give(item: String): InteractionResult
}

data class InteractionResult(val success: Boolean, val message: String = "")

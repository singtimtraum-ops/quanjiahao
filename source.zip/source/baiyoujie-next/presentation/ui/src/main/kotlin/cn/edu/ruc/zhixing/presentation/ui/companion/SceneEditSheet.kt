package cn.edu.ruc.zhixing.presentation.ui.companion

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import cn.edu.ruc.zhixing.presentation.ui.companion.model.SceneOption

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun SceneEditSheet(selected: SceneOption, onSelect: (SceneOption) -> Unit, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("选择场景", style = MaterialTheme.typography.titleLarge)
            SceneOption.entries.forEach { scene ->
                ListItem(
                    headlineContent = { Text(scene.displayName) },
                    leadingContent = {
                        Box(Modifier.size(42.dp).background(scenePreviewColor(scene), RoundedCornerShape(6.dp)))
                    },
                    trailingContent = { RadioButton(selected == scene, { onSelect(scene) }) },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            ListItem(
                headlineContent = { Text("自定义 / 更多场景") },
                supportingContent = { Text("敬请期待") },
                colors = ListItemDefaults.colors(headlineColor = MaterialTheme.colorScheme.onSurfaceVariant),
            )
            Spacer(Modifier.height(20.dp))
        }
    }
}

internal fun scenePreviewColor(scene: SceneOption): Color = when (scene) {
    SceneOption.STUDY_ROOM -> Color(0xFFB8D8C4)
    SceneOption.NIGHT_WINDOW -> Color(0xFF35445D)
    SceneOption.CLASSROOM -> Color(0xFFD9CFAE)
}

package cn.edu.ruc.zhixing.presentation.ui.features.chat

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import cn.edu.ruc.zhixing.core.model.planner.*
import java.time.*
import java.time.format.DateTimeFormatter

@Composable
internal fun SuggestionCard(item: Suggestion, events: List<ScheduleEvent>,
    confirm: (String, String) -> Unit, dismiss: (String) -> Unit) {
    var title by rememberSaveable(item.id) { mutableStateOf(item.title) }
    var editing by rememberSaveable(item.id) { mutableStateOf(false) }
    val conflict = item.startTime?.let { start -> item.endTime?.let { end ->
        events.any { it.id != item.id && it.status != EventStatus.CANCELLED && it.startTime < end && it.endTime > start }
    } } == true
    OutlinedCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(if (item.kind == SuggestionKind.TODO) "待办建议" else "日程建议", style = MaterialTheme.typography.labelLarge)
            if (editing && item.status == SuggestionStatus.PENDING) {
                OutlinedTextField(title, { title = it.take(200) }, Modifier.fillMaxWidth(), label = { Text("标题") })
            } else Text(title, style = MaterialTheme.typography.titleMedium)
            item.startTime?.let { Text("开始：${dateTime(it)}", style = MaterialTheme.typography.bodySmall) }
            item.endTime?.let { Text("结束：${dateTime(it)}", style = MaterialTheme.typography.bodySmall) }
            item.dueTime?.let { Text("截止：${dateTime(it)}", style = MaterialTheme.typography.bodySmall) }
            item.location?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
            Text(if (item.source == "MESSAGE") "来源：消息整理" else "来源：对话", style = MaterialTheme.typography.labelSmall)
            if (conflict && item.status == SuggestionStatus.PENDING) Text("与已有日程时间冲突", color = MaterialTheme.colorScheme.error)
            when (item.status) {
                SuggestionStatus.ACCEPTED -> Text("已添加", color = MaterialTheme.colorScheme.primary)
                SuggestionStatus.DISMISSED -> Text("已忽略")
                SuggestionStatus.PENDING -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(enabled = title.isNotBlank(), onClick = { confirm(item.id, title) }) {
                        Icon(Icons.Default.Check, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("确认")
                    }
                    TextButton(onClick = { dismiss(item.id) }) { Text("忽略") }
                    IconButton(onClick = { editing = !editing }) { Icon(Icons.Default.Edit, "修改建议标题") }
                }
            }
        }
    }
}
private fun dateTime(value: Long) = Instant.ofEpochMilli(value).atZone(ZoneId.systemDefault())
    .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))

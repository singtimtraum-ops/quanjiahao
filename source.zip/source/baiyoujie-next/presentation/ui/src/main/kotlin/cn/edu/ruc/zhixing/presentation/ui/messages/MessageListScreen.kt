package cn.edu.ruc.zhixing.presentation.ui.messages

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import cn.edu.ruc.zhixing.core.model.PriorityLevel
import cn.edu.ruc.zhixing.presentation.ui.model.AdaptiveStatus
import cn.edu.ruc.zhixing.presentation.ui.model.MessageSection
import cn.edu.ruc.zhixing.presentation.ui.model.UiMessage

/**
 * 验证版·消息页：可直接发几条“测试消息”走完整分类管线，并展示 P0~P3 分组结果。
 * 每条展示：发送者、内容、类别、得分与可解释原因，便于确认引擎在工作。
 * 顶部展示「学习状态」（样本数/最看重信号），每条提供“提升/降低重要性”反馈驱动学习。
 */
@Composable
fun MessageListScreen(
    sections: List<MessageSection>,
    adaptiveStatus: AdaptiveStatus,
    onSendTest: (sender: String, content: String, isGroup: Boolean) -> Unit,
    onFeedback: (messageId: String, moreImportant: Boolean) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("分类结果 · 按重要性分组", style = MaterialTheme.typography.headlineSmall)
        Text("点击按钮发一条测试消息，验证「分类 → 数据库 → 展示」。", style = MaterialTheme.typography.bodySmall)

        AdaptiveStatusCard(adaptiveStatus)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { onSendTest("老板", "合同今天之前必须给我，申请马上要用，紧急！", false) }) {
                Text("紧急·工作")
            }
            OutlinedButton(onClick = { onSendTest("经理", "项目汇报定在明天上午，请负责人尽快准备", true) }) {
                Text("工作·群聊")
            }
            OutlinedButton(onClick = { onSendTest("张三", "哈哈哈哈哈今晚一起吃饭吗", true) }) {
                Text("闲聊·群")
            }
        }

        if (sections.isEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text("暂无消息。先在「采集」页开启通知，或点上方按钮发一条测试消息。",
                style = MaterialTheme.typography.bodySmall)
        } else {
            sections.forEach { section ->
                Text(
                    levelLabel(section.level),
                    style = MaterialTheme.typography.titleSmall,
                    color = levelColor(section.level),
                )
                section.messages.forEach { MsgCard(it, onFeedback) }
            }
        }
    }
}

@Composable
private fun AdaptiveStatusCard(status: AdaptiveStatus) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text("学习状态", style = MaterialTheme.typography.titleSmall)
                Text(
                    if (status.learningActive) "已开始学习" else "积累反馈中",
                    color = if (status.learningActive) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.outline,
                )
            }
            Text("反馈样本：${status.sampleCount} 条", style = MaterialTheme.typography.bodySmall)
            if (status.topSignals.isNotEmpty()) {
                Text(
                    "当前最看重的信号：${status.topSignals.joinToString("，")}",
                    style = MaterialTheme.typography.bodySmall,
                )
            } else {
                Text(
                    "对消息点「更重要/不那么重要」，模型会记录并学习你的偏好。",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}

@Composable
private fun MsgCard(msg: UiMessage, onFeedback: (String, Boolean) -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(if (msg.isGroup) "${msg.sender}（群）" else msg.sender,
                    style = MaterialTheme.typography.titleSmall)
                Text(msg.level.name, color = levelColor(msg.level), style = MaterialTheme.typography.labelMedium)
            }
            Text(msg.content, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(4.dp))
            Text(
                "类别 ${msg.category} · 得分 ${"%.2f".format(msg.score)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.outline,
            )
            Text(msg.reason.ifEmpty { "（未给出原因）" },
                style = MaterialTheme.typography.bodySmall)

            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { onFeedback(msg.id, true) }) { Text("更重要") }
                OutlinedButton(onClick = { onFeedback(msg.id, false) }) { Text("不那么重要") }
            }
        }
    }
}

fun levelLabel(level: PriorityLevel): String = when (level) {
    PriorityLevel.P0_URGENT -> "P0 紧急"
    PriorityLevel.P1_IMPORTANT -> "P1 重要"
    PriorityLevel.P2_NORMAL -> "P2 普通"
    PriorityLevel.P3_IGNORABLE -> "P3 可忽略"
}

private fun levelColor(level: PriorityLevel) = when (level) {
    PriorityLevel.P0_URGENT -> androidx.compose.ui.graphics.Color(0xFFD64541)
    PriorityLevel.P1_IMPORTANT -> androidx.compose.ui.graphics.Color(0xFFE08A00)
    PriorityLevel.P2_NORMAL -> androidx.compose.ui.graphics.Color(0xFF2E7D5B)
    PriorityLevel.P3_IGNORABLE -> androidx.compose.ui.graphics.Color(0xFF909090)
}

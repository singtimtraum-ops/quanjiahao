package cn.edu.ruc.zhixing.presentation.ui.companion

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import cn.edu.ruc.zhixing.presentation.ui.companion.model.CharacterOption

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun CharacterEditSheet(selected: CharacterOption, onSelect: (CharacterOption) -> Unit, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("选择形象", style = MaterialTheme.typography.titleLarge)
            CharacterOption.entries.forEach { character ->
                ListItem(
                    headlineContent = { Text(character.displayName) },
                    trailingContent = { RadioButton(selected == character, { onSelect(character) }) },
                )
            }
            listOf("清爽短发", "校园制服").forEach { name ->
                ListItem(
                    headlineContent = { Text(name) },
                    supportingContent = { Text("敬请期待") },
                    colors = ListItemDefaults.colors(headlineColor = MaterialTheme.colorScheme.onSurfaceVariant),
                )
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}

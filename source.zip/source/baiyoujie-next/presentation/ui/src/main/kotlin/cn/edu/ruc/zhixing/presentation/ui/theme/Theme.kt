package cn.edu.ruc.zhixing.presentation.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF2E7D5B),
    primaryContainer = Color(0xFFD7EEDF),
    onPrimaryContainer = Color(0xFF173D2C),
    secondary = Color(0xFFBE5F6F),
    background = Color(0xFFF7FAF9),
    surfaceVariant = Color(0xFFE7EFEC),
    secondaryContainer = Color(0xFFF7E5E9),
    surface = Color(0xFFFFFFFF),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF4F7F6),
    surfaceContainer = Color(0xFFEDF2F0),
    surfaceContainerHigh = Color(0xFFE7ECEA),
    surfaceContainerHighest = Color(0xFFDFE6E2),
    onSurface = Color(0xFF222925),
    onSurfaceVariant = Color(0xFF505A54),
    onSecondaryContainer = Color(0xFF61343F),
    outline = Color(0xFF78857D),
    outlineVariant = Color(0xFFC2CEC7),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF79D2A8),
    primaryContainer = Color(0xFF244E3B),
    secondary = Color(0xFFE6A2B0),
    secondaryContainer = Color(0xFF50363F),
    background = Color(0xFF121316),
    surface = Color(0xFF1E1F23),
    surfaceContainerLowest = Color(0xFF111415),
    surfaceContainerLow = Color(0xFF1A1F1D),
    surfaceContainer = Color(0xFF202624),
    surfaceContainerHigh = Color(0xFF2A302D),
    surfaceContainerHighest = Color(0xFF343B37),
    onSurface = Color(0xFFE1E8E3),
    onSurfaceVariant = Color(0xFFBBC7BF),
)

@Composable
fun ZhixingTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        typography = Typography(),
        content = content,
    )
}

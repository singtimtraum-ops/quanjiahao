package cn.edu.ruc.zhixing.presentation.ui.features.settings

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import cn.edu.ruc.zhixing.companion.ai.config.LlmConfig
import cn.edu.ruc.zhixing.presentation.ui.companion.CompanionViewModel
import cn.edu.ruc.zhixing.presentation.ui.model.ModuleState

@Composable internal fun SettingsPane(config: LlmConfig, status: String, modules: List<ModuleState>, save: (LlmConfig) -> Unit, cloud: (Boolean) -> Unit, test: () -> Unit, enable: (String) -> Unit, disable: (String) -> Unit, memory: () -> Unit) {
    val companionViewModel: CompanionViewModel = viewModel()
    val squeezeSound by companionViewModel.squeezeSound.collectAsState()
    val context = LocalContext.current
    val soundPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            companionViewModel.setSqueezeSound(uri)
        }
    }
    var url by rememberSaveable(config.baseUrl) { mutableStateOf(config.baseUrl) }
    var key by remember(config.apiKey) { mutableStateOf(config.apiKey) }
    var model by rememberSaveable(config.model) { mutableStateOf(config.model) }
    var name by rememberSaveable(config.personaName) { mutableStateOf(config.personaName) }
    var consent by remember { mutableStateOf(false) }
    var module by remember { mutableStateOf<ModuleState?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("模型与角色", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(name, { name = it.take(20) }, Modifier.fillMaxWidth(), label = { Text("伙伴名字") }, singleLine = true)
        OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(), label = { Text("服务地址（HTTPS）") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
        OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("模型名称") }, singleLine = true)
        OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), label = { Text("API Key") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text("云端理解", Modifier.weight(1f)); Switch(config.allowCloud, { if(it) consent = true else cloud(false) }) }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { save(LlmConfig(url, key, model, config.allowCloud, name)) }) { Text("保存设置") }
            OutlinedButton(enabled = config.allowCloud, onClick = test) { Text("测试已保存配置") }
        }
        if(status.isNotBlank()) Text(status, color = MaterialTheme.colorScheme.primary)
        HorizontalDivider()
        Text("陪伴", style = MaterialTheme.typography.titleLarge)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("捏脸音效")
                Text(if (squeezeSound == null) "未设置（静音）" else "已设置", style = MaterialTheme.typography.bodySmall)
            }
            OutlinedButton(onClick = { soundPicker.launch(arrayOf("audio/*")) }) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(6.dp))
                Text(if (squeezeSound == null) "选择音效" else "更换")
            }
            if (squeezeSound != null) {
                TextButton(onClick = { companionViewModel.setSqueezeSound(null) }) { Text("清除") }
            }
        }
        HorizontalDivider(); Text("消息采集", style = MaterialTheme.typography.titleLarge)
        modules.filter { it.id != "db" }.forEach { item ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(item.name); Text(if(item.enabled) "已开启" else "未开启", style = MaterialTheme.typography.bodySmall) }
                Switch(item.enabled, { if(it) module = item else disable(item.id) })
            }
        }
        TextButton(onClick = memory) { Text("查看记忆") }
    }
    if(consent) AlertDialog(onDismissRequest = { consent = false }, title = { Text("开启云端理解？") }, text = { Text("对话、有效记忆、相关日程以及已采集的重要消息会在脱敏后发送至已保存的服务地址：${config.baseUrl}，用于回复及提取记忆、待办和日程建议。自动脱敏不能保证去除所有个人信息，请勿输入敏感内容。API 调用可能产生费用。") }, confirmButton = { TextButton(onClick = { cloud(true); consent = false }) { Text("同意并开启") } }, dismissButton = { TextButton(onClick = { consent = false }) { Text("取消") } })
    module?.let { item -> AlertDialog(onDismissRequest = { module = null }, title = { Text("开启${item.name}？") }, text = { Text(if(item.id == "notify") "仅在你授予系统通知使用权后读取支持应用的通知摘要，用于本机分类。无法获取完整聊天历史；你可以随时关闭。" else "无障碍仅用于内测的当前屏文本增强，会读取支持应用的可见文本。默认关闭，可随时撤回同意。") }, confirmButton = { TextButton(onClick = { enable(item.id); module = null }) { Text("同意并前往授权") } }, dismissButton = { TextButton(onClick = { module = null }) { Text("取消") } }) }
}

package cn.edu.ruc.zhixing.presentation.ui.features.chat

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal class UserAvatarStore(private val context: Context) {
    val file: File get() = File(context.filesDir, "avatars/user_avatar.jpg")

    suspend fun save(uri: Uri): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val bitmap = context.contentResolver.openInputStream(uri).use { stream ->
                requireNotNull(stream) { "无法打开图片" }
                requireNotNull(BitmapFactory.decodeStream(stream)) { "无法解析图片" }
            }
            val side = minOf(bitmap.width, bitmap.height)
            val cropped = Bitmap.createBitmap(bitmap, (bitmap.width - side) / 2, (bitmap.height - side) / 2, side, side)
            val scaled = if (side > 256) Bitmap.createScaledBitmap(cropped, 256, 256, true) else cropped
            file.parentFile?.mkdirs()
            file.outputStream().use { output -> check(scaled.compress(Bitmap.CompressFormat.JPEG, 85, output)) }
            if (scaled !== cropped) scaled.recycle()
            if (cropped !== bitmap) cropped.recycle()
            bitmap.recycle()
            true
        }.getOrDefault(false)
    }
}

@Composable
internal fun ChatAvatar(
    model: Any?,
    placeholder: Painter,
    size: Dp = 40.dp,
    onClick: (() -> Unit)? = null,
) {
    val interaction = if (onClick == null) Modifier else Modifier.clickable(onClick = onClick)
    AsyncImage(
        model = model,
        contentDescription = if (onClick == null) "小行头像" else "用户头像，点击更换",
        placeholder = placeholder,
        fallback = placeholder,
        error = placeholder,
        contentScale = ContentScale.Crop,
        modifier = Modifier.size(size).clip(CircleShape)
            .border(1.dp, androidx.compose.material3.MaterialTheme.colorScheme.outlineVariant, CircleShape)
            .then(interaction),
    )
}

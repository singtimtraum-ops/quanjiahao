package cn.edu.ruc.zhixing.presentation.ui.features.schedule

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import cn.edu.ruc.zhixing.core.model.planner.*
import java.time.*
import java.time.format.DateTimeFormatter

@Composable internal fun SchedulePane(events: List<ScheduleEvent>, todos: List<TodoItem>, addTodo: (String, Long?) -> Unit, done: (String, Boolean) -> Unit, addEvent: (String, Long, Long) -> Unit, delete: (String) -> Unit, courses: () -> Unit) {
    var selected by rememberSaveable { mutableStateOf(LocalDate.now().toString()) }
    var editor by remember { mutableStateOf(false) }
    var isTodo by remember { mutableStateOf(true) }
    var title by rememberSaveable { mutableStateOf("") }
    var start by rememberSaveable { mutableStateOf(LocalDate.now().toString() + " 15:00") }
    var end by rememberSaveable { mutableStateOf(LocalDate.now().toString() + " 16:00") }
    var validation by remember { mutableStateOf("") }
    val date = LocalDate.parse(selected)
    val monday = date.minusDays((date.dayOfWeek.value - 1).toLong())
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { OutlinedButton(onClick = courses) { Icon(Icons.Default.DateRange, null); Spacer(Modifier.width(8.dp)); Text("课表") } }
        item { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { selected = date.minusWeeks(1).toString() }) { Icon(Icons.Default.KeyboardArrowLeft, "上一周") }
            Text("${monday.monthValue}月${monday.dayOfMonth}日起", Modifier.weight(1f))
            IconButton(onClick = { selected = date.plusWeeks(1).toString() }) { Icon(Icons.Default.KeyboardArrowRight, "下一周") }
            IconButton(onClick = { editor = true }) { Icon(Icons.Default.Add, "新增待办或日程") }
        } }
        item { Row(Modifier.fillMaxWidth()) { repeat(7) { index -> val d = monday.plusDays(index.toLong()); TextButton(onClick = { selected = d.toString() }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(0.dp), colors = ButtonDefaults.textButtonColors(contentColor = if(d == date) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)) { Text(d.dayOfMonth.toString()) } } } }
        item { Text("${date.monthValue}月${date.dayOfMonth}日", style = MaterialTheme.typography.titleLarge) }
        val from = date.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val until = date.plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val selectedEvents = events.filter { it.startTime < until && it.endTime > from && it.status != EventStatus.CANCELLED }
        if(selectedEvents.isEmpty()) item { Text("暂无日程", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(selectedEvents, key = { it.id }) { event -> Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(event.title)
                Text("${time(event.startTime)}—${time(event.endTime)}", style = MaterialTheme.typography.bodySmall)
                event.location?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                if (event.source == EventSource.COURSE) Text("课表", style = MaterialTheme.typography.labelSmall)
            }
            IconButton(onClick = { delete(event.id) }) { Icon(Icons.Default.Delete, "删除日程") }
        } }
        item { HorizontalDivider(); Text("待办", Modifier.padding(top = 12.dp), style = MaterialTheme.typography.titleLarge) }
        if(todos.isEmpty()) item { Text("暂无待办", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(todos, key = { it.id }) { todo -> Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(todo.done, { done(todo.id, it) }); Text(todo.title, Modifier.weight(1f)) } }
    }
    if(editor) AlertDialog(onDismissRequest = { editor = false }, title = { Text("新增安排") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(isTodo, { isTodo = it }); Text("待办事项") }
        OutlinedTextField(title, { title = it }, label = { Text("标题") }, singleLine = true)
        if(!isTodo) {
            OutlinedTextField(start, { start = it }, label = { Text("开始：年-月-日 时:分") }, singleLine = true)
            OutlinedTextField(end, { end = it }, label = { Text("结束：年-月-日 时:分") }, singleLine = true)
        }
        if(validation.isNotBlank()) Text(validation, color = MaterialTheme.colorScheme.error)
    } }, confirmButton = { TextButton(onClick = {
        try {
            require(title.isNotBlank())
            if(isTodo) addTodo(title, null) else {
                val format = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm").withResolverStyle(java.time.format.ResolverStyle.STRICT)
                val s = LocalDateTime.parse(start, format).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                val e = LocalDateTime.parse(end, format).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                require(e > s); addEvent(title, s, e)
            }
            editor = false; title = ""; validation = ""
        } catch (_: Exception) { validation = "请检查标题和时间，结束时间应晚于开始时间。" }
    }) { Text("保存") } }, dismissButton = { TextButton(onClick = { editor = false }) { Text("取消") } })
}

private fun time(value: Long): String = Instant.ofEpochMilli(value).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm"))

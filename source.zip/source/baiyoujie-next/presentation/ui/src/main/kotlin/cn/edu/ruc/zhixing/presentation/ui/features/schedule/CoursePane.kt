package cn.edu.ruc.zhixing.presentation.ui.features.schedule

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import cn.edu.ruc.zhixing.core.model.planner.*
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID

@Composable internal fun CoursePane(saved: CoursePlan, save: (CoursePlan) -> Unit) {
    var serialized by rememberSaveable(saved) { mutableStateOf(Json.encodeToString(saved)) }
    val draft = remember(serialized) { Json.decodeFromString<CoursePlan>(serialized) }
    fun update(value: CoursePlan) { serialized = Json.encodeToString(value) }
    var term by rememberSaveable(saved.termStart) { mutableStateOf(saved.termStart) }
    var weeks by rememberSaveable(saved.totalWeeks) { mutableStateOf(saved.totalWeeks.toString()) }
    var error by remember { mutableStateOf("") }
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }
    var preview by remember { mutableStateOf<Int?>(null) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("学期", style = MaterialTheme.typography.titleLarge) }
        item { OutlinedTextField(term, { term = it }, Modifier.fillMaxWidth(), label = { Text("第一教学周周一（YYYY-MM-DD）") }, singleLine = true) }
        item { OutlinedTextField(weeks, { weeks = it.take(2) }, Modifier.fillMaxWidth(), label = { Text("教学周数") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
        item { Text("时区：${draft.zoneId}", style = MaterialTheme.typography.labelMedium) }
        item { HorizontalDivider(); Row(verticalAlignment = Alignment.CenterVertically) {
            Text("节次时间", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
            IconButton(enabled = draft.slots.size < 20, onClick = {
                val number = (1..20).first { n -> draft.slots.none { it.number == n } }
                update(draft.copy(slots = (draft.slots + LessonSlot(number, "", "")).sortedBy { it.number }))
            }) { Icon(Icons.Default.Add, "新增节次") }
        } }
        if (draft.slots.isEmpty()) item { Text("尚未设置节次", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(draft.slots, key = { "slot-${it.number}" }) { slot ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("第${slot.number}节", Modifier.width(46.dp), style = MaterialTheme.typography.labelMedium)
                OutlinedTextField(slot.start, { value -> update(draft.copy(slots = draft.slots.map { if (it.number == slot.number) it.copy(start = value.take(5)) else it })) },
                    Modifier.weight(1f), label = { Text("上课") }, placeholder = { Text("HH:mm") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii))
                OutlinedTextField(slot.end, { value -> update(draft.copy(slots = draft.slots.map { if (it.number == slot.number) it.copy(end = value.take(5)) else it })) },
                    Modifier.weight(1f), label = { Text("下课") }, placeholder = { Text("HH:mm") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii))
                IconButton(onClick = { update(draft.copy(slots = draft.slots.filterNot { it.number == slot.number })) }) { Icon(Icons.Default.Delete, "删除第${slot.number}节") }
            }
        }
        item { HorizontalDivider(); Row(verticalAlignment = Alignment.CenterVertically) {
            Text("课程", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
            IconButton(enabled = draft.courses.size < 60, onClick = { editingId = "" }) { Icon(Icons.Default.Add, "新增课程") }
        } }
        if (draft.courses.isEmpty()) item { Text("尚未添加课程", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(draft.courses, key = { it.id }) { course ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(course.title, style = MaterialTheme.typography.titleMedium)
                    Text("周${"一二三四五六日"[course.dayOfWeek - 1]} 第${course.firstLesson}–${course.lastLesson}节", style = MaterialTheme.typography.bodySmall)
                    Text("第${course.firstWeek}–${course.lastWeek}周 · ${patternLabel(course.pattern)} ${course.location}", style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = { editingId = course.id }) { Icon(Icons.Default.Edit, "编辑课程") }
                IconButton(onClick = { update(draft.copy(courses = draft.courses.filterNot { it.id == course.id })) }) { Icon(Icons.Default.Delete, "删除课程") }
            }
        }
        if (error.isNotBlank()) item { Text(error, color = MaterialTheme.colorScheme.error) }
        item { Button(onClick = {
            try {
                val candidate = draft.copy(termStart = term.trim(), totalWeeks = weeks.toInt())
                val count = CoursePlanner.expand(candidate).size
                update(candidate); preview = count; error = ""
            } catch (e: Exception) {
                error = if (e is IllegalArgumentException && e !is NumberFormatException) e.message ?: "请检查课程设置。" else "请检查日期、教学周数和节次时间。"
            }
        }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Check, null); Spacer(Modifier.width(8.dp)); Text("保存课表") } }
    }
    editingId?.let { id ->
        val existing = draft.courses.find { it.id == id }
        CourseEditor(existing, draft.slots.map { it.number }, onDismiss = { editingId = null }) { course ->
            update(draft.copy(courses = draft.courses.filterNot { it.id == course.id } + course)); editingId = null
        }
    }
    preview?.let { count ->
        AlertDialog(onDismissRequest = { preview = null }, title = { Text("生成 $count 节课程安排？") },
            text = { Text("将更新本学期课表生成的日程，手动添加和其他来源的日程不受影响。") },
            confirmButton = { TextButton(onClick = { save(draft); preview = null }) { Text("确认保存") } },
            dismissButton = { TextButton(onClick = { preview = null }) { Text("取消") } })
    }
}

@Composable private fun CourseEditor(existing: Course?, slots: List<Int>, onDismiss: () -> Unit, onSave: (Course) -> Unit) {
    var title by rememberSaveable { mutableStateOf(existing?.title ?: "") }
    var day by rememberSaveable { mutableStateOf(existing?.dayOfWeek ?: 1) }
    var first by rememberSaveable { mutableStateOf(existing?.firstLesson?.toString() ?: "") }
    var last by rememberSaveable { mutableStateOf(existing?.lastLesson?.toString() ?: "") }
    var firstWeek by rememberSaveable { mutableStateOf(existing?.firstWeek?.toString() ?: "1") }
    var lastWeek by rememberSaveable { mutableStateOf(existing?.lastWeek?.toString() ?: "") }
    var pattern by rememberSaveable { mutableStateOf(existing?.pattern ?: WeekPattern.ALL) }
    var location by rememberSaveable { mutableStateOf(existing?.location ?: "") }
    var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "新增课程" else "编辑课程") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(title, { title = it.take(100) }, Modifier.fillMaxWidth(), label = { Text("课程名称") }, singleLine = true)
            ChoiceField("星期", "周${"一二三四五六日"[day - 1]}", (1..7).map { it to "周${"一二三四五六日"[it - 1]}" }) { day = it }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumberField(first, { first = it }, "起始节次", Modifier.weight(1f))
                NumberField(last, { last = it }, "结束节次", Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumberField(firstWeek, { firstWeek = it }, "起始教学周", Modifier.weight(1f))
                NumberField(lastWeek, { lastWeek = it }, "结束教学周", Modifier.weight(1f))
            }
            ChoiceField("重复", patternLabel(pattern), WeekPattern.entries.map { it to patternLabel(it) }) { pattern = it }
            OutlinedTextField(location, { location = it.take(200) }, Modifier.fillMaxWidth(), label = { Text("教室（可选）") }, singleLine = true)
            if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        } },
        confirmButton = { TextButton(onClick = {
            try {
                val a = first.toInt(); val b = last.toInt(); val w1 = firstWeek.toInt(); val w2 = lastWeek.toInt()
                require(title.isNotBlank() && a in slots && b in slots && b >= a && w1 in 1..40 && w2 in w1..40)
                onSave(Course(existing?.id ?: UUID.randomUUID().toString(), title.trim(), day, a, b, w1, w2, pattern, location.trim()))
            } catch (_: Exception) { error = "请填写名称，选择已设置的节次，并检查教学周范围。" }
        }) { Text("完成") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } })
}
@Composable private fun NumberField(value: String, changed: (String) -> Unit, label: String, modifier: Modifier) {
    OutlinedTextField(value, { changed(it.take(2)) }, modifier, label = { Text(label) }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
}
@Composable private fun <T> ChoiceField(label: String, current: String, choices: List<Pair<T, String>>, onSelect: (T) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text("$label：$current", Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null)
        }
        DropdownMenu(expanded, { expanded = false }) {
            choices.forEach { (value, title) -> DropdownMenuItem(text = { Text(title) }, onClick = { onSelect(value); expanded = false }) }
        }
    }
}
private fun patternLabel(pattern: WeekPattern) = when (pattern) { WeekPattern.ALL -> "每周"; WeekPattern.ODD -> "单周"; WeekPattern.EVEN -> "双周" }

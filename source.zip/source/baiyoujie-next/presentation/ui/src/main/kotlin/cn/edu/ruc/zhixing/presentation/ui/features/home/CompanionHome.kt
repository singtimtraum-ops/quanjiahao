package cn.edu.ruc.zhixing.presentation.ui.features.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import cn.edu.ruc.zhixing.core.model.planner.*
import cn.edu.ruc.zhixing.presentation.ui.avatar.AvatarPortrait
import kotlinx.coroutines.delay
import java.time.*
import java.time.format.DateTimeFormatter

@Composable internal fun CompanionHome(name: String, events: List<ScheduleEvent>, chat: () -> Unit, focus: () -> Unit, messages: () -> Unit) {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(1000) } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text(now.format(DateTimeFormatter.ofPattern("M月d日 EEEE", java.util.Locale.CHINA)), style = MaterialTheme.typography.titleMedium)
        Text(now.format(DateTimeFormatter.ofPattern("HH:mm")), style = MaterialTheme.typography.displayMedium)
        AvatarPortrait(now.hour)
        Text("$name · 我在", style = MaterialTheme.typography.titleLarge)
        Button(onClick = chat, modifier = Modifier.fillMaxWidth()) { Text("聊一会儿") }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = messages, modifier = Modifier.weight(1f)) { Text("消息整理") }
            OutlinedButton(onClick = focus, modifier = Modifier.weight(1f)) { Text("番茄钟") }
        }
        HorizontalDivider(); Text("今日日程", Modifier.align(Alignment.Start), style = MaterialTheme.typography.titleMedium)
        val today = events.filter { Instant.ofEpochMilli(it.startTime).atZone(ZoneId.systemDefault()).toLocalDate() == now.toLocalDate() && it.status != EventStatus.CANCELLED }.take(2)
        if(today.isEmpty()) Text("今天暂无安排", Modifier.align(Alignment.Start), color = MaterialTheme.colorScheme.onSurfaceVariant)
        today.forEach {
            val start = Instant.ofEpochMilli(it.startTime)
                .atZone(ZoneId.systemDefault())
                .format(DateTimeFormatter.ofPattern("HH:mm"))
            Text("$start  ${it.title}", Modifier.fillMaxWidth())
        }
    }
}

package cn.edu.ruc.zhixing.presentation.ui.companion

import android.app.Application
import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import cn.edu.ruc.zhixing.presentation.ui.companion.model.*
import cn.edu.ruc.zhixing.presentation.ui.companion.noise.AudioTrackNoisePlayer
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

private val Context.companionUiPreferences by preferencesDataStore("companion_ui")

class CompanionViewModel(application: Application) : AndroidViewModel(application) {
    private val timeSource: TimeSource = SystemTimeSource
    private val dataStore = application.companionUiPreferences
    private val noisePlayer = AudioTrackNoisePlayer()
    val playingNoise: StateFlow<NoiseKind?> = noisePlayer.playingKind

    private val mutableScene = MutableStateFlow(SceneOption.STUDY_ROOM)
    val scene = mutableScene.asStateFlow()
    private val mutableCharacter = MutableStateFlow(CharacterOption.XIAOXING)
    val character = mutableCharacter.asStateFlow()
    private val mutableImportedAudio = MutableStateFlow<String?>(null)
    val importedAudio = mutableImportedAudio.asStateFlow()
    private val mutableImportedPlaying = MutableStateFlow(false)
    val importedPlaying = mutableImportedPlaying.asStateFlow()
    private val mutableAudioMessage = MutableStateFlow("")
    val audioMessage = mutableAudioMessage.asStateFlow()
    private val mutablePomodoro = MutableStateFlow(PomodoroState())
    val pomodoro = mutablePomodoro.asStateFlow()
    private val mutableSqueezeSound = MutableStateFlow<String?>(null)
    val squeezeSound: StateFlow<String?> = mutableSqueezeSound.asStateFlow()

    private var importedPlayer: MediaPlayer? = null
    private var timerJob: Job? = null
    private var restored = false

    init {
        viewModelScope.launch {
            dataStore.data.collect { values ->
                mutableScene.value = enumValueOrDefault(values[SCENE], SceneOption.STUDY_ROOM)
                mutableCharacter.value = enumValueOrDefault(values[CHARACTER], CharacterOption.XIAOXING)
                mutableImportedAudio.value = values[IMPORTED_AUDIO]
                mutableSqueezeSound.value = values[SQUEEZE_SOUND]
                if (!restored) {
                    restored = true
                    val duration = values[DURATION]?.toInt()?.coerceIn(1, 180) ?: 25
                    val endAt = values[END_AT]?.takeIf { it > timeSource.now() }
                    mutablePomodoro.value = PomodoroState(
                        taskName = values[TASK].orEmpty(),
                        durationMinutes = duration,
                        background = enumValueOrDefault(values[FOCUS_BACKGROUND], FocusBackground.FOREST),
                        endAtMillis = endAt,
                        remainingMillis = endAt?.let { remainingUntil(it, timeSource.now()) } ?: duration * 60_000L,
                    )
                    if (endAt != null) startTicker()
                }
            }
        }
    }

    fun selectScene(value: SceneOption) {
        mutableScene.value = value
        viewModelScope.launch { dataStore.edit { it[SCENE] = value.name } }
    }

    fun selectCharacter(value: CharacterOption) {
        mutableCharacter.value = value
        viewModelScope.launch { dataStore.edit { it[CHARACTER] = value.name } }
    }

    fun startNoise(kind: NoiseKind) {
        stopImportedAudio()
        runCatching { noisePlayer.start(kind) }
            .onFailure { mutableAudioMessage.value = "当前设备无法播放合成白噪音。" }
    }

    fun stopAudio() {
        noisePlayer.stop()
        stopImportedAudio()
    }

    fun importAudio(uri: Uri) {
        mutableImportedAudio.value = uri.toString()
        viewModelScope.launch { dataStore.edit { it[IMPORTED_AUDIO] = uri.toString() } }
        mutableAudioMessage.value = "本地音频已导入。"
    }

    fun playImportedAudio() {
        val uri = mutableImportedAudio.value?.let(Uri::parse) ?: return
        noisePlayer.stop()
        stopImportedAudio()
        runCatching {
            importedPlayer = MediaPlayer().apply {
                setDataSource(getApplication(), uri)
                isLooping = true
                setOnCompletionListener { mutableImportedPlaying.value = false }
                prepare()
                start()
            }
            mutableImportedPlaying.value = true
        }.onFailure {
            stopImportedAudio()
            mutableAudioMessage.value = "无法读取该音频，请重新导入。"
        }
    }

    private fun stopImportedAudio() {
        importedPlayer?.let { player ->
            runCatching { player.stop() }
            runCatching { player.release() }
        }
        importedPlayer = null
        mutableImportedPlaying.value = false
    }

    fun updateTask(value: String) {
        mutablePomodoro.value = mutablePomodoro.value.copy(taskName = value.take(80))
    }

    fun selectDuration(minutes: Int) {
        if (mutablePomodoro.value.isRunning) return
        mutablePomodoro.value = mutablePomodoro.value.copy(
            durationMinutes = minutes,
            remainingMillis = minutes * 60_000L,
            completed = false,
        )
    }

    fun selectFocusBackground(value: FocusBackground) {
        mutablePomodoro.value = mutablePomodoro.value.copy(background = value)
        viewModelScope.launch { dataStore.edit { it[FOCUS_BACKGROUND] = value.name } }
    }

    fun startPomodoro() {
        val state = mutablePomodoro.value
        val endAt = timeSource.now() + state.durationMinutes * 60_000L
        mutablePomodoro.value = state.copy(endAtMillis = endAt, remainingMillis = state.durationMinutes * 60_000L, completed = false)
        viewModelScope.launch {
            dataStore.edit {
                it[END_AT] = endAt
                it[DURATION] = state.durationMinutes.toLong()
                it[TASK] = state.taskName
                it[FOCUS_BACKGROUND] = state.background.name
            }
        }
        startTicker()
    }

    fun stopPomodoro() {
        timerJob?.cancel()
        timerJob = null
        val state = mutablePomodoro.value
        mutablePomodoro.value = state.copy(endAtMillis = null, remainingMillis = state.durationMinutes * 60_000L, completed = false)
        viewModelScope.launch { dataStore.edit { it.remove(END_AT) } }
    }

    fun dismissCompletion() {
        mutablePomodoro.value = mutablePomodoro.value.copy(completed = false)
    }

    fun setSqueezeSound(uri: Uri?) {
        mutableSqueezeSound.value = uri?.toString()
        viewModelScope.launch {
            dataStore.edit { values ->
                if (uri == null) values.remove(SQUEEZE_SOUND) else values[SQUEEZE_SOUND] = uri.toString()
            }
        }
    }

    private fun startTicker() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                val current = mutablePomodoro.value
                val endAt = current.endAtMillis ?: break
                val remaining = remainingUntil(endAt, timeSource.now())
                mutablePomodoro.value = current.copy(remainingMillis = remaining)
                if (remaining == 0L) {
                    mutablePomodoro.value = mutablePomodoro.value.copy(endAtMillis = null, completed = true)
                    dataStore.edit { it.remove(END_AT) }
                    break
                }
                delay(250)
            }
        }
    }

    override fun onCleared() {
        stopAudio()
        super.onCleared()
    }

    private inline fun <reified T : Enum<T>> enumValueOrDefault(value: String?, fallback: T): T =
        enumValues<T>().firstOrNull { it.name == value } ?: fallback

    private companion object {
        val SCENE = stringPreferencesKey("companion_scene")
        val CHARACTER = stringPreferencesKey("companion_character")
        val IMPORTED_AUDIO = stringPreferencesKey("companion_imported_audio")
        val FOCUS_BACKGROUND = stringPreferencesKey("pomodoro_background")
        val END_AT = longPreferencesKey("pomodoro_end_at")
        val DURATION = longPreferencesKey("pomodoro_duration")
        val TASK = stringPreferencesKey("pomodoro_task")
        val SQUEEZE_SOUND = stringPreferencesKey("mascot_squeeze_sound")
    }
}

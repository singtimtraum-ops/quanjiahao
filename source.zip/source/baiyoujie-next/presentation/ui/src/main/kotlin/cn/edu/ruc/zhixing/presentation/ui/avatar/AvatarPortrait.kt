package cn.edu.ruc.zhixing.presentation.ui.avatar

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/**
 * zzk owns this visual implementation. Callers provide semantic state only and must not
 * reach into drawing or future animation internals.
 */
@Composable
fun AvatarPortrait(hour: Int, modifier: Modifier = Modifier) {
    Canvas(modifier.size(180.dp, 210.dp)) {
        val w = size.width
        val h = size.height
        drawOval(Color(0xFFDAEDE5), topLeft = Offset(0f, h * .25f), size = Size(w, h * .75f))
        drawOval(Color(0xFF384744), topLeft = Offset(w * .17f, 0f), size = Size(w * .66f, h * .74f))
        drawOval(Color(0xFFFFDFC9), topLeft = Offset(w * .26f, h * .16f), size = Size(w * .48f, h * .48f))
        drawOval(Color(0xFF384744), topLeft = Offset(w * .21f, h * .04f), size = Size(w * .6f, h * .26f))
        val y = h * .38f
        if (hour >= 23 || hour < 7) {
            drawLine(Color(0xFF384744), Offset(w * .36f, y), Offset(w * .43f, y), 4f)
            drawLine(Color(0xFF384744), Offset(w * .57f, y), Offset(w * .64f, y), 4f)
        } else {
            drawCircle(Color(0xFF384744), w * .025f, Offset(w * .4f, y))
            drawCircle(Color(0xFF384744), w * .025f, Offset(w * .6f, y))
        }
        drawOval(Color(0xFFE9A6AB), Offset(w * .32f, h * .44f), Size(w * .09f, h * .03f))
        drawOval(Color(0xFFE9A6AB), Offset(w * .59f, h * .44f), Size(w * .09f, h * .03f))
        drawArc(Color(0xFF9D5D57), 10f, 160f, false, Offset(w * .46f, h * .46f), Size(w * .08f, h * .05f), style = Stroke(3f))
    }
}

package cn.edu.ruc.zhixing.presentation.ui.companion

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import cn.edu.ruc.zhixing.presentation.ui.avatar.AvatarPortrait
import cn.edu.ruc.zhixing.presentation.ui.companion.model.CharacterOption
import cn.edu.ruc.zhixing.presentation.ui.companion.model.SceneOption

/** 形象动作状态：IDLE 日常、STUDY 学习、FOCUS 番茄钟专注中。 */
enum class CharacterPose(val displayName: String) {
    IDLE("日常"),
    STUDY("学习"),
    FOCUS("专注"),
}

/**
 * 场景中的虚拟形象。
 * MVP：复用 AvatarPortrait，根据场景与动作状态调整位置/提示文案。
 * 形象在场景中"做事"——锚定在场景对应位置。
 * 美术资源（char_<id>_<pose>.png）到位后替换即可。
 */
@Composable
internal fun CharacterInScene(
    character: CharacterOption,
    scene: SceneOption,
    pose: CharacterPose,
    hour: Int,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier.fillMaxSize().padding(bottom = 80.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        AvatarPortrait(hour)
        val poseLabel = when (pose) {
            CharacterPose.STUDY -> "正在看书"
            CharacterPose.FOCUS -> "陪你专注中"
            CharacterPose.IDLE -> "在这里陪你"
        }
        Text(
            "${character.displayName} · $poseLabel",
            color = if (scene == SceneOption.NIGHT_WINDOW) Color.White else Color(0xFF202624),
        )
    }
}

/** 根据场景决定形象的默认动作。 */
internal fun defaultPoseFor(scene: SceneOption): CharacterPose = when (scene) {
    SceneOption.STUDY_ROOM -> CharacterPose.STUDY
    SceneOption.NIGHT_WINDOW -> CharacterPose.STUDY
    SceneOption.CLASSROOM -> CharacterPose.STUDY
}

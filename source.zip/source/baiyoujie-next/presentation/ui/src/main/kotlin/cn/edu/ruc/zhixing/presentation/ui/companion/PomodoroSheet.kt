package cn.edu.ruc.zhixing.presentation.ui.companion

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import cn.edu.ruc.zhixing.presentation.ui.companion.model.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun PomodoroSheet(
    state: PomodoroState,
    playingNoise: NoiseKind?,
    importedAudio: String?,
    importedPlaying: Boolean,
    onTaskChange: (String) -> Unit,
    onDuration: (Int) -> Unit,
    onBackground: (FocusBackground) -> Unit,
    onNoise: (NoiseKind) -> Unit,
    onStopAudio: () -> Unit,
    onImport: (android.net.Uri) -> Unit,
    onPlayImported: () -> Unit,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            onImport(uri)
        }
    }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text("番茄钟", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(
                value = state.taskName,
                onValueChange = onTaskChange,
                enabled = !state.isRunning,
                label = { Text("任务名称（可选）") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Text("专注时长", style = MaterialTheme.typography.titleSmall)
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                listOf(25, 45).forEachIndexed { index, minutes ->
                    SegmentedButton(
                        selected = state.durationMinutes == minutes,
                        onClick = { onDuration(minutes) },
                        enabled = !state.isRunning,
                        shape = SegmentedButtonDefaults.itemShape(index, 2),
                    ) { Text("$minutes 分钟") }
                }
            }
            Text("页面背景", style = MaterialTheme.typography.titleSmall)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FocusBackground.entries.forEach { background ->
                    FilterChip(
                        selected = state.background == background,
                        onClick = { onBackground(background) },
                        label = { Text(background.displayName) },
                        modifier = Modifier.weight(1f),
                    )
                }
            }
            Text("专注声音", style = MaterialTheme.typography.titleSmall)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                NoiseKind.entries.forEach { kind ->
                    FilterChip(
                        selected = playingNoise == kind,
                        onClick = { onNoise(kind) },
                        label = { Text(kind.displayName) },
                        modifier = Modifier.weight(1f),
                    )
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { audioPicker.launch(arrayOf("audio/*")) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(6.dp))
                    Text(if (importedAudio == null) "导入本地音频" else "更换本地音频")
                }
                if (importedAudio != null) {
                    IconButton(onClick = if (importedPlaying) onStopAudio else onPlayImported) {
                        Icon(if (importedPlaying) Icons.Default.Close else Icons.Default.PlayArrow, if (importedPlaying) "停止本地音频" else "播放本地音频")
                    }
                }
            }
            FocusTimer(state)
            Button(
                onClick = if (state.isRunning) onStop else onStart,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Icon(if (state.isRunning) Icons.Default.Close else Icons.Default.PlayArrow, null)
                Spacer(Modifier.width(8.dp))
                Text(if (state.isRunning) "结束专注" else "开始番茄钟")
            }
        }
    }
}

@Composable
private fun FocusTimer(state: PomodoroState) {
    val background = when (state.background) {
        FocusBackground.FOREST -> Color(0xFFD7EEDF)
        FocusBackground.PAPER -> Color(0xFFF2EEE3)
        FocusBackground.NIGHT -> Color(0xFF303A4A)
    }
    val foreground = if (state.background == FocusBackground.NIGHT) Color.White else Color(0xFF202624)
    Box(
        Modifier.fillMaxWidth().height(132.dp).background(background, RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(formatRemaining(state.remainingMillis), style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.SemiBold, color = foreground)
            if (state.taskName.isNotBlank()) Text(state.taskName, color = foreground)
        }
    }
}

internal fun formatRemaining(milliseconds: Long): String {
    val totalSeconds = (milliseconds.coerceAtLeast(0) + 999) / 1000
    return "%02d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}

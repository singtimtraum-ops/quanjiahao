package cn.edu.ruc.zhixing.presentation.ui

import org.junit.Assert.assertEquals
import org.junit.Test

class NavigationContractTest {
    @Test
    fun fourTabsHaveStableOrder() {
        assertEquals(
            listOf("主页", "陪伴", "对话", "日程"),
            TabDestination.entries.map { it.label },
        )
    }
}

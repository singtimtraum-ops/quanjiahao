package cn.edu.ruc.zhixing.presentation.ui.companion

import cn.edu.ruc.zhixing.presentation.ui.companion.model.remainingUntil
import org.junit.Assert.assertEquals
import org.junit.Test

class PomodoroTimeTest {
    @Test
    fun backgroundElapsedTimeIsIncluded() {
        assertEquals(20_000L, remainingUntil(endAtMillis = 100_000L, nowMillis = 80_000L))
        assertEquals(0L, remainingUntil(endAtMillis = 100_000L, nowMillis = 120_000L))
    }

    @Test
    fun displayRoundsPartialSecondUp() {
        assertEquals("25:00", formatRemaining(1_500_000L))
        assertEquals("00:01", formatRemaining(1L))
        assertEquals("00:00", formatRemaining(0L))
    }
}

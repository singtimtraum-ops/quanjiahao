param(
    [ValidateSet('auto', 'owner', 'zzj', 'zzk', 'integration')]
    [string]$Role = 'auto',
    [string]$BaseRef = 'integration'
)

$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path

function Invoke-Git([string[]]$Arguments) {
    $output = & git -C $root @Arguments 2>&1
    if ($LASTEXITCODE -ne 0) { throw ($output -join [Environment]::NewLine) }
    return @($output)
}

$branch = (Invoke-Git @('branch', '--show-current') | Select-Object -First 1).Trim()
if ($Role -eq 'auto') {
    $Role = switch -Regex ($branch) {
        '^feature/chat-and-app-shell$' { 'owner'; break }
        '^feature/calendar-and-message$' { 'zzj'; break }
        '^feature/avatar-and-art$' { 'zzk'; break }
        '^(integration|main)$' { 'integration'; break }
        default { throw "无法从分支 '$branch' 判断角色，请显式传入 -Role。" }
    }
}

$tracked = Invoke-Git @('ls-files')
$forbiddenPatterns = @(
    '(^|/)local\.properties$', '(^|/)\.env($|\.)', '\.(jks|keystore|pem|p12)$',
    '\.(apk|aab)$', '\.(db|db-shm|db-wal|sqlite|sqlite3)$', '\.log$'
)
$forbidden = @($tracked | Where-Object {
    $path = $_
    $forbiddenPatterns | Where-Object { $path -match $_ } | Select-Object -First 1
})
if ($forbidden.Count -gt 0) {
    throw "仓库中包含不应提交的本机文件：`n$($forbidden -join "`n")"
}

$secretPattern = '(sk-[A-Za-z0-9_-]{20,}|AIza[0-9A-Za-z_-]{30,}|-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----)'
$secretMatches = @(& git -C $root grep -I -n -E $secretPattern -- . 2>$null)
if ($LASTEXITCODE -eq 0) {
    throw "仓库内容疑似包含真实密钥，请移除后再提交：`n$($secretMatches -join "`n")"
}
if ($LASTEXITCODE -gt 1) { throw '无法完成仓库密钥扫描。' }

if ($Role -eq 'integration') {
    Write-Host "检查通过：未发现敏感或构建产物，当前角色为 integration。"
    exit 0
}

& git -C $root rev-parse --verify --quiet $BaseRef *> $null
if ($LASTEXITCODE -ne 0) {
    Write-Warning "基线 '$BaseRef' 不存在，仅完成敏感文件检查。"
    exit 0
}
$changed = @(
    Invoke-Git @('diff', '--name-only', "${BaseRef}...HEAD")
    Invoke-Git @('diff', '--cached', '--name-only')
    Invoke-Git @('diff', '--name-only')
) | Where-Object { $_ } | Sort-Object -Unique

$sharedDocs = '^docs/handoffs/|^docs/proposals/'
$allowed = switch ($Role) {
    'owner' { @('^companion/', '^presentation/ui/.*/companion/', '^presentation/ui/.*/features/(home|chat|settings)/', '^presentation/ui/src/test/.*/(home|chat|settings|companion)/', $sharedDocs) }
    'zzj' { @('^planner/', '^acquisition/', '^engine/', '^presentation/ui/.*/features/schedule/', '^presentation/ui/.*/messages/', $sharedDocs) }
    'zzk' { @('^presentation/ui/.*/avatar/', '^presentation/ui/src/main/res/(drawable|drawable-[^/]+|mipmap[^/]*|font|raw)/', '^docs/art/', $sharedDocs) }
}
$violations = @($changed | Where-Object {
    $path = $_
    -not ($allowed | Where-Object { $path -match $_ } | Select-Object -First 1)
})
if ($violations.Count -gt 0) {
    throw "角色 '$Role' 修改了职责范围外的文件。请撤回这些改动，或在交接单中申请由集成 Agent 修改：`n$($violations -join "`n")"
}

Write-Host "检查通过：$($changed.Count) 个改动文件均属于角色 '$Role'。"
